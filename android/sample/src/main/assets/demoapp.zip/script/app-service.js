define("pages/answer/answer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({
    data: {
        askId: ""
    },
    onLoad: function onLoad(options) {
        // 获取打听的 id
        this.setData({
            askId: options.uid
        });
    },

    // 提交打听按钮
    formSubmit: function formSubmit(e) {
        var that = this;

        // 获取答案信息
        var answer = e.detail.value.answer;
        var contact = e.detail.value.contact;

        if (answer.length == 0) {
            wx.showModal({
                content: "您还没有输入答案",
                showCancel: false
            });
        } else {
            var myId = app.globalData.su_uid;
            var ask_uid = that.data.askId;

            app.request({
                url: "_a=ask&_u=ajax.addaskanswer",
                data: {
                    su_uid: myId,
                    ask_uid: ask_uid,
                    brief: answer,
                    info: {
                        contact: contact
                    }
                },
                success: that.postAnswerCb
            });
        }
    },

    // 回答打听的回调函数
    postAnswerCb: function postAnswerCb(ret) {
        if (ret.errno == 0) {
            wx.showToast({
                title: "提交成功",
                success: function success() {
                    setTimeout(function () {
                        wx.navigateBack();
                    }, 1000);
                }
            });
        }
    }
});
});
define("pages/answerList/answerList.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
var util = require('../../../../utils/util.js');
var shareUrl = "";

Page({

    /**
    * 页面的初始数据
    */
    data: {},

    /**
    * 生命周期函数--监听页面加载
    */
    onLoad: function onLoad(options) {
        var id = options.ask_uid;
        shareUrl = "/pages/asking/pages/answerList/answerList?ask_uid=" + id;

        console.log("options >>>", options);
        if (options.relayer) {
            this.setData({
                relayer: true
            });
            this.getRelayerList(id);
        } else {
            this.getAnswerList(id);
        }
    },

    /**
    * 生命周期函数--监听页面初次渲染完成
    */
    onReady: function onReady() {},

    /**
    * 生命周期函数--监听页面显示
    */
    onShow: function onShow() {},

    // 获取打听信息
    getRelayerList: function getRelayerList(id) {
        var that = this;

        app.request({
            url: "_a=ask&_u=ajax.ask",
            data: {
                uid: id
            },
            success: function success(ret) {
                var askData = ret.data;
                var relayerList = askData.cash_share;

                console.log("ret ", ret);

                relayerList.forEach(function (ele) {
                    ele.name = ele.profile.realname ? ele.profile.realname : ele.su.name;
                    ele.price = util.formatPrice(ele.cash);
                });

                console.log("relayerList >>> ", relayerList);

                that.setData({
                    relayerList: relayerList
                });
            }
        });
    },

    // 获取接单回复列表函数
    getAnswerList: function getAnswerList(id) {
        var that = this;

        // 获取接单回复列表
        app.request({
            url: "_a=ask&_u=ajax.answerlist",
            data: {
                ask_uid: id
            },
            success: function success(ret) {
                console.log("answerList >>>>>> ", ret);
                var answerList = ret.data.list;
                answerList.forEach(function (ele) {
                    ele.name = ele.profile.realname ? ele.profile.realname : ele.su.name;
                });

                that.setData({
                    answerList: answerList
                    // maxIndex: maxIndex
                });
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    /**
    * 页面上拉触底事件的处理函数
    */
    onReachBottom: function onReachBottom() {},

    /**
    * 用户点击右上角分享
    */
    onShareAppMessage: function onShareAppMessage() {
        return {
            title: "打听答案列表",
            path: shareUrl
        };
    }
});
});
define("pages/askingRule/askingRule.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var WxParse = require('../../../common/wxParse/wxParse.js');
var app = getApp();

Page({
    data: {},
    onLoad: function onLoad(options) {
        var that = this;

        app.request({
            url: "_a=ask&_u=ajax.get_ask_rule",
            data: {},
            success: that.getRuleCb
        });
    },
    // 获取打听规则回调函数
    getRuleCb: function getRuleCb(ret) {
        var article = ret.data;
        var that = this;

        WxParse.wxParse('article', 'html', article, that, 5);
    },

    onShareAppMessage: function onShareAppMessage() {
        return {
            title: "芒格学院打听问事规则"
        };
    }
});
});
define("pages/common/wxParse/html2json.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * html2Json 改造来自: https://github.com/Jxck/html2json
 * 
 * 
 * author: Di (微信小程序开发工程师)
 * organization: WeAppDev(微信小程序开发论坛)(http://weappdev.com)
 *               垂直微信小程序开发交流社区
 * 
 * github地址: https://github.com/icindy/wxParse
 * 
 * for: 微信小程序富文本解析
 * detail : http://weappdev.com/t/wxparse-alpha0-1-html-markdown/184
 */

var __placeImgeUrlHttps = "https";
var __emojisReg = '';
var __emojisBaseSrc = '';
var __emojis = {};
var wxDiscode = require('./wxDiscode.js');
var HTMLParser = require('./htmlparser.js');
// Empty Elements - HTML 5
var empty = makeMap("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr");
// Block Elements - HTML 5
var block = makeMap("br,a,code,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video");

// Inline Elements - HTML 5
var inline = makeMap("abbr,acronym,applet,b,basefont,bdo,big,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var");

// Elements that you can, intentionally, leave open
// (and which close themselves)
var closeSelf = makeMap("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr");

// Attributes that have their values filled in disabled="disabled"
var fillAttrs = makeMap("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected");

// Special Elements (can contain anything)
var special = makeMap("wxxxcode-style,script,style,view,scroll-view,block");
function makeMap(str) {
    var obj = {},
        items = str.split(",");
    for (var i = 0; i < items.length; i++) {
        obj[items[i]] = true;
    }return obj;
}

function q(v) {
    return '"' + v + '"';
}

function removeDOCTYPE(html) {
    return html.replace(/<\?xml.*\?>\n/, '').replace(/<.*!doctype.*\>\n/, '').replace(/<.*!DOCTYPE.*\>\n/, '');
}

function html2json(html, bindName) {
    //处理字符串
    html = removeDOCTYPE(html);
    html = wxDiscode.strDiscode(html);
    //生成node节点
    var bufArray = [];
    var results = {
        node: bindName,
        nodes: [],
        images: [],
        imageUrls: []
    };
    HTMLParser(html, {
        start: function start(tag, attrs, unary) {
            //debug(tag, attrs, unary);
            // node for this element
            var node = {
                node: 'element',
                tag: tag
            };

            if (block[tag]) {
                node.tagType = "block";
            } else if (inline[tag]) {
                node.tagType = "inline";
            } else if (closeSelf[tag]) {
                node.tagType = "closeSelf";
            }

            if (attrs.length !== 0) {
                node.attr = attrs.reduce(function (pre, attr) {
                    var name = attr.name;
                    var value = attr.value;
                    if (name == 'class') {
                        console.dir(value);
                        //  value = value.join("")
                        node.classStr = value;
                    }
                    // has multi attibutes
                    // make it array of attribute
                    if (name == 'style') {
                        console.dir(value);
                        //  value = value.join("")
                        node.styleStr = value;
                    }
                    if (value.match(/ /)) {
                        value = value.split(' ');
                    }

                    // if attr already exists
                    // merge it
                    if (pre[name]) {
                        if (Array.isArray(pre[name])) {
                            // already array, push to last
                            pre[name].push(value);
                        } else {
                            // single value, make it array
                            pre[name] = [pre[name], value];
                        }
                    } else {
                        // not exist, put it
                        pre[name] = value;
                    }

                    return pre;
                }, {});
            }

            //对img添加额外数据
            if (node.tag === 'img') {
                node.imgIndex = results.images.length;
                var imgUrl = node.attr.src;
                imgUrl = wxDiscode.urlToHttpUrl(imgUrl, __placeImgeUrlHttps);
                node.attr.src = imgUrl;
                node.from = bindName;
                results.images.push(node);
                results.imageUrls.push(imgUrl);
            }

            // 处理font标签样式属性
            if (node.tag === 'font') {
                var fontSize = ['x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', '-webkit-xxx-large'];
                var styleAttrs = {
                    'color': 'color',
                    'face': 'font-family',
                    'size': 'font-size'
                };
                if (!node.attr.style) node.attr.style = [];
                if (!node.styleStr) node.styleStr = '';
                for (var key in styleAttrs) {
                    if (node.attr[key]) {
                        var value = key === 'size' ? fontSize[node.attr[key] - 1] : node.attr[key];
                        node.attr.style.push(styleAttrs[key]);
                        node.attr.style.push(value);
                        node.styleStr += styleAttrs[key] + ': ' + value + ';';
                    }
                }
            }

            //临时记录source资源
            if (node.tag === 'source') {
                results.source = node.attr.src;
            }

            if (unary) {
                // if this tag dosen't have end tag
                // like <img src="hoge.png"/>
                // add to parents
                var parent = bufArray[0] || results;
                if (parent.nodes === undefined) {
                    parent.nodes = [];
                }
                parent.nodes.push(node);
            } else {
                bufArray.unshift(node);
            }
        },
        end: function end(tag) {
            //debug(tag);
            // merge into parent tag
            var node = bufArray.shift();
            if (node.tag !== tag) console.error('invalid state: mismatch end tag');

            //当有缓存source资源时于于video补上src资源
            if (node.tag === 'video' && results.source) {
                node.attr.src = results.source;
                delete result.source;
            }

            if (bufArray.length === 0) {
                results.nodes.push(node);
            } else {
                var parent = bufArray[0];
                if (parent.nodes === undefined) {
                    parent.nodes = [];
                }
                parent.nodes.push(node);
            }
        },
        chars: function chars(text) {
            //debug(text);
            var node = {
                node: 'text',
                text: text,
                textArray: transEmojiStr(text)
            };

            if (bufArray.length === 0) {
                results.nodes.push(node);
            } else {
                var parent = bufArray[0];
                if (parent.nodes === undefined) {
                    parent.nodes = [];
                }
                parent.nodes.push(node);
            }
        },
        comment: function comment(text) {
            //debug(text);
            // var node = {
            //     node: 'comment',
            //     text: text,
            // };
            // var parent = bufArray[0];
            // if (parent.nodes === undefined) {
            //     parent.nodes = [];
            // }
            // parent.nodes.push(node);
        }
    });
    return results;
};

function transEmojiStr(str) {
    // var eReg = new RegExp("["+__reg+' '+"]");
    //   str = str.replace(/\[([^\[\]]+)\]/g,':$1:')

    var emojiObjs = [];
    //如果正则表达式为空
    if (__emojisReg.length == 0 || !__emojis) {
        var emojiObj = {};
        emojiObj.node = "text";
        emojiObj.text = str;
        array = [emojiObj];
        return array;
    }
    //这个地方需要调整
    str = str.replace(/\[([^\[\]]+)\]/g, ':$1:');
    var eReg = new RegExp("[:]");
    var array = str.split(eReg);
    for (var i = 0; i < array.length; i++) {
        var ele = array[i];
        var emojiObj = {};
        if (__emojis[ele]) {
            emojiObj.node = "element";
            emojiObj.tag = "emoji";
            emojiObj.text = __emojis[ele];
            emojiObj.baseSrc = __emojisBaseSrc;
        } else {
            emojiObj.node = "text";
            emojiObj.text = ele;
        }
        emojiObjs.push(emojiObj);
    }

    return emojiObjs;
}

function emojisInit() {
    var reg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var baseSrc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "/wxParse/emojis/";
    var emojis = arguments[2];

    __emojisReg = reg;
    __emojisBaseSrc = baseSrc;
    __emojis = emojis;
}

module.exports = {
    html2json: html2json,
    emojisInit: emojisInit
};
});
define("pages/common/wxParse/htmlparser.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

/**
 * 
 * htmlParser改造自: https://github.com/blowsie/Pure-JavaScript-HTML5-Parser
 * 
 * author: Di (微信小程序开发工程师)
 * organization: WeAppDev(微信小程序开发论坛)(http://weappdev.com)
 *               垂直微信小程序开发交流社区
 * 
 * github地址: https://github.com/icindy/wxParse
 * 
 * for: 微信小程序富文本解析
 * detail : http://weappdev.com/t/wxparse-alpha0-1-html-markdown/184
 */
// Regular Expressions for parsing tags and attributes
var startTag = /^<([-A-Za-z0-9_]+)((?:\s+[a-zA-Z_:][-a-zA-Z0-9_:.]*(?:\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/,
    endTag = /^<\/([-A-Za-z0-9_]+)[^>]*>/,
    attr = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g;

// Empty Elements - HTML 5
var empty = makeMap("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr");

// Block Elements - HTML 5
var block = makeMap("a,address,code,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video");

// Inline Elements - HTML 5
var inline = makeMap("abbr,acronym,applet,b,basefont,bdo,big,br,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var");

// Elements that you can, intentionally, leave open
// (and which close themselves)
var closeSelf = makeMap("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr");

// Attributes that have their values filled in disabled="disabled"
var fillAttrs = makeMap("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected");

// Special Elements (can contain anything)
var special = makeMap("wxxxcode-style,script,style,view,scroll-view,block");

function HTMLParser(html, handler) {
	var index,
	    chars,
	    match,
	    stack = [],
	    last = html;
	stack.last = function () {
		return this[this.length - 1];
	};

	while (html) {
		chars = true;

		// Make sure we're not in a script or style element
		if (!stack.last() || !special[stack.last()]) {

			// Comment
			if (html.indexOf("<!--") == 0) {
				index = html.indexOf("-->");

				if (index >= 0) {
					if (handler.comment) handler.comment(html.substring(4, index));
					html = html.substring(index + 3);
					chars = false;
				}

				// end tag
			} else if (html.indexOf("</") == 0) {
				match = html.match(endTag);

				if (match) {
					html = html.substring(match[0].length);
					match[0].replace(endTag, parseEndTag);
					chars = false;
				}

				// start tag
			} else if (html.indexOf("<") == 0) {
				match = html.match(startTag);

				if (match) {
					html = html.substring(match[0].length);
					match[0].replace(startTag, parseStartTag);
					chars = false;
				}
			}

			if (chars) {
				index = html.indexOf("<");
				var text = '';
				while (index === 0) {
					text += "<";
					html = html.substring(1);
					index = html.indexOf("<");
				}
				text += index < 0 ? html : html.substring(0, index);
				html = index < 0 ? "" : html.substring(index);

				if (handler.chars) handler.chars(text);
			}
		} else {

			html = html.replace(new RegExp("([\\s\\S]*?)<\/" + stack.last() + "[^>]*>"), function (all, text) {
				text = text.replace(/<!--([\s\S]*?)-->|<!\[CDATA\[([\s\S]*?)]]>/g, "$1$2");
				if (handler.chars) handler.chars(text);

				return "";
			});

			parseEndTag("", stack.last());
		}

		if (html == last) throw "Parse Error: " + html;
		last = html;
	}

	// Clean up any remaining tags
	parseEndTag();

	function parseStartTag(tag, tagName, rest, unary) {
		tagName = tagName.toLowerCase();

		if (block[tagName]) {
			while (stack.last() && inline[stack.last()]) {
				parseEndTag("", stack.last());
			}
		}

		if (closeSelf[tagName] && stack.last() == tagName) {
			parseEndTag("", tagName);
		}

		unary = empty[tagName] || !!unary;

		if (!unary) stack.push(tagName);

		if (handler.start) {
			var attrs = [];

			rest.replace(attr, function (match, name) {
				var value = arguments[2] ? arguments[2] : arguments[3] ? arguments[3] : arguments[4] ? arguments[4] : fillAttrs[name] ? name : "";

				attrs.push({
					name: name,
					value: value,
					escaped: value.replace(/(^|[^\\])"/g, '$1\\\"') //"
				});
			});

			if (handler.start) {
				handler.start(tagName, attrs, unary);
			}
		}
	}

	function parseEndTag(tag, tagName) {
		// If no tag name is provided, clean shop
		if (!tagName) var pos = 0;

		// Find the closest opened tag of the same type
		else {
				tagName = tagName.toLowerCase();
				for (var pos = stack.length - 1; pos >= 0; pos--) {
					if (stack[pos] == tagName) break;
				}
			}
		if (pos >= 0) {
			// Close all the open elements, up the stack
			for (var i = stack.length - 1; i >= pos; i--) {
				if (handler.end) handler.end(stack[i]);
			} // Remove the open elements from the stack
			stack.length = pos;
		}
	}
};

function makeMap(str) {
	var obj = {},
	    items = str.split(",");
	for (var i = 0; i < items.length; i++) {
		obj[items[i]] = true;
	}return obj;
}

module.exports = HTMLParser;
});
define("pages/common/wxParse/showdown.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

/**
 * 
 * showdown: https://github.com/showdownjs/showdown
 * 
 * author: Di (微信小程序开发工程师)
 * organization: WeAppDev(微信小程序开发论坛)(http://weappdev.com)
 *               垂直微信小程序开发交流社区
 * 
 * github地址: https://github.com/icindy/wxParse
 * 
 * for: 微信小程序富文本解析
 * detail : http://weappdev.com/t/wxparse-alpha0-1-html-markdown/184
 */

function getDefaultOpts(simple) {
  'use strict';

  var defaultOptions = {
    omitExtraWLInCodeBlocks: {
      defaultValue: false,
      describe: 'Omit the default extra whiteline added to code blocks',
      type: 'boolean'
    },
    noHeaderId: {
      defaultValue: false,
      describe: 'Turn on/off generated header id',
      type: 'boolean'
    },
    prefixHeaderId: {
      defaultValue: false,
      describe: 'Specify a prefix to generated header ids',
      type: 'string'
    },
    headerLevelStart: {
      defaultValue: false,
      describe: 'The header blocks level start',
      type: 'integer'
    },
    parseImgDimensions: {
      defaultValue: false,
      describe: 'Turn on/off image dimension parsing',
      type: 'boolean'
    },
    simplifiedAutoLink: {
      defaultValue: false,
      describe: 'Turn on/off GFM autolink style',
      type: 'boolean'
    },
    literalMidWordUnderscores: {
      defaultValue: false,
      describe: 'Parse midword underscores as literal underscores',
      type: 'boolean'
    },
    strikethrough: {
      defaultValue: false,
      describe: 'Turn on/off strikethrough support',
      type: 'boolean'
    },
    tables: {
      defaultValue: false,
      describe: 'Turn on/off tables support',
      type: 'boolean'
    },
    tablesHeaderId: {
      defaultValue: false,
      describe: 'Add an id to table headers',
      type: 'boolean'
    },
    ghCodeBlocks: {
      defaultValue: true,
      describe: 'Turn on/off GFM fenced code blocks support',
      type: 'boolean'
    },
    tasklists: {
      defaultValue: false,
      describe: 'Turn on/off GFM tasklist support',
      type: 'boolean'
    },
    smoothLivePreview: {
      defaultValue: false,
      describe: 'Prevents weird effects in live previews due to incomplete input',
      type: 'boolean'
    },
    smartIndentationFix: {
      defaultValue: false,
      description: 'Tries to smartly fix identation in es6 strings',
      type: 'boolean'
    }
  };
  if (simple === false) {
    return JSON.parse(JSON.stringify(defaultOptions));
  }
  var ret = {};
  for (var opt in defaultOptions) {
    if (defaultOptions.hasOwnProperty(opt)) {
      ret[opt] = defaultOptions[opt].defaultValue;
    }
  }
  return ret;
}

/**
 * Created by Tivie on 06-01-2015.
 */

// Private properties
var showdown = {},
    parsers = {},
    extensions = {},
    globalOptions = getDefaultOpts(true),
    flavor = {
  github: {
    omitExtraWLInCodeBlocks: true,
    prefixHeaderId: 'user-content-',
    simplifiedAutoLink: true,
    literalMidWordUnderscores: true,
    strikethrough: true,
    tables: true,
    tablesHeaderId: true,
    ghCodeBlocks: true,
    tasklists: true
  },
  vanilla: getDefaultOpts(true)
};

/**
 * helper namespace
 * @type {{}}
 */
showdown.helper = {};

/**
 * TODO LEGACY SUPPORT CODE
 * @type {{}}
 */
showdown.extensions = {};

/**
 * Set a global option
 * @static
 * @param {string} key
 * @param {*} value
 * @returns {showdown}
 */
showdown.setOption = function (key, value) {
  'use strict';

  globalOptions[key] = value;
  return this;
};

/**
 * Get a global option
 * @static
 * @param {string} key
 * @returns {*}
 */
showdown.getOption = function (key) {
  'use strict';

  return globalOptions[key];
};

/**
 * Get the global options
 * @static
 * @returns {{}}
 */
showdown.getOptions = function () {
  'use strict';

  return globalOptions;
};

/**
 * Reset global options to the default values
 * @static
 */
showdown.resetOptions = function () {
  'use strict';

  globalOptions = getDefaultOpts(true);
};

/**
 * Set the flavor showdown should use as default
 * @param {string} name
 */
showdown.setFlavor = function (name) {
  'use strict';

  if (flavor.hasOwnProperty(name)) {
    var preset = flavor[name];
    for (var option in preset) {
      if (preset.hasOwnProperty(option)) {
        globalOptions[option] = preset[option];
      }
    }
  }
};

/**
 * Get the default options
 * @static
 * @param {boolean} [simple=true]
 * @returns {{}}
 */
showdown.getDefaultOptions = function (simple) {
  'use strict';

  return getDefaultOpts(simple);
};

/**
 * Get or set a subParser
 *
 * subParser(name)       - Get a registered subParser
 * subParser(name, func) - Register a subParser
 * @static
 * @param {string} name
 * @param {function} [func]
 * @returns {*}
 */
showdown.subParser = function (name, func) {
  'use strict';

  if (showdown.helper.isString(name)) {
    if (typeof func !== 'undefined') {
      parsers[name] = func;
    } else {
      if (parsers.hasOwnProperty(name)) {
        return parsers[name];
      } else {
        throw Error('SubParser named ' + name + ' not registered!');
      }
    }
  }
};

/**
 * Gets or registers an extension
 * @static
 * @param {string} name
 * @param {object|function=} ext
 * @returns {*}
 */
showdown.extension = function (name, ext) {
  'use strict';

  if (!showdown.helper.isString(name)) {
    throw Error('Extension \'name\' must be a string');
  }

  name = showdown.helper.stdExtName(name);

  // Getter
  if (showdown.helper.isUndefined(ext)) {
    if (!extensions.hasOwnProperty(name)) {
      throw Error('Extension named ' + name + ' is not registered!');
    }
    return extensions[name];

    // Setter
  } else {
    // Expand extension if it's wrapped in a function
    if (typeof ext === 'function') {
      ext = ext();
    }

    // Ensure extension is an array
    if (!showdown.helper.isArray(ext)) {
      ext = [ext];
    }

    var validExtension = validate(ext, name);

    if (validExtension.valid) {
      extensions[name] = ext;
    } else {
      throw Error(validExtension.error);
    }
  }
};

/**
 * Gets all extensions registered
 * @returns {{}}
 */
showdown.getAllExtensions = function () {
  'use strict';

  return extensions;
};

/**
 * Remove an extension
 * @param {string} name
 */
showdown.removeExtension = function (name) {
  'use strict';

  delete extensions[name];
};

/**
 * Removes all extensions
 */
showdown.resetExtensions = function () {
  'use strict';

  extensions = {};
};

/**
 * Validate extension
 * @param {array} extension
 * @param {string} name
 * @returns {{valid: boolean, error: string}}
 */
function validate(extension, name) {
  'use strict';

  var errMsg = name ? 'Error in ' + name + ' extension->' : 'Error in unnamed extension',
      ret = {
    valid: true,
    error: ''
  };

  if (!showdown.helper.isArray(extension)) {
    extension = [extension];
  }

  for (var i = 0; i < extension.length; ++i) {
    var baseMsg = errMsg + ' sub-extension ' + i + ': ',
        ext = extension[i];
    if ((typeof ext === 'undefined' ? 'undefined' : _typeof(ext)) !== 'object') {
      ret.valid = false;
      ret.error = baseMsg + 'must be an object, but ' + (typeof ext === 'undefined' ? 'undefined' : _typeof(ext)) + ' given';
      return ret;
    }

    if (!showdown.helper.isString(ext.type)) {
      ret.valid = false;
      ret.error = baseMsg + 'property "type" must be a string, but ' + _typeof(ext.type) + ' given';
      return ret;
    }

    var type = ext.type = ext.type.toLowerCase();

    // normalize extension type
    if (type === 'language') {
      type = ext.type = 'lang';
    }

    if (type === 'html') {
      type = ext.type = 'output';
    }

    if (type !== 'lang' && type !== 'output' && type !== 'listener') {
      ret.valid = false;
      ret.error = baseMsg + 'type ' + type + ' is not recognized. Valid values: "lang/language", "output/html" or "listener"';
      return ret;
    }

    if (type === 'listener') {
      if (showdown.helper.isUndefined(ext.listeners)) {
        ret.valid = false;
        ret.error = baseMsg + '. Extensions of type "listener" must have a property called "listeners"';
        return ret;
      }
    } else {
      if (showdown.helper.isUndefined(ext.filter) && showdown.helper.isUndefined(ext.regex)) {
        ret.valid = false;
        ret.error = baseMsg + type + ' extensions must define either a "regex" property or a "filter" method';
        return ret;
      }
    }

    if (ext.listeners) {
      if (_typeof(ext.listeners) !== 'object') {
        ret.valid = false;
        ret.error = baseMsg + '"listeners" property must be an object but ' + _typeof(ext.listeners) + ' given';
        return ret;
      }
      for (var ln in ext.listeners) {
        if (ext.listeners.hasOwnProperty(ln)) {
          if (typeof ext.listeners[ln] !== 'function') {
            ret.valid = false;
            ret.error = baseMsg + '"listeners" property must be an hash of [event name]: [callback]. listeners.' + ln + ' must be a function but ' + _typeof(ext.listeners[ln]) + ' given';
            return ret;
          }
        }
      }
    }

    if (ext.filter) {
      if (typeof ext.filter !== 'function') {
        ret.valid = false;
        ret.error = baseMsg + '"filter" must be a function, but ' + _typeof(ext.filter) + ' given';
        return ret;
      }
    } else if (ext.regex) {
      if (showdown.helper.isString(ext.regex)) {
        ext.regex = new RegExp(ext.regex, 'g');
      }
      if (!ext.regex instanceof RegExp) {
        ret.valid = false;
        ret.error = baseMsg + '"regex" property must either be a string or a RegExp object, but ' + _typeof(ext.regex) + ' given';
        return ret;
      }
      if (showdown.helper.isUndefined(ext.replace)) {
        ret.valid = false;
        ret.error = baseMsg + '"regex" extensions must implement a replace string or function';
        return ret;
      }
    }
  }
  return ret;
}

/**
 * Validate extension
 * @param {object} ext
 * @returns {boolean}
 */
showdown.validateExtension = function (ext) {
  'use strict';

  var validateExtension = validate(ext, null);
  if (!validateExtension.valid) {
    console.warn(validateExtension.error);
    return false;
  }
  return true;
};

/**
 * showdownjs helper functions
 */

if (!showdown.hasOwnProperty('helper')) {
  showdown.helper = {};
}

/**
 * Check if var is string
 * @static
 * @param {string} a
 * @returns {boolean}
 */
showdown.helper.isString = function isString(a) {
  'use strict';

  return typeof a === 'string' || a instanceof String;
};

/**
 * Check if var is a function
 * @static
 * @param {string} a
 * @returns {boolean}
 */
showdown.helper.isFunction = function isFunction(a) {
  'use strict';

  var getType = {};
  return a && getType.toString.call(a) === '[object Function]';
};

/**
 * ForEach helper function
 * @static
 * @param {*} obj
 * @param {function} callback
 */
showdown.helper.forEach = function forEach(obj, callback) {
  'use strict';

  if (typeof obj.forEach === 'function') {
    obj.forEach(callback);
  } else {
    for (var i = 0; i < obj.length; i++) {
      callback(obj[i], i, obj);
    }
  }
};

/**
 * isArray helper function
 * @static
 * @param {*} a
 * @returns {boolean}
 */
showdown.helper.isArray = function isArray(a) {
  'use strict';

  return a.constructor === Array;
};

/**
 * Check if value is undefined
 * @static
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is `undefined`, else `false`.
 */
showdown.helper.isUndefined = function isUndefined(value) {
  'use strict';

  return typeof value === 'undefined';
};

/**
 * Standardidize extension name
 * @static
 * @param {string} s extension name
 * @returns {string}
 */
showdown.helper.stdExtName = function (s) {
  'use strict';

  return s.replace(/[_-]||\s/g, '').toLowerCase();
};

function escapeCharactersCallback(wholeMatch, m1) {
  'use strict';

  var charCodeToEscape = m1.charCodeAt(0);
  return '~E' + charCodeToEscape + 'E';
}

/**
 * Callback used to escape characters when passing through String.replace
 * @static
 * @param {string} wholeMatch
 * @param {string} m1
 * @returns {string}
 */
showdown.helper.escapeCharactersCallback = escapeCharactersCallback;

/**
 * Escape characters in a string
 * @static
 * @param {string} text
 * @param {string} charsToEscape
 * @param {boolean} afterBackslash
 * @returns {XML|string|void|*}
 */
showdown.helper.escapeCharacters = function escapeCharacters(text, charsToEscape, afterBackslash) {
  'use strict';
  // First we have to escape the escape characters so that
  // we can build a character class out of them

  var regexString = '([' + charsToEscape.replace(/([\[\]\\])/g, '\\$1') + '])';

  if (afterBackslash) {
    regexString = '\\\\' + regexString;
  }

  var regex = new RegExp(regexString, 'g');
  text = text.replace(regex, escapeCharactersCallback);

  return text;
};

var rgxFindMatchPos = function rgxFindMatchPos(str, left, right, flags) {
  'use strict';

  var f = flags || '',
      g = f.indexOf('g') > -1,
      x = new RegExp(left + '|' + right, 'g' + f.replace(/g/g, '')),
      l = new RegExp(left, f.replace(/g/g, '')),
      pos = [],
      t,
      s,
      m,
      start,
      end;

  do {
    t = 0;
    while (m = x.exec(str)) {
      if (l.test(m[0])) {
        if (!t++) {
          s = x.lastIndex;
          start = s - m[0].length;
        }
      } else if (t) {
        if (! --t) {
          end = m.index + m[0].length;
          var obj = {
            left: { start: start, end: s },
            match: { start: s, end: m.index },
            right: { start: m.index, end: end },
            wholeMatch: { start: start, end: end }
          };
          pos.push(obj);
          if (!g) {
            return pos;
          }
        }
      }
    }
  } while (t && (x.lastIndex = s));

  return pos;
};

/**
 * matchRecursiveRegExp
 *
 * (c) 2007 Steven Levithan <stevenlevithan.com>
 * MIT License
 *
 * Accepts a string to search, a left and right format delimiter
 * as regex patterns, and optional regex flags. Returns an array
 * of matches, allowing nested instances of left/right delimiters.
 * Use the "g" flag to return all matches, otherwise only the
 * first is returned. Be careful to ensure that the left and
 * right format delimiters produce mutually exclusive matches.
 * Backreferences are not supported within the right delimiter
 * due to how it is internally combined with the left delimiter.
 * When matching strings whose format delimiters are unbalanced
 * to the left or right, the output is intentionally as a
 * conventional regex library with recursion support would
 * produce, e.g. "<<x>" and "<x>>" both produce ["x"] when using
 * "<" and ">" as the delimiters (both strings contain a single,
 * balanced instance of "<x>").
 *
 * examples:
 * matchRecursiveRegExp("test", "\\(", "\\)")
 * returns: []
 * matchRecursiveRegExp("<t<<e>><s>>t<>", "<", ">", "g")
 * returns: ["t<<e>><s>", ""]
 * matchRecursiveRegExp("<div id=\"x\">test</div>", "<div\\b[^>]*>", "</div>", "gi")
 * returns: ["test"]
 */
showdown.helper.matchRecursiveRegExp = function (str, left, right, flags) {
  'use strict';

  var matchPos = rgxFindMatchPos(str, left, right, flags),
      results = [];

  for (var i = 0; i < matchPos.length; ++i) {
    results.push([str.slice(matchPos[i].wholeMatch.start, matchPos[i].wholeMatch.end), str.slice(matchPos[i].match.start, matchPos[i].match.end), str.slice(matchPos[i].left.start, matchPos[i].left.end), str.slice(matchPos[i].right.start, matchPos[i].right.end)]);
  }
  return results;
};

/**
 *
 * @param {string} str
 * @param {string|function} replacement
 * @param {string} left
 * @param {string} right
 * @param {string} flags
 * @returns {string}
 */
showdown.helper.replaceRecursiveRegExp = function (str, replacement, left, right, flags) {
  'use strict';

  if (!showdown.helper.isFunction(replacement)) {
    var repStr = replacement;
    replacement = function replacement() {
      return repStr;
    };
  }

  var matchPos = rgxFindMatchPos(str, left, right, flags),
      finalStr = str,
      lng = matchPos.length;

  if (lng > 0) {
    var bits = [];
    if (matchPos[0].wholeMatch.start !== 0) {
      bits.push(str.slice(0, matchPos[0].wholeMatch.start));
    }
    for (var i = 0; i < lng; ++i) {
      bits.push(replacement(str.slice(matchPos[i].wholeMatch.start, matchPos[i].wholeMatch.end), str.slice(matchPos[i].match.start, matchPos[i].match.end), str.slice(matchPos[i].left.start, matchPos[i].left.end), str.slice(matchPos[i].right.start, matchPos[i].right.end)));
      if (i < lng - 1) {
        bits.push(str.slice(matchPos[i].wholeMatch.end, matchPos[i + 1].wholeMatch.start));
      }
    }
    if (matchPos[lng - 1].wholeMatch.end < str.length) {
      bits.push(str.slice(matchPos[lng - 1].wholeMatch.end));
    }
    finalStr = bits.join('');
  }
  return finalStr;
};

/**
 * POLYFILLS
 */
if (showdown.helper.isUndefined(console)) {
  console = {
    warn: function warn(msg) {
      'use strict';

      alert(msg);
    },
    log: function log(msg) {
      'use strict';

      alert(msg);
    },
    error: function error(msg) {
      'use strict';

      throw msg;
    }
  };
}

/**
 * Created by Estevao on 31-05-2015.
 */

/**
 * Showdown Converter class
 * @class
 * @param {object} [converterOptions]
 * @returns {Converter}
 */
showdown.Converter = function (converterOptions) {
  'use strict';

  var
  /**
   * Options used by this converter
   * @private
   * @type {{}}
   */
  options = {},


  /**
   * Language extensions used by this converter
   * @private
   * @type {Array}
   */
  langExtensions = [],


  /**
   * Output modifiers extensions used by this converter
   * @private
   * @type {Array}
   */
  outputModifiers = [],


  /**
   * Event listeners
   * @private
   * @type {{}}
   */
  listeners = {};

  _constructor();

  /**
   * Converter constructor
   * @private
   */
  function _constructor() {
    converterOptions = converterOptions || {};

    for (var gOpt in globalOptions) {
      if (globalOptions.hasOwnProperty(gOpt)) {
        options[gOpt] = globalOptions[gOpt];
      }
    }

    // Merge options
    if ((typeof converterOptions === 'undefined' ? 'undefined' : _typeof(converterOptions)) === 'object') {
      for (var opt in converterOptions) {
        if (converterOptions.hasOwnProperty(opt)) {
          options[opt] = converterOptions[opt];
        }
      }
    } else {
      throw Error('Converter expects the passed parameter to be an object, but ' + (typeof converterOptions === 'undefined' ? 'undefined' : _typeof(converterOptions)) + ' was passed instead.');
    }

    if (options.extensions) {
      showdown.helper.forEach(options.extensions, _parseExtension);
    }
  }

  /**
   * Parse extension
   * @param {*} ext
   * @param {string} [name='']
   * @private
   */
  function _parseExtension(ext, name) {

    name = name || null;
    // If it's a string, the extension was previously loaded
    if (showdown.helper.isString(ext)) {
      ext = showdown.helper.stdExtName(ext);
      name = ext;

      // LEGACY_SUPPORT CODE
      if (showdown.extensions[ext]) {
        console.warn('DEPRECATION WARNING: ' + ext + ' is an old extension that uses a deprecated loading method.' + 'Please inform the developer that the extension should be updated!');
        legacyExtensionLoading(showdown.extensions[ext], ext);
        return;
        // END LEGACY SUPPORT CODE
      } else if (!showdown.helper.isUndefined(extensions[ext])) {
        ext = extensions[ext];
      } else {
        throw Error('Extension "' + ext + '" could not be loaded. It was either not found or is not a valid extension.');
      }
    }

    if (typeof ext === 'function') {
      ext = ext();
    }

    if (!showdown.helper.isArray(ext)) {
      ext = [ext];
    }

    var validExt = validate(ext, name);
    if (!validExt.valid) {
      throw Error(validExt.error);
    }

    for (var i = 0; i < ext.length; ++i) {
      switch (ext[i].type) {

        case 'lang':
          langExtensions.push(ext[i]);
          break;

        case 'output':
          outputModifiers.push(ext[i]);
          break;
      }
      if (ext[i].hasOwnProperty(listeners)) {
        for (var ln in ext[i].listeners) {
          if (ext[i].listeners.hasOwnProperty(ln)) {
            listen(ln, ext[i].listeners[ln]);
          }
        }
      }
    }
  }

  /**
   * LEGACY_SUPPORT
   * @param {*} ext
   * @param {string} name
   */
  function legacyExtensionLoading(ext, name) {
    if (typeof ext === 'function') {
      ext = ext(new showdown.Converter());
    }
    if (!showdown.helper.isArray(ext)) {
      ext = [ext];
    }
    var valid = validate(ext, name);

    if (!valid.valid) {
      throw Error(valid.error);
    }

    for (var i = 0; i < ext.length; ++i) {
      switch (ext[i].type) {
        case 'lang':
          langExtensions.push(ext[i]);
          break;
        case 'output':
          outputModifiers.push(ext[i]);
          break;
        default:
          // should never reach here
          throw Error('Extension loader error: Type unrecognized!!!');
      }
    }
  }

  /**
   * Listen to an event
   * @param {string} name
   * @param {function} callback
   */
  function listen(name, callback) {
    if (!showdown.helper.isString(name)) {
      throw Error('Invalid argument in converter.listen() method: name must be a string, but ' + (typeof name === 'undefined' ? 'undefined' : _typeof(name)) + ' given');
    }

    if (typeof callback !== 'function') {
      throw Error('Invalid argument in converter.listen() method: callback must be a function, but ' + (typeof callback === 'undefined' ? 'undefined' : _typeof(callback)) + ' given');
    }

    if (!listeners.hasOwnProperty(name)) {
      listeners[name] = [];
    }
    listeners[name].push(callback);
  }

  function rTrimInputText(text) {
    var rsp = text.match(/^\s*/)[0].length,
        rgx = new RegExp('^\\s{0,' + rsp + '}', 'gm');
    return text.replace(rgx, '');
  }

  /**
   * Dispatch an event
   * @private
   * @param {string} evtName Event name
   * @param {string} text Text
   * @param {{}} options Converter Options
   * @param {{}} globals
   * @returns {string}
   */
  this._dispatch = function dispatch(evtName, text, options, globals) {
    if (listeners.hasOwnProperty(evtName)) {
      for (var ei = 0; ei < listeners[evtName].length; ++ei) {
        var nText = listeners[evtName][ei](evtName, text, this, options, globals);
        if (nText && typeof nText !== 'undefined') {
          text = nText;
        }
      }
    }
    return text;
  };

  /**
   * Listen to an event
   * @param {string} name
   * @param {function} callback
   * @returns {showdown.Converter}
   */
  this.listen = function (name, callback) {
    listen(name, callback);
    return this;
  };

  /**
   * Converts a markdown string into HTML
   * @param {string} text
   * @returns {*}
   */
  this.makeHtml = function (text) {
    //check if text is not falsy
    if (!text) {
      return text;
    }

    var globals = {
      gHtmlBlocks: [],
      gHtmlMdBlocks: [],
      gHtmlSpans: [],
      gUrls: {},
      gTitles: {},
      gDimensions: {},
      gListLevel: 0,
      hashLinkCounts: {},
      langExtensions: langExtensions,
      outputModifiers: outputModifiers,
      converter: this,
      ghCodeBlocks: []
    };

    // attacklab: Replace ~ with ~T
    // This lets us use tilde as an escape char to avoid md5 hashes
    // The choice of character is arbitrary; anything that isn't
    // magic in Markdown will work.
    text = text.replace(/~/g, '~T');

    // attacklab: Replace $ with ~D
    // RegExp interprets $ as a special character
    // when it's in a replacement string
    text = text.replace(/\$/g, '~D');

    // Standardize line endings
    text = text.replace(/\r\n/g, '\n'); // DOS to Unix
    text = text.replace(/\r/g, '\n'); // Mac to Unix

    if (options.smartIndentationFix) {
      text = rTrimInputText(text);
    }

    // Make sure text begins and ends with a couple of newlines:
    //text = '\n\n' + text + '\n\n';
    text = text;
    // detab
    text = showdown.subParser('detab')(text, options, globals);

    // stripBlankLines
    text = showdown.subParser('stripBlankLines')(text, options, globals);

    //run languageExtensions
    showdown.helper.forEach(langExtensions, function (ext) {
      text = showdown.subParser('runExtension')(ext, text, options, globals);
    });

    // run the sub parsers
    text = showdown.subParser('hashPreCodeTags')(text, options, globals);
    text = showdown.subParser('githubCodeBlocks')(text, options, globals);
    text = showdown.subParser('hashHTMLBlocks')(text, options, globals);
    text = showdown.subParser('hashHTMLSpans')(text, options, globals);
    text = showdown.subParser('stripLinkDefinitions')(text, options, globals);
    text = showdown.subParser('blockGamut')(text, options, globals);
    text = showdown.subParser('unhashHTMLSpans')(text, options, globals);
    text = showdown.subParser('unescapeSpecialChars')(text, options, globals);

    // attacklab: Restore dollar signs
    text = text.replace(/~D/g, '$$');

    // attacklab: Restore tildes
    text = text.replace(/~T/g, '~');

    // Run output modifiers
    showdown.helper.forEach(outputModifiers, function (ext) {
      text = showdown.subParser('runExtension')(ext, text, options, globals);
    });
    return text;
  };

  /**
   * Set an option of this Converter instance
   * @param {string} key
   * @param {*} value
   */
  this.setOption = function (key, value) {
    options[key] = value;
  };

  /**
   * Get the option of this Converter instance
   * @param {string} key
   * @returns {*}
   */
  this.getOption = function (key) {
    return options[key];
  };

  /**
   * Get the options of this Converter instance
   * @returns {{}}
   */
  this.getOptions = function () {
    return options;
  };

  /**
   * Add extension to THIS converter
   * @param {{}} extension
   * @param {string} [name=null]
   */
  this.addExtension = function (extension, name) {
    name = name || null;
    _parseExtension(extension, name);
  };

  /**
   * Use a global registered extension with THIS converter
   * @param {string} extensionName Name of the previously registered extension
   */
  this.useExtension = function (extensionName) {
    _parseExtension(extensionName);
  };

  /**
   * Set the flavor THIS converter should use
   * @param {string} name
   */
  this.setFlavor = function (name) {
    if (flavor.hasOwnProperty(name)) {
      var preset = flavor[name];
      for (var option in preset) {
        if (preset.hasOwnProperty(option)) {
          options[option] = preset[option];
        }
      }
    }
  };

  /**
   * Remove an extension from THIS converter.
   * Note: This is a costly operation. It's better to initialize a new converter
   * and specify the extensions you wish to use
   * @param {Array} extension
   */
  this.removeExtension = function (extension) {
    if (!showdown.helper.isArray(extension)) {
      extension = [extension];
    }
    for (var a = 0; a < extension.length; ++a) {
      var ext = extension[a];
      for (var i = 0; i < langExtensions.length; ++i) {
        if (langExtensions[i] === ext) {
          langExtensions[i].splice(i, 1);
        }
      }
      for (var ii = 0; ii < outputModifiers.length; ++i) {
        if (outputModifiers[ii] === ext) {
          outputModifiers[ii].splice(i, 1);
        }
      }
    }
  };

  /**
   * Get all extension of THIS converter
   * @returns {{language: Array, output: Array}}
   */
  this.getAllExtensions = function () {
    return {
      language: langExtensions,
      output: outputModifiers
    };
  };
};

/**
 * Turn Markdown link shortcuts into XHTML <a> tags.
 */
showdown.subParser('anchors', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('anchors.before', text, options, globals);

  var writeAnchorTag = function writeAnchorTag(wholeMatch, m1, m2, m3, m4, m5, m6, m7) {
    if (showdown.helper.isUndefined(m7)) {
      m7 = '';
    }
    wholeMatch = m1;
    var linkText = m2,
        linkId = m3.toLowerCase(),
        url = m4,
        title = m7;

    if (!url) {
      if (!linkId) {
        // lower-case and turn embedded newlines into spaces
        linkId = linkText.toLowerCase().replace(/ ?\n/g, ' ');
      }
      url = '#' + linkId;

      if (!showdown.helper.isUndefined(globals.gUrls[linkId])) {
        url = globals.gUrls[linkId];
        if (!showdown.helper.isUndefined(globals.gTitles[linkId])) {
          title = globals.gTitles[linkId];
        }
      } else {
        if (wholeMatch.search(/\(\s*\)$/m) > -1) {
          // Special case for explicit empty url
          url = '';
        } else {
          return wholeMatch;
        }
      }
    }

    url = showdown.helper.escapeCharacters(url, '*_', false);
    var result = '<a href="' + url + '"';

    if (title !== '' && title !== null) {
      title = title.replace(/"/g, '&quot;');
      title = showdown.helper.escapeCharacters(title, '*_', false);
      result += ' title="' + title + '"';
    }

    result += '>' + linkText + '</a>';

    return result;
  };

  // First, handle reference-style links: [link text] [id]
  /*
   text = text.replace(/
   (							// wrap whole match in $1
   \[
   (
   (?:
   \[[^\]]*\]		// allow brackets nested one level
   |
   [^\[]			// or anything else
   )*
   )
   \]
    [ ]?					// one optional space
   (?:\n[ ]*)?				// one optional newline followed by spaces
    \[
   (.*?)					// id = $3
   \]
   )()()()()					// pad remaining backreferences
   /g,_DoAnchors_callback);
   */
  text = text.replace(/(\[((?:\[[^\]]*]|[^\[\]])*)][ ]?(?:\n[ ]*)?\[(.*?)])()()()()/g, writeAnchorTag);

  //
  // Next, inline-style links: [link text](url "optional title")
  //

  /*
   text = text.replace(/
   (						// wrap whole match in $1
   \[
   (
   (?:
   \[[^\]]*\]	// allow brackets nested one level
   |
   [^\[\]]			// or anything else
   )
   )
   \]
   \(						// literal paren
   [ \t]*
   ()						// no id, so leave $3 empty
   <?(.*?)>?				// href = $4
   [ \t]*
   (						// $5
   (['"])				// quote char = $6
   (.*?)				// Title = $7
   \6					// matching quote
   [ \t]*				// ignore any spaces/tabs between closing quote and )
   )?						// title is optional
   \)
   )
   /g,writeAnchorTag);
   */
  text = text.replace(/(\[((?:\[[^\]]*]|[^\[\]])*)]\([ \t]*()<?(.*?(?:\(.*?\).*?)?)>?[ \t]*((['"])(.*?)\6[ \t]*)?\))/g, writeAnchorTag);

  //
  // Last, handle reference-style shortcuts: [link text]
  // These must come last in case you've also got [link test][1]
  // or [link test](/foo)
  //

  /*
   text = text.replace(/
   (                // wrap whole match in $1
   \[
   ([^\[\]]+)       // link text = $2; can't contain '[' or ']'
   \]
   )()()()()()      // pad rest of backreferences
   /g, writeAnchorTag);
   */
  text = text.replace(/(\[([^\[\]]+)])()()()()()/g, writeAnchorTag);

  text = globals.converter._dispatch('anchors.after', text, options, globals);
  return text;
});

showdown.subParser('autoLinks', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('autoLinks.before', text, options, globals);

  var simpleURLRegex = /\b(((https?|ftp|dict):\/\/|www\.)[^'">\s]+\.[^'">\s]+)(?=\s|$)(?!["<>])/gi,
      delimUrlRegex = /<(((https?|ftp|dict):\/\/|www\.)[^'">\s]+)>/gi,
      simpleMailRegex = /(?:^|[ \n\t])([A-Za-z0-9!#$%&'*+-/=?^_`\{|}~\.]+@[-a-z0-9]+(\.[-a-z0-9]+)*\.[a-z]+)(?:$|[ \n\t])/gi,
      delimMailRegex = /<(?:mailto:)?([-.\w]+@[-a-z0-9]+(\.[-a-z0-9]+)*\.[a-z]+)>/gi;

  text = text.replace(delimUrlRegex, replaceLink);
  text = text.replace(delimMailRegex, replaceMail);
  // simpleURLRegex  = /\b(((https?|ftp|dict):\/\/|www\.)[-.+~:?#@!$&'()*,;=[\]\w]+)\b/gi,
  // Email addresses: <address@domain.foo>

  if (options.simplifiedAutoLink) {
    text = text.replace(simpleURLRegex, replaceLink);
    text = text.replace(simpleMailRegex, replaceMail);
  }

  function replaceLink(wm, link) {
    var lnkTxt = link;
    if (/^www\./i.test(link)) {
      link = link.replace(/^www\./i, 'http://www.');
    }
    return '<a href="' + link + '">' + lnkTxt + '</a>';
  }

  function replaceMail(wholeMatch, m1) {
    var unescapedStr = showdown.subParser('unescapeSpecialChars')(m1);
    return showdown.subParser('encodeEmailAddress')(unescapedStr);
  }

  text = globals.converter._dispatch('autoLinks.after', text, options, globals);

  return text;
});

/**
 * These are all the transformations that form block-level
 * tags like paragraphs, headers, and list items.
 */
showdown.subParser('blockGamut', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('blockGamut.before', text, options, globals);

  // we parse blockquotes first so that we can have headings and hrs
  // inside blockquotes
  text = showdown.subParser('blockQuotes')(text, options, globals);
  text = showdown.subParser('headers')(text, options, globals);

  // Do Horizontal Rules:
  var key = showdown.subParser('hashBlock')('<hr />', options, globals);
  text = text.replace(/^[ ]{0,2}([ ]?\*[ ]?){3,}[ \t]*$/gm, key);
  text = text.replace(/^[ ]{0,2}([ ]?\-[ ]?){3,}[ \t]*$/gm, key);
  text = text.replace(/^[ ]{0,2}([ ]?_[ ]?){3,}[ \t]*$/gm, key);

  text = showdown.subParser('lists')(text, options, globals);
  text = showdown.subParser('codeBlocks')(text, options, globals);
  text = showdown.subParser('tables')(text, options, globals);

  // We already ran _HashHTMLBlocks() before, in Markdown(), but that
  // was to escape raw HTML in the original Markdown source. This time,
  // we're escaping the markup we've just created, so that we don't wrap
  // <p> tags around block-level tags.
  text = showdown.subParser('hashHTMLBlocks')(text, options, globals);
  text = showdown.subParser('paragraphs')(text, options, globals);

  text = globals.converter._dispatch('blockGamut.after', text, options, globals);

  return text;
});

showdown.subParser('blockQuotes', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('blockQuotes.before', text, options, globals);
  /*
   text = text.replace(/
   (								// Wrap whole match in $1
   (
   ^[ \t]*>[ \t]?			// '>' at the start of a line
   .+\n					// rest of the first line
   (.+\n)*					// subsequent consecutive lines
   \n*						// blanks
   )+
   )
   /gm, function(){...});
   */

  text = text.replace(/((^[ \t]{0,3}>[ \t]?.+\n(.+\n)*\n*)+)/gm, function (wholeMatch, m1) {
    var bq = m1;

    // attacklab: hack around Konqueror 3.5.4 bug:
    // "----------bug".replace(/^-/g,"") == "bug"
    bq = bq.replace(/^[ \t]*>[ \t]?/gm, '~0'); // trim one level of quoting

    // attacklab: clean up hack
    bq = bq.replace(/~0/g, '');

    bq = bq.replace(/^[ \t]+$/gm, ''); // trim whitespace-only lines
    bq = showdown.subParser('githubCodeBlocks')(bq, options, globals);
    bq = showdown.subParser('blockGamut')(bq, options, globals); // recurse

    bq = bq.replace(/(^|\n)/g, '$1  ');
    // These leading spaces screw with <pre> content, so we need to fix that:
    bq = bq.replace(/(\s*<pre>[^\r]+?<\/pre>)/gm, function (wholeMatch, m1) {
      var pre = m1;
      // attacklab: hack around Konqueror 3.5.4 bug:
      pre = pre.replace(/^  /mg, '~0');
      pre = pre.replace(/~0/g, '');
      return pre;
    });

    return showdown.subParser('hashBlock')('<blockquote>\n' + bq + '\n</blockquote>', options, globals);
  });

  text = globals.converter._dispatch('blockQuotes.after', text, options, globals);
  return text;
});

/**
 * Process Markdown `<pre><code>` blocks.
 */
showdown.subParser('codeBlocks', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('codeBlocks.before', text, options, globals);
  /*
   text = text.replace(text,
   /(?:\n\n|^)
   (								// $1 = the code block -- one or more lines, starting with a space/tab
   (?:
   (?:[ ]{4}|\t)			// Lines must start with a tab or a tab-width of spaces - attacklab: g_tab_width
   .*\n+
   )+
   )
   (\n*[ ]{0,3}[^ \t\n]|(?=~0))	// attacklab: g_tab_width
   /g,function(){...});
   */

  // attacklab: sentinel workarounds for lack of \A and \Z, safari\khtml bug
  text += '~0';

  var pattern = /(?:\n\n|^)((?:(?:[ ]{4}|\t).*\n+)+)(\n*[ ]{0,3}[^ \t\n]|(?=~0))/g;
  text = text.replace(pattern, function (wholeMatch, m1, m2) {
    var codeblock = m1,
        nextChar = m2,
        end = '\n';

    codeblock = showdown.subParser('outdent')(codeblock);
    codeblock = showdown.subParser('encodeCode')(codeblock);
    codeblock = showdown.subParser('detab')(codeblock);
    codeblock = codeblock.replace(/^\n+/g, ''); // trim leading newlines
    codeblock = codeblock.replace(/\n+$/g, ''); // trim trailing newlines

    if (options.omitExtraWLInCodeBlocks) {
      end = '';
    }

    codeblock = '<pre><code>' + codeblock + end + '</code></pre>';

    return showdown.subParser('hashBlock')(codeblock, options, globals) + nextChar;
  });

  // attacklab: strip sentinel
  text = text.replace(/~0/, '');

  text = globals.converter._dispatch('codeBlocks.after', text, options, globals);
  return text;
});

/**
 *
 *   *  Backtick quotes are used for <code></code> spans.
 *
 *   *  You can use multiple backticks as the delimiters if you want to
 *     include literal backticks in the code span. So, this input:
 *
 *         Just type ``foo `bar` baz`` at the prompt.
 *
 *       Will translate to:
 *
 *         <p>Just type <code>foo `bar` baz</code> at the prompt.</p>
 *
 *    There's no arbitrary limit to the number of backticks you
 *    can use as delimters. If you need three consecutive backticks
 *    in your code, use four for delimiters, etc.
 *
 *  *  You can use spaces to get literal backticks at the edges:
 *
 *         ... type `` `bar` `` ...
 *
 *       Turns to:
 *
 *         ... type <code>`bar`</code> ...
 */
showdown.subParser('codeSpans', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('codeSpans.before', text, options, globals);

  /*
   text = text.replace(/
   (^|[^\\])					// Character before opening ` can't be a backslash
   (`+)						// $2 = Opening run of `
   (							// $3 = The code block
   [^\r]*?
   [^`]					// attacklab: work around lack of lookbehind
   )
   \2							// Matching closer
   (?!`)
   /gm, function(){...});
   */

  if (typeof text === 'undefined') {
    text = '';
  }
  text = text.replace(/(^|[^\\])(`+)([^\r]*?[^`])\2(?!`)/gm, function (wholeMatch, m1, m2, m3) {
    var c = m3;
    c = c.replace(/^([ \t]*)/g, ''); // leading whitespace
    c = c.replace(/[ \t]*$/g, ''); // trailing whitespace
    c = showdown.subParser('encodeCode')(c);
    return m1 + '<code>' + c + '</code>';
  });

  text = globals.converter._dispatch('codeSpans.after', text, options, globals);
  return text;
});

/**
 * Convert all tabs to spaces
 */
showdown.subParser('detab', function (text) {
  'use strict';

  // expand first n-1 tabs

  text = text.replace(/\t(?=\t)/g, '    '); // g_tab_width

  // replace the nth with two sentinels
  text = text.replace(/\t/g, '~A~B');

  // use the sentinel to anchor our regex so it doesn't explode
  text = text.replace(/~B(.+?)~A/g, function (wholeMatch, m1) {
    var leadingText = m1,
        numSpaces = 4 - leadingText.length % 4; // g_tab_width

    // there *must* be a better way to do this:
    for (var i = 0; i < numSpaces; i++) {
      leadingText += ' ';
    }

    return leadingText;
  });

  // clean up sentinels
  text = text.replace(/~A/g, '    '); // g_tab_width
  text = text.replace(/~B/g, '');

  return text;
});

/**
 * Smart processing for ampersands and angle brackets that need to be encoded.
 */
showdown.subParser('encodeAmpsAndAngles', function (text) {
  'use strict';
  // Ampersand-encoding based entirely on Nat Irons's Amputator MT plugin:
  // http://bumppo.net/projects/amputator/

  text = text.replace(/&(?!#?[xX]?(?:[0-9a-fA-F]+|\w+);)/g, '&amp;');

  // Encode naked <'s
  text = text.replace(/<(?![a-z\/?\$!])/gi, '&lt;');

  return text;
});

/**
 * Returns the string, with after processing the following backslash escape sequences.
 *
 * attacklab: The polite way to do this is with the new escapeCharacters() function:
 *
 *    text = escapeCharacters(text,"\\",true);
 *    text = escapeCharacters(text,"`*_{}[]()>#+-.!",true);
 *
 * ...but we're sidestepping its use of the (slow) RegExp constructor
 * as an optimization for Firefox.  This function gets called a LOT.
 */
showdown.subParser('encodeBackslashEscapes', function (text) {
  'use strict';

  text = text.replace(/\\(\\)/g, showdown.helper.escapeCharactersCallback);
  text = text.replace(/\\([`*_{}\[\]()>#+-.!])/g, showdown.helper.escapeCharactersCallback);
  return text;
});

/**
 * Encode/escape certain characters inside Markdown code runs.
 * The point is that in code, these characters are literals,
 * and lose their special Markdown meanings.
 */
showdown.subParser('encodeCode', function (text) {
  'use strict';

  // Encode all ampersands; HTML entities are not
  // entities within a Markdown code span.

  text = text.replace(/&/g, '&amp;');

  // Do the angle bracket song and dance:
  text = text.replace(/</g, '&lt;');
  text = text.replace(/>/g, '&gt;');

  // Now, escape characters that are magic in Markdown:
  text = showdown.helper.escapeCharacters(text, '*_{}[]\\', false);

  // jj the line above breaks this:
  //---
  //* Item
  //   1. Subitem
  //            special char: *
  // ---

  return text;
});

/**
 *  Input: an email address, e.g. "foo@example.com"
 *
 *  Output: the email address as a mailto link, with each character
 *    of the address encoded as either a decimal or hex entity, in
 *    the hopes of foiling most address harvesting spam bots. E.g.:
 *
 *    <a href="&#x6D;&#97;&#105;&#108;&#x74;&#111;:&#102;&#111;&#111;&#64;&#101;
 *       x&#x61;&#109;&#x70;&#108;&#x65;&#x2E;&#99;&#111;&#109;">&#102;&#111;&#111;
 *       &#64;&#101;x&#x61;&#109;&#x70;&#108;&#x65;&#x2E;&#99;&#111;&#109;</a>
 *
 *  Based on a filter by Matthew Wickline, posted to the BBEdit-Talk
 *  mailing list: <http://tinyurl.com/yu7ue>
 *
 */
showdown.subParser('encodeEmailAddress', function (addr) {
  'use strict';

  var encode = [function (ch) {
    return '&#' + ch.charCodeAt(0) + ';';
  }, function (ch) {
    return '&#x' + ch.charCodeAt(0).toString(16) + ';';
  }, function (ch) {
    return ch;
  }];

  addr = 'mailto:' + addr;

  addr = addr.replace(/./g, function (ch) {
    if (ch === '@') {
      // this *must* be encoded. I insist.
      ch = encode[Math.floor(Math.random() * 2)](ch);
    } else if (ch !== ':') {
      // leave ':' alone (to spot mailto: later)
      var r = Math.random();
      // roughly 10% raw, 45% hex, 45% dec
      ch = r > 0.9 ? encode[2](ch) : r > 0.45 ? encode[1](ch) : encode[0](ch);
    }
    return ch;
  });

  addr = '<a href="' + addr + '">' + addr + '</a>';
  addr = addr.replace(/">.+:/g, '">'); // strip the mailto: from the visible part

  return addr;
});

/**
 * Within tags -- meaning between < and > -- encode [\ ` * _] so they
 * don't conflict with their use in Markdown for code, italics and strong.
 */
showdown.subParser('escapeSpecialCharsWithinTagAttributes', function (text) {
  'use strict';

  // Build a regex to find HTML tags and comments.  See Friedl's
  // "Mastering Regular Expressions", 2nd Ed., pp. 200-201.

  var regex = /(<[a-z\/!$]("[^"]*"|'[^']*'|[^'">])*>|<!(--.*?--\s*)+>)/gi;

  text = text.replace(regex, function (wholeMatch) {
    var tag = wholeMatch.replace(/(.)<\/?code>(?=.)/g, '$1`');
    tag = showdown.helper.escapeCharacters(tag, '\\`*_', false);
    return tag;
  });

  return text;
});

/**
 * Handle github codeblocks prior to running HashHTML so that
 * HTML contained within the codeblock gets escaped properly
 * Example:
 * ```ruby
 *     def hello_world(x)
 *       puts "Hello, #{x}"
 *     end
 * ```
 */
showdown.subParser('githubCodeBlocks', function (text, options, globals) {
  'use strict';

  // early exit if option is not enabled

  if (!options.ghCodeBlocks) {
    return text;
  }

  text = globals.converter._dispatch('githubCodeBlocks.before', text, options, globals);

  text += '~0';

  text = text.replace(/(?:^|\n)```(.*)\n([\s\S]*?)\n```/g, function (wholeMatch, language, codeblock) {
    var end = options.omitExtraWLInCodeBlocks ? '' : '\n';

    // First parse the github code block
    codeblock = showdown.subParser('encodeCode')(codeblock);
    codeblock = showdown.subParser('detab')(codeblock);
    codeblock = codeblock.replace(/^\n+/g, ''); // trim leading newlines
    codeblock = codeblock.replace(/\n+$/g, ''); // trim trailing whitespace

    codeblock = '<pre><code' + (language ? ' class="' + language + ' language-' + language + '"' : '') + '>' + codeblock + end + '</code></pre>';

    codeblock = showdown.subParser('hashBlock')(codeblock, options, globals);

    // Since GHCodeblocks can be false positives, we need to
    // store the primitive text and the parsed text in a global var,
    // and then return a token
    return '\n\n~G' + (globals.ghCodeBlocks.push({ text: wholeMatch, codeblock: codeblock }) - 1) + 'G\n\n';
  });

  // attacklab: strip sentinel
  text = text.replace(/~0/, '');

  return globals.converter._dispatch('githubCodeBlocks.after', text, options, globals);
});

showdown.subParser('hashBlock', function (text, options, globals) {
  'use strict';

  text = text.replace(/(^\n+|\n+$)/g, '');
  return '\n\n~K' + (globals.gHtmlBlocks.push(text) - 1) + 'K\n\n';
});

showdown.subParser('hashElement', function (text, options, globals) {
  'use strict';

  return function (wholeMatch, m1) {
    var blockText = m1;

    // Undo double lines
    blockText = blockText.replace(/\n\n/g, '\n');
    blockText = blockText.replace(/^\n/, '');

    // strip trailing blank lines
    blockText = blockText.replace(/\n+$/g, '');

    // Replace the element text with a marker ("~KxK" where x is its key)
    blockText = '\n\n~K' + (globals.gHtmlBlocks.push(blockText) - 1) + 'K\n\n';

    return blockText;
  };
});

showdown.subParser('hashHTMLBlocks', function (text, options, globals) {
  'use strict';

  var blockTags = ['pre', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'table', 'dl', 'ol', 'ul', 'script', 'noscript', 'form', 'fieldset', 'iframe', 'math', 'style', 'section', 'header', 'footer', 'nav', 'article', 'aside', 'address', 'audio', 'canvas', 'figure', 'hgroup', 'output', 'video', 'p'],
      repFunc = function repFunc(wholeMatch, match, left, right) {
    var txt = wholeMatch;
    // check if this html element is marked as markdown
    // if so, it's contents should be parsed as markdown
    if (left.search(/\bmarkdown\b/) !== -1) {
      txt = left + globals.converter.makeHtml(match) + right;
    }
    return '\n\n~K' + (globals.gHtmlBlocks.push(txt) - 1) + 'K\n\n';
  };

  for (var i = 0; i < blockTags.length; ++i) {
    text = showdown.helper.replaceRecursiveRegExp(text, repFunc, '^(?: |\\t){0,3}<' + blockTags[i] + '\\b[^>]*>', '</' + blockTags[i] + '>', 'gim');
  }

  // HR SPECIAL CASE
  text = text.replace(/(\n[ ]{0,3}(<(hr)\b([^<>])*?\/?>)[ \t]*(?=\n{2,}))/g, showdown.subParser('hashElement')(text, options, globals));

  // Special case for standalone HTML comments:
  text = text.replace(/(<!--[\s\S]*?-->)/g, showdown.subParser('hashElement')(text, options, globals));

  // PHP and ASP-style processor instructions (<?...?> and <%...%>)
  text = text.replace(/(?:\n\n)([ ]{0,3}(?:<([?%])[^\r]*?\2>)[ \t]*(?=\n{2,}))/g, showdown.subParser('hashElement')(text, options, globals));
  return text;
});

/**
 * Hash span elements that should not be parsed as markdown
 */
showdown.subParser('hashHTMLSpans', function (text, config, globals) {
  'use strict';

  var matches = showdown.helper.matchRecursiveRegExp(text, '<code\\b[^>]*>', '</code>', 'gi');

  for (var i = 0; i < matches.length; ++i) {
    text = text.replace(matches[i][0], '~L' + (globals.gHtmlSpans.push(matches[i][0]) - 1) + 'L');
  }
  return text;
});

/**
 * Unhash HTML spans
 */
showdown.subParser('unhashHTMLSpans', function (text, config, globals) {
  'use strict';

  for (var i = 0; i < globals.gHtmlSpans.length; ++i) {
    text = text.replace('~L' + i + 'L', globals.gHtmlSpans[i]);
  }

  return text;
});

/**
 * Hash span elements that should not be parsed as markdown
 */
showdown.subParser('hashPreCodeTags', function (text, config, globals) {
  'use strict';

  var repFunc = function repFunc(wholeMatch, match, left, right) {
    // encode html entities
    var codeblock = left + showdown.subParser('encodeCode')(match) + right;
    return '\n\n~G' + (globals.ghCodeBlocks.push({ text: wholeMatch, codeblock: codeblock }) - 1) + 'G\n\n';
  };

  text = showdown.helper.replaceRecursiveRegExp(text, repFunc, '^(?: |\\t){0,3}<pre\\b[^>]*>\\s*<code\\b[^>]*>', '^(?: |\\t){0,3}</code>\\s*</pre>', 'gim');
  return text;
});

showdown.subParser('headers', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('headers.before', text, options, globals);

  var prefixHeader = options.prefixHeaderId,
      headerLevelStart = isNaN(parseInt(options.headerLevelStart)) ? 1 : parseInt(options.headerLevelStart),


  // Set text-style headers:
  //	Header 1
  //	========
  //
  //	Header 2
  //	--------
  //
  setextRegexH1 = options.smoothLivePreview ? /^(.+)[ \t]*\n={2,}[ \t]*\n+/gm : /^(.+)[ \t]*\n=+[ \t]*\n+/gm,
      setextRegexH2 = options.smoothLivePreview ? /^(.+)[ \t]*\n-{2,}[ \t]*\n+/gm : /^(.+)[ \t]*\n-+[ \t]*\n+/gm;

  text = text.replace(setextRegexH1, function (wholeMatch, m1) {

    var spanGamut = showdown.subParser('spanGamut')(m1, options, globals),
        hID = options.noHeaderId ? '' : ' id="' + headerId(m1) + '"',
        hLevel = headerLevelStart,
        hashBlock = '<h' + hLevel + hID + '>' + spanGamut + '</h' + hLevel + '>';
    return showdown.subParser('hashBlock')(hashBlock, options, globals);
  });

  text = text.replace(setextRegexH2, function (matchFound, m1) {
    var spanGamut = showdown.subParser('spanGamut')(m1, options, globals),
        hID = options.noHeaderId ? '' : ' id="' + headerId(m1) + '"',
        hLevel = headerLevelStart + 1,
        hashBlock = '<h' + hLevel + hID + '>' + spanGamut + '</h' + hLevel + '>';
    return showdown.subParser('hashBlock')(hashBlock, options, globals);
  });

  // atx-style headers:
  //  # Header 1
  //  ## Header 2
  //  ## Header 2 with closing hashes ##
  //  ...
  //  ###### Header 6
  //
  text = text.replace(/^(#{1,6})[ \t]*(.+?)[ \t]*#*\n+/gm, function (wholeMatch, m1, m2) {
    var span = showdown.subParser('spanGamut')(m2, options, globals),
        hID = options.noHeaderId ? '' : ' id="' + headerId(m2) + '"',
        hLevel = headerLevelStart - 1 + m1.length,
        header = '<h' + hLevel + hID + '>' + span + '</h' + hLevel + '>';

    return showdown.subParser('hashBlock')(header, options, globals);
  });

  function headerId(m) {
    var title,
        escapedId = m.replace(/[^\w]/g, '').toLowerCase();

    if (globals.hashLinkCounts[escapedId]) {
      title = escapedId + '-' + globals.hashLinkCounts[escapedId]++;
    } else {
      title = escapedId;
      globals.hashLinkCounts[escapedId] = 1;
    }

    // Prefix id to prevent causing inadvertent pre-existing style matches.
    if (prefixHeader === true) {
      prefixHeader = 'section';
    }

    if (showdown.helper.isString(prefixHeader)) {
      return prefixHeader + title;
    }
    return title;
  }

  text = globals.converter._dispatch('headers.after', text, options, globals);
  return text;
});

/**
 * Turn Markdown image shortcuts into <img> tags.
 */
showdown.subParser('images', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('images.before', text, options, globals);

  var inlineRegExp = /!\[(.*?)]\s?\([ \t]*()<?(\S+?)>?(?: =([*\d]+[A-Za-z%]{0,4})x([*\d]+[A-Za-z%]{0,4}))?[ \t]*(?:(['"])(.*?)\6[ \t]*)?\)/g,
      referenceRegExp = /!\[([^\]]*?)] ?(?:\n *)?\[(.*?)]()()()()()/g;

  function writeImageTag(wholeMatch, altText, linkId, url, width, height, m5, title) {

    var gUrls = globals.gUrls,
        gTitles = globals.gTitles,
        gDims = globals.gDimensions;

    linkId = linkId.toLowerCase();

    if (!title) {
      title = '';
    }

    if (url === '' || url === null) {
      if (linkId === '' || linkId === null) {
        // lower-case and turn embedded newlines into spaces
        linkId = altText.toLowerCase().replace(/ ?\n/g, ' ');
      }
      url = '#' + linkId;

      if (!showdown.helper.isUndefined(gUrls[linkId])) {
        url = gUrls[linkId];
        if (!showdown.helper.isUndefined(gTitles[linkId])) {
          title = gTitles[linkId];
        }
        if (!showdown.helper.isUndefined(gDims[linkId])) {
          width = gDims[linkId].width;
          height = gDims[linkId].height;
        }
      } else {
        return wholeMatch;
      }
    }

    altText = altText.replace(/"/g, '&quot;');
    altText = showdown.helper.escapeCharacters(altText, '*_', false);
    url = showdown.helper.escapeCharacters(url, '*_', false);
    var result = '<img src="' + url + '" alt="' + altText + '"';

    if (title) {
      title = title.replace(/"/g, '&quot;');
      title = showdown.helper.escapeCharacters(title, '*_', false);
      result += ' title="' + title + '"';
    }

    if (width && height) {
      width = width === '*' ? 'auto' : width;
      height = height === '*' ? 'auto' : height;

      result += ' width="' + width + '"';
      result += ' height="' + height + '"';
    }

    result += ' />';
    return result;
  }

  // First, handle reference-style labeled images: ![alt text][id]
  text = text.replace(referenceRegExp, writeImageTag);

  // Next, handle inline images:  ![alt text](url =<width>x<height> "optional title")
  text = text.replace(inlineRegExp, writeImageTag);

  text = globals.converter._dispatch('images.after', text, options, globals);
  return text;
});

showdown.subParser('italicsAndBold', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('italicsAndBold.before', text, options, globals);

  if (options.literalMidWordUnderscores) {
    //underscores
    // Since we are consuming a \s character, we need to add it
    text = text.replace(/(^|\s|>|\b)__(?=\S)([\s\S]+?)__(?=\b|<|\s|$)/gm, '$1<strong>$2</strong>');
    text = text.replace(/(^|\s|>|\b)_(?=\S)([\s\S]+?)_(?=\b|<|\s|$)/gm, '$1<em>$2</em>');
    //asterisks
    text = text.replace(/(\*\*)(?=\S)([^\r]*?\S[*]*)\1/g, '<strong>$2</strong>');
    text = text.replace(/(\*)(?=\S)([^\r]*?\S)\1/g, '<em>$2</em>');
  } else {
    // <strong> must go first:
    text = text.replace(/(\*\*|__)(?=\S)([^\r]*?\S[*_]*)\1/g, '<strong>$2</strong>');
    text = text.replace(/(\*|_)(?=\S)([^\r]*?\S)\1/g, '<em>$2</em>');
  }

  text = globals.converter._dispatch('italicsAndBold.after', text, options, globals);
  return text;
});

/**
 * Form HTML ordered (numbered) and unordered (bulleted) lists.
 */
showdown.subParser('lists', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('lists.before', text, options, globals);
  /**
   * Process the contents of a single ordered or unordered list, splitting it
   * into individual list items.
   * @param {string} listStr
   * @param {boolean} trimTrailing
   * @returns {string}
   */
  function processListItems(listStr, trimTrailing) {
    // The $g_list_level global keeps track of when we're inside a list.
    // Each time we enter a list, we increment it; when we leave a list,
    // we decrement. If it's zero, we're not in a list anymore.
    //
    // We do this because when we're not inside a list, we want to treat
    // something like this:
    //
    //    I recommend upgrading to version
    //    8. Oops, now this line is treated
    //    as a sub-list.
    //
    // As a single paragraph, despite the fact that the second line starts
    // with a digit-period-space sequence.
    //
    // Whereas when we're inside a list (or sub-list), that line will be
    // treated as the start of a sub-list. What a kludge, huh? This is
    // an aspect of Markdown's syntax that's hard to parse perfectly
    // without resorting to mind-reading. Perhaps the solution is to
    // change the syntax rules such that sub-lists must start with a
    // starting cardinal number; e.g. "1." or "a.".
    globals.gListLevel++;

    // trim trailing blank lines:
    listStr = listStr.replace(/\n{2,}$/, '\n');

    // attacklab: add sentinel to emulate \z
    listStr += '~0';

    var rgx = /(\n)?(^[ \t]*)([*+-]|\d+[.])[ \t]+((\[(x|X| )?])?[ \t]*[^\r]+?(\n{1,2}))(?=\n*(~0|\2([*+-]|\d+[.])[ \t]+))/gm,
        isParagraphed = /\n[ \t]*\n(?!~0)/.test(listStr);

    listStr = listStr.replace(rgx, function (wholeMatch, m1, m2, m3, m4, taskbtn, checked) {
      checked = checked && checked.trim() !== '';
      var item = showdown.subParser('outdent')(m4, options, globals),
          bulletStyle = '';

      // Support for github tasklists
      if (taskbtn && options.tasklists) {
        bulletStyle = ' class="task-list-item" style="list-style-type: none;"';
        item = item.replace(/^[ \t]*\[(x|X| )?]/m, function () {
          var otp = '<input type="checkbox" disabled style="margin: 0px 0.35em 0.25em -1.6em; vertical-align: middle;"';
          if (checked) {
            otp += ' checked';
          }
          otp += '>';
          return otp;
        });
      }
      // m1 - Leading line or
      // Has a double return (multi paragraph) or
      // Has sublist
      if (m1 || item.search(/\n{2,}/) > -1) {
        item = showdown.subParser('githubCodeBlocks')(item, options, globals);
        item = showdown.subParser('blockGamut')(item, options, globals);
      } else {
        // Recursion for sub-lists:
        item = showdown.subParser('lists')(item, options, globals);
        item = item.replace(/\n$/, ''); // chomp(item)
        if (isParagraphed) {
          item = showdown.subParser('paragraphs')(item, options, globals);
        } else {
          item = showdown.subParser('spanGamut')(item, options, globals);
        }
      }
      item = '\n<li' + bulletStyle + '>' + item + '</li>\n';
      return item;
    });

    // attacklab: strip sentinel
    listStr = listStr.replace(/~0/g, '');

    globals.gListLevel--;

    if (trimTrailing) {
      listStr = listStr.replace(/\s+$/, '');
    }

    return listStr;
  }

  /**
   * Check and parse consecutive lists (better fix for issue #142)
   * @param {string} list
   * @param {string} listType
   * @param {boolean} trimTrailing
   * @returns {string}
   */
  function parseConsecutiveLists(list, listType, trimTrailing) {
    // check if we caught 2 or more consecutive lists by mistake
    // we use the counterRgx, meaning if listType is UL we look for UL and vice versa
    var counterRxg = listType === 'ul' ? /^ {0,2}\d+\.[ \t]/gm : /^ {0,2}[*+-][ \t]/gm,
        subLists = [],
        result = '';

    if (list.search(counterRxg) !== -1) {
      (function parseCL(txt) {
        var pos = txt.search(counterRxg);
        if (pos !== -1) {
          // slice
          result += '\n\n<' + listType + '>' + processListItems(txt.slice(0, pos), !!trimTrailing) + '</' + listType + '>\n\n';

          // invert counterType and listType
          listType = listType === 'ul' ? 'ol' : 'ul';
          counterRxg = listType === 'ul' ? /^ {0,2}\d+\.[ \t]/gm : /^ {0,2}[*+-][ \t]/gm;

          //recurse
          parseCL(txt.slice(pos));
        } else {
          result += '\n\n<' + listType + '>' + processListItems(txt, !!trimTrailing) + '</' + listType + '>\n\n';
        }
      })(list);
      for (var i = 0; i < subLists.length; ++i) {}
    } else {
      result = '\n\n<' + listType + '>' + processListItems(list, !!trimTrailing) + '</' + listType + '>\n\n';
    }

    return result;
  }

  // attacklab: add sentinel to hack around khtml/safari bug:
  // http://bugs.webkit.org/show_bug.cgi?id=11231
  text += '~0';

  // Re-usable pattern to match any entire ul or ol list:
  var wholeList = /^(([ ]{0,3}([*+-]|\d+[.])[ \t]+)[^\r]+?(~0|\n{2,}(?=\S)(?![ \t]*(?:[*+-]|\d+[.])[ \t]+)))/gm;

  if (globals.gListLevel) {
    text = text.replace(wholeList, function (wholeMatch, list, m2) {
      var listType = m2.search(/[*+-]/g) > -1 ? 'ul' : 'ol';
      return parseConsecutiveLists(list, listType, true);
    });
  } else {
    wholeList = /(\n\n|^\n?)(([ ]{0,3}([*+-]|\d+[.])[ \t]+)[^\r]+?(~0|\n{2,}(?=\S)(?![ \t]*(?:[*+-]|\d+[.])[ \t]+)))/gm;
    //wholeList = /(\n\n|^\n?)( {0,3}([*+-]|\d+\.)[ \t]+[\s\S]+?)(?=(~0)|(\n\n(?!\t| {2,}| {0,3}([*+-]|\d+\.)[ \t])))/g;
    text = text.replace(wholeList, function (wholeMatch, m1, list, m3) {

      var listType = m3.search(/[*+-]/g) > -1 ? 'ul' : 'ol';
      return parseConsecutiveLists(list, listType);
    });
  }

  // attacklab: strip sentinel
  text = text.replace(/~0/, '');

  text = globals.converter._dispatch('lists.after', text, options, globals);
  return text;
});

/**
 * Remove one level of line-leading tabs or spaces
 */
showdown.subParser('outdent', function (text) {
  'use strict';

  // attacklab: hack around Konqueror 3.5.4 bug:
  // "----------bug".replace(/^-/g,"") == "bug"

  text = text.replace(/^(\t|[ ]{1,4})/gm, '~0'); // attacklab: g_tab_width

  // attacklab: clean up hack
  text = text.replace(/~0/g, '');

  return text;
});

/**
 *
 */
showdown.subParser('paragraphs', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('paragraphs.before', text, options, globals);
  // Strip leading and trailing lines:
  text = text.replace(/^\n+/g, '');
  text = text.replace(/\n+$/g, '');

  var grafs = text.split(/\n{2,}/g),
      grafsOut = [],
      end = grafs.length; // Wrap <p> tags

  for (var i = 0; i < end; i++) {
    var str = grafs[i];
    // if this is an HTML marker, copy it
    if (str.search(/~(K|G)(\d+)\1/g) >= 0) {
      grafsOut.push(str);
    } else {
      str = showdown.subParser('spanGamut')(str, options, globals);
      str = str.replace(/^([ \t]*)/g, '<p>');
      str += '</p>';
      grafsOut.push(str);
    }
  }

  /** Unhashify HTML blocks */
  end = grafsOut.length;
  for (i = 0; i < end; i++) {
    var blockText = '',
        grafsOutIt = grafsOut[i],
        codeFlag = false;
    // if this is a marker for an html block...
    while (grafsOutIt.search(/~(K|G)(\d+)\1/) >= 0) {
      var delim = RegExp.$1,
          num = RegExp.$2;

      if (delim === 'K') {
        blockText = globals.gHtmlBlocks[num];
      } else {
        // we need to check if ghBlock is a false positive
        if (codeFlag) {
          // use encoded version of all text
          blockText = showdown.subParser('encodeCode')(globals.ghCodeBlocks[num].text);
        } else {
          blockText = globals.ghCodeBlocks[num].codeblock;
        }
      }
      blockText = blockText.replace(/\$/g, '$$$$'); // Escape any dollar signs

      grafsOutIt = grafsOutIt.replace(/(\n\n)?~(K|G)\d+\2(\n\n)?/, blockText);
      // Check if grafsOutIt is a pre->code
      if (/^<pre\b[^>]*>\s*<code\b[^>]*>/.test(grafsOutIt)) {
        codeFlag = true;
      }
    }
    grafsOut[i] = grafsOutIt;
  }
  text = grafsOut.join('\n\n');
  // Strip leading and trailing lines:
  text = text.replace(/^\n+/g, '');
  text = text.replace(/\n+$/g, '');
  return globals.converter._dispatch('paragraphs.after', text, options, globals);
});

/**
 * Run extension
 */
showdown.subParser('runExtension', function (ext, text, options, globals) {
  'use strict';

  if (ext.filter) {
    text = ext.filter(text, globals.converter, options);
  } else if (ext.regex) {
    // TODO remove this when old extension loading mechanism is deprecated
    var re = ext.regex;
    if (!re instanceof RegExp) {
      re = new RegExp(re, 'g');
    }
    text = text.replace(re, ext.replace);
  }

  return text;
});

/**
 * These are all the transformations that occur *within* block-level
 * tags like paragraphs, headers, and list items.
 */
showdown.subParser('spanGamut', function (text, options, globals) {
  'use strict';

  text = globals.converter._dispatch('spanGamut.before', text, options, globals);
  text = showdown.subParser('codeSpans')(text, options, globals);
  text = showdown.subParser('escapeSpecialCharsWithinTagAttributes')(text, options, globals);
  text = showdown.subParser('encodeBackslashEscapes')(text, options, globals);

  // Process anchor and image tags. Images must come first,
  // because ![foo][f] looks like an anchor.
  text = showdown.subParser('images')(text, options, globals);
  text = showdown.subParser('anchors')(text, options, globals);

  // Make links out of things like `<http://example.com/>`
  // Must come after _DoAnchors(), because you can use < and >
  // delimiters in inline links like [this](<url>).
  text = showdown.subParser('autoLinks')(text, options, globals);
  text = showdown.subParser('encodeAmpsAndAngles')(text, options, globals);
  text = showdown.subParser('italicsAndBold')(text, options, globals);
  text = showdown.subParser('strikethrough')(text, options, globals);

  // Do hard breaks:
  text = text.replace(/  +\n/g, ' <br />\n');

  text = globals.converter._dispatch('spanGamut.after', text, options, globals);
  return text;
});

showdown.subParser('strikethrough', function (text, options, globals) {
  'use strict';

  if (options.strikethrough) {
    text = globals.converter._dispatch('strikethrough.before', text, options, globals);
    text = text.replace(/(?:~T){2}([\s\S]+?)(?:~T){2}/g, '<del>$1</del>');
    text = globals.converter._dispatch('strikethrough.after', text, options, globals);
  }

  return text;
});

/**
 * Strip any lines consisting only of spaces and tabs.
 * This makes subsequent regexs easier to write, because we can
 * match consecutive blank lines with /\n+/ instead of something
 * contorted like /[ \t]*\n+/
 */
showdown.subParser('stripBlankLines', function (text) {
  'use strict';

  return text.replace(/^[ \t]+$/mg, '');
});

/**
 * Strips link definitions from text, stores the URLs and titles in
 * hash references.
 * Link defs are in the form: ^[id]: url "optional title"
 *
 * ^[ ]{0,3}\[(.+)\]: // id = $1  attacklab: g_tab_width - 1
 * [ \t]*
 * \n?                  // maybe *one* newline
 * [ \t]*
 * <?(\S+?)>?          // url = $2
 * [ \t]*
 * \n?                // maybe one newline
 * [ \t]*
 * (?:
 * (\n*)              // any lines skipped = $3 attacklab: lookbehind removed
 * ["(]
 * (.+?)              // title = $4
 * [")]
 * [ \t]*
 * )?                 // title is optional
 * (?:\n+|$)
 * /gm,
 * function(){...});
 *
 */
showdown.subParser('stripLinkDefinitions', function (text, options, globals) {
  'use strict';

  var regex = /^ {0,3}\[(.+)]:[ \t]*\n?[ \t]*<?(\S+?)>?(?: =([*\d]+[A-Za-z%]{0,4})x([*\d]+[A-Za-z%]{0,4}))?[ \t]*\n?[ \t]*(?:(\n*)["|'(](.+?)["|')][ \t]*)?(?:\n+|(?=~0))/gm;

  // attacklab: sentinel workarounds for lack of \A and \Z, safari\khtml bug
  text += '~0';

  text = text.replace(regex, function (wholeMatch, linkId, url, width, height, blankLines, title) {
    linkId = linkId.toLowerCase();
    globals.gUrls[linkId] = showdown.subParser('encodeAmpsAndAngles')(url); // Link IDs are case-insensitive

    if (blankLines) {
      // Oops, found blank lines, so it's not a title.
      // Put back the parenthetical statement we stole.
      return blankLines + title;
    } else {
      if (title) {
        globals.gTitles[linkId] = title.replace(/"|'/g, '&quot;');
      }
      if (options.parseImgDimensions && width && height) {
        globals.gDimensions[linkId] = {
          width: width,
          height: height
        };
      }
    }
    // Completely remove the definition from the text
    return '';
  });

  // attacklab: strip sentinel
  text = text.replace(/~0/, '');

  return text;
});

showdown.subParser('tables', function (text, options, globals) {
  'use strict';

  if (!options.tables) {
    return text;
  }

  var tableRgx = /^[ \t]{0,3}\|?.+\|.+\n[ \t]{0,3}\|?[ \t]*:?[ \t]*(?:-|=){2,}[ \t]*:?[ \t]*\|[ \t]*:?[ \t]*(?:-|=){2,}[\s\S]+?(?:\n\n|~0)/gm;

  function parseStyles(sLine) {
    if (/^:[ \t]*--*$/.test(sLine)) {
      return ' style="text-align:left;"';
    } else if (/^--*[ \t]*:[ \t]*$/.test(sLine)) {
      return ' style="text-align:right;"';
    } else if (/^:[ \t]*--*[ \t]*:$/.test(sLine)) {
      return ' style="text-align:center;"';
    } else {
      return '';
    }
  }

  function parseHeaders(header, style) {
    var id = '';
    header = header.trim();
    if (options.tableHeaderId) {
      id = ' id="' + header.replace(/ /g, '_').toLowerCase() + '"';
    }
    header = showdown.subParser('spanGamut')(header, options, globals);

    return '<th' + id + style + '>' + header + '</th>\n';
  }

  function parseCells(cell, style) {
    var subText = showdown.subParser('spanGamut')(cell, options, globals);
    return '<td' + style + '>' + subText + '</td>\n';
  }

  function buildTable(headers, cells) {
    var tb = '<table>\n<thead>\n<tr>\n',
        tblLgn = headers.length;

    for (var i = 0; i < tblLgn; ++i) {
      tb += headers[i];
    }
    tb += '</tr>\n</thead>\n<tbody>\n';

    for (i = 0; i < cells.length; ++i) {
      tb += '<tr>\n';
      for (var ii = 0; ii < tblLgn; ++ii) {
        tb += cells[i][ii];
      }
      tb += '</tr>\n';
    }
    tb += '</tbody>\n</table>\n';
    return tb;
  }

  text = globals.converter._dispatch('tables.before', text, options, globals);

  text = text.replace(tableRgx, function (rawTable) {

    var i,
        tableLines = rawTable.split('\n');

    // strip wrong first and last column if wrapped tables are used
    for (i = 0; i < tableLines.length; ++i) {
      if (/^[ \t]{0,3}\|/.test(tableLines[i])) {
        tableLines[i] = tableLines[i].replace(/^[ \t]{0,3}\|/, '');
      }
      if (/\|[ \t]*$/.test(tableLines[i])) {
        tableLines[i] = tableLines[i].replace(/\|[ \t]*$/, '');
      }
    }

    var rawHeaders = tableLines[0].split('|').map(function (s) {
      return s.trim();
    }),
        rawStyles = tableLines[1].split('|').map(function (s) {
      return s.trim();
    }),
        rawCells = [],
        headers = [],
        styles = [],
        cells = [];

    tableLines.shift();
    tableLines.shift();

    for (i = 0; i < tableLines.length; ++i) {
      if (tableLines[i].trim() === '') {
        continue;
      }
      rawCells.push(tableLines[i].split('|').map(function (s) {
        return s.trim();
      }));
    }

    if (rawHeaders.length < rawStyles.length) {
      return rawTable;
    }

    for (i = 0; i < rawStyles.length; ++i) {
      styles.push(parseStyles(rawStyles[i]));
    }

    for (i = 0; i < rawHeaders.length; ++i) {
      if (showdown.helper.isUndefined(styles[i])) {
        styles[i] = '';
      }
      headers.push(parseHeaders(rawHeaders[i], styles[i]));
    }

    for (i = 0; i < rawCells.length; ++i) {
      var row = [];
      for (var ii = 0; ii < headers.length; ++ii) {
        if (showdown.helper.isUndefined(rawCells[i][ii])) {}
        row.push(parseCells(rawCells[i][ii], styles[ii]));
      }
      cells.push(row);
    }

    return buildTable(headers, cells);
  });

  text = globals.converter._dispatch('tables.after', text, options, globals);

  return text;
});

/**
 * Swap back in all the special characters we've hidden.
 */
showdown.subParser('unescapeSpecialChars', function (text) {
  'use strict';

  text = text.replace(/~E(\d+)E/g, function (wholeMatch, m1) {
    var charCodeToReplace = parseInt(m1);
    return String.fromCharCode(charCodeToReplace);
  });
  return text;
});
module.exports = showdown;
});
define("pages/common/wxParse/wxDiscode.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// HTML 支持的数学符号
function strNumDiscode(str) {
    str = str.replace(/&forall;/g, '∀');
    str = str.replace(/&part;/g, '∂');
    str = str.replace(/&exists;/g, '∃');
    str = str.replace(/&empty;/g, '∅');
    str = str.replace(/&nabla;/g, '∇');
    str = str.replace(/&isin;/g, '∈');
    str = str.replace(/&notin;/g, '∉');
    str = str.replace(/&ni;/g, '∋');
    str = str.replace(/&prod;/g, '∏');
    str = str.replace(/&sum;/g, '∑');
    str = str.replace(/&minus;/g, '−');
    str = str.replace(/&lowast;/g, '∗');
    str = str.replace(/&radic;/g, '√');
    str = str.replace(/&prop;/g, '∝');
    str = str.replace(/&infin;/g, '∞');
    str = str.replace(/&ang;/g, '∠');
    str = str.replace(/&and;/g, '∧');
    str = str.replace(/&or;/g, '∨');
    str = str.replace(/&cap;/g, '∩');
    str = str.replace(/&cap;/g, '∪');
    str = str.replace(/&int;/g, '∫');
    str = str.replace(/&there4;/g, '∴');
    str = str.replace(/&sim;/g, '∼');
    str = str.replace(/&cong;/g, '≅');
    str = str.replace(/&asymp;/g, '≈');
    str = str.replace(/&ne;/g, '≠');
    str = str.replace(/&le;/g, '≤');
    str = str.replace(/&ge;/g, '≥');
    str = str.replace(/&sub;/g, '⊂');
    str = str.replace(/&sup;/g, '⊃');
    str = str.replace(/&nsub;/g, '⊄');
    str = str.replace(/&sube;/g, '⊆');
    str = str.replace(/&supe;/g, '⊇');
    str = str.replace(/&oplus;/g, '⊕');
    str = str.replace(/&otimes;/g, '⊗');
    str = str.replace(/&perp;/g, '⊥');
    str = str.replace(/&sdot;/g, '⋅');
    return str;
}

//HTML 支持的希腊字母
function strGreeceDiscode(str) {
    str = str.replace(/&Alpha;/g, 'Α');
    str = str.replace(/&Beta;/g, 'Β');
    str = str.replace(/&Gamma;/g, 'Γ');
    str = str.replace(/&Delta;/g, 'Δ');
    str = str.replace(/&Epsilon;/g, 'Ε');
    str = str.replace(/&Zeta;/g, 'Ζ');
    str = str.replace(/&Eta;/g, 'Η');
    str = str.replace(/&Theta;/g, 'Θ');
    str = str.replace(/&Iota;/g, 'Ι');
    str = str.replace(/&Kappa;/g, 'Κ');
    str = str.replace(/&Lambda;/g, 'Λ');
    str = str.replace(/&Mu;/g, 'Μ');
    str = str.replace(/&Nu;/g, 'Ν');
    str = str.replace(/&Xi;/g, 'Ν');
    str = str.replace(/&Omicron;/g, 'Ο');
    str = str.replace(/&Pi;/g, 'Π');
    str = str.replace(/&Rho;/g, 'Ρ');
    str = str.replace(/&Sigma;/g, 'Σ');
    str = str.replace(/&Tau;/g, 'Τ');
    str = str.replace(/&Upsilon;/g, 'Υ');
    str = str.replace(/&Phi;/g, 'Φ');
    str = str.replace(/&Chi;/g, 'Χ');
    str = str.replace(/&Psi;/g, 'Ψ');
    str = str.replace(/&Omega;/g, 'Ω');

    str = str.replace(/&alpha;/g, 'α');
    str = str.replace(/&beta;/g, 'β');
    str = str.replace(/&gamma;/g, 'γ');
    str = str.replace(/&delta;/g, 'δ');
    str = str.replace(/&epsilon;/g, 'ε');
    str = str.replace(/&zeta;/g, 'ζ');
    str = str.replace(/&eta;/g, 'η');
    str = str.replace(/&theta;/g, 'θ');
    str = str.replace(/&iota;/g, 'ι');
    str = str.replace(/&kappa;/g, 'κ');
    str = str.replace(/&lambda;/g, 'λ');
    str = str.replace(/&mu;/g, 'μ');
    str = str.replace(/&nu;/g, 'ν');
    str = str.replace(/&xi;/g, 'ξ');
    str = str.replace(/&omicron;/g, 'ο');
    str = str.replace(/&pi;/g, 'π');
    str = str.replace(/&rho;/g, 'ρ');
    str = str.replace(/&sigmaf;/g, 'ς');
    str = str.replace(/&sigma;/g, 'σ');
    str = str.replace(/&tau;/g, 'τ');
    str = str.replace(/&upsilon;/g, 'υ');
    str = str.replace(/&phi;/g, 'φ');
    str = str.replace(/&chi;/g, 'χ');
    str = str.replace(/&psi;/g, 'ψ');
    str = str.replace(/&omega;/g, 'ω');
    str = str.replace(/&thetasym;/g, 'ϑ');
    str = str.replace(/&upsih;/g, 'ϒ');
    str = str.replace(/&piv;/g, 'ϖ');
    str = str.replace(/&middot;/g, '·');
    return str;
}

// 

function strcharacterDiscode(str) {
    // 加入常用解析
    str = str.replace(/&nbsp;/g, ' ');
    str = str.replace(/&quot;/g, "'");
    str = str.replace(/&amp;/g, '&');
    // str = str.replace(/&lt;/g, '‹');
    // str = str.replace(/&gt;/g, '›');

    str = str.replace(/&lt;/g, '<');
    str = str.replace(/&gt;/g, '>');

    return str;
}

// HTML 支持的其他实体
function strOtherDiscode(str) {
    str = str.replace(/&OElig;/g, 'Œ');
    str = str.replace(/&oelig;/g, 'œ');
    str = str.replace(/&Scaron;/g, 'Š');
    str = str.replace(/&scaron;/g, 'š');
    str = str.replace(/&Yuml;/g, 'Ÿ');
    str = str.replace(/&fnof;/g, 'ƒ');
    str = str.replace(/&circ;/g, 'ˆ');
    str = str.replace(/&tilde;/g, '˜');
    str = str.replace(/&ensp;/g, '');
    str = str.replace(/&emsp;/g, '');
    str = str.replace(/&thinsp;/g, '');
    str = str.replace(/&zwnj;/g, '');
    str = str.replace(/&zwj;/g, '');
    str = str.replace(/&lrm;/g, '');
    str = str.replace(/&rlm;/g, '');
    str = str.replace(/&ndash;/g, '–');
    str = str.replace(/&mdash;/g, '—');
    str = str.replace(/&lsquo;/g, '‘');
    str = str.replace(/&rsquo;/g, '’');
    str = str.replace(/&sbquo;/g, '‚');
    str = str.replace(/&ldquo;/g, '“');
    str = str.replace(/&rdquo;/g, '”');
    str = str.replace(/&bdquo;/g, '„');
    str = str.replace(/&dagger;/g, '†');
    str = str.replace(/&Dagger;/g, '‡');
    str = str.replace(/&bull;/g, '•');
    str = str.replace(/&hellip;/g, '…');
    str = str.replace(/&permil;/g, '‰');
    str = str.replace(/&prime;/g, '′');
    str = str.replace(/&Prime;/g, '″');
    str = str.replace(/&lsaquo;/g, '‹');
    str = str.replace(/&rsaquo;/g, '›');
    str = str.replace(/&oline;/g, '‾');
    str = str.replace(/&euro;/g, '€');
    str = str.replace(/&trade;/g, '™');

    str = str.replace(/&larr;/g, '←');
    str = str.replace(/&uarr;/g, '↑');
    str = str.replace(/&rarr;/g, '→');
    str = str.replace(/&darr;/g, '↓');
    str = str.replace(/&harr;/g, '↔');
    str = str.replace(/&crarr;/g, '↵');
    str = str.replace(/&lceil;/g, '⌈');
    str = str.replace(/&rceil;/g, '⌉');

    str = str.replace(/&lfloor;/g, '⌊');
    str = str.replace(/&rfloor;/g, '⌋');
    str = str.replace(/&loz;/g, '◊');
    str = str.replace(/&spades;/g, '♠');
    str = str.replace(/&clubs;/g, '♣');
    str = str.replace(/&hearts;/g, '♥');

    str = str.replace(/&diams;/g, '♦');

    return str;
}

function strMoreDiscode(str) {
    str = str.replace(/\r\n/g, "");
    str = str.replace(/\n/g, "");

    str = str.replace(/code/g, "wxxxcode-style");
    return str;
}

function strDiscode(str) {
    str = strNumDiscode(str);
    str = strGreeceDiscode(str);
    str = strcharacterDiscode(str);
    str = strOtherDiscode(str);
    str = strMoreDiscode(str);
    return str;
}
function urlToHttpUrl(url, rep) {

    var patt1 = new RegExp("^//");
    var result = patt1.test(url);
    if (result) {
        url = rep + ":" + url;
    }

    //uctphp modify
    if (!url.startsWith('http')) {
        url = getApp().globalData.prefix_url + url;
    }

    return url;
}

module.exports = {
    strDiscode: strDiscode,
    urlToHttpUrl: urlToHttpUrl
};
});
define("pages/common/wxParse/wxParse.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _showdown = require('./showdown.js');

var _showdown2 = _interopRequireDefault(_showdown);

var _html2json = require('./html2json.js');

var _html2json2 = _interopRequireDefault(_html2json);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * 配置及公有属性
 **/
/**
 * 主函数入口区
 **/
/**
 * author: Di (微信小程序开发工程师)
 * organization: WeAppDev(微信小程序开发论坛)(http://weappdev.com)
 *               垂直微信小程序开发交流社区
 * 
 * github地址: https://github.com/icindy/wxParse
 * 
 * for: 微信小程序富文本解析
 * detail : http://weappdev.com/t/wxparse-alpha0-1-html-markdown/184
 */

/**
 * utils函数引入
 **/
function wxParse() {
  var bindName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'wxParseData';
  var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'html';
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '<div class="color:red;">数据不能为空</div>';
  var target = arguments[3];
  var imagePadding = arguments[4];

  var that = target;
  var transData = {}; //存放转化后的数据
  if (type == 'html') {
    transData = _html2json2.default.html2json(data, bindName);
    console.log(JSON.stringify(transData, ' ', ' '));
  } else if (type == 'md' || type == 'markdown') {
    var converter = new _showdown2.default.Converter();
    var html = converter.makeHtml(data);
    transData = _html2json2.default.html2json(html, bindName);
    console.log(JSON.stringify(transData, ' ', ' '));
  }
  transData.view = {};
  transData.view.imagePadding = 0;
  if (typeof imagePadding != 'undefined') {
    transData.view.imagePadding = imagePadding;
  }
  var bindData = {};
  bindData[bindName] = transData;
  that.setData(bindData);
  that.wxParseImgLoad = wxParseImgLoad;
  that.wxParseImgTap = wxParseImgTap;
}
// 图片点击事件
function wxParseImgTap(e) {
  var that = this;
  var nowImgUrl = e.target.dataset.src;
  var tagFrom = e.target.dataset.from;
  if (typeof tagFrom != 'undefined' && tagFrom.length > 0) {
    wx.previewImage({
      current: nowImgUrl, // 当前显示图片的http链接
      urls: that.data[tagFrom].imageUrls // 需要预览的图片http链接列表
    });
  }
}

/**
 * 图片视觉宽高计算函数区 
 **/
function wxParseImgLoad(e) {
  var that = this;
  var tagFrom = e.target.dataset.from;
  var idx = e.target.dataset.idx;
  if (typeof tagFrom != 'undefined' && tagFrom.length > 0) {
    calMoreImageInfo(e, idx, that, tagFrom);
  }
}
// 假循环获取计算图片视觉最佳宽高
function calMoreImageInfo(e, idx, that, bindName) {
  var temData = that.data[bindName];
  if (temData.images.length == 0) {
    return;
  }
  var temImages = temData.images;
  //因为无法获取view宽度 需要自定义padding进行计算，稍后处理
  var recal = wxAutoImageCal(e.detail.width, e.detail.height, that, bindName);
  temImages[idx].width = recal.imageWidth;
  temImages[idx].height = recal.imageheight;
  temData.images = temImages;
  var bindData = {};
  bindData[bindName] = temData;
  that.setData(bindData);
}

// 计算视觉优先的图片宽高
function wxAutoImageCal(originalWidth, originalHeight, that, bindName) {
  //获取图片的原始长宽
  var windowWidth = 0,
      windowHeight = 0;
  var autoWidth = 0,
      autoHeight = 0;
  var results = {};
  wx.getSystemInfo({
    success: function success(res) {
      var padding = that.data[bindName].view.imagePadding;
      windowWidth = res.windowWidth - 2 * padding;
      windowHeight = res.windowHeight;
      //判断按照那种方式进行缩放
      console.log("windowWidth" + windowWidth);
      if (originalWidth > windowWidth) {
        //在图片width大于手机屏幕width时候
        autoWidth = windowWidth;
        console.log("autoWidth" + autoWidth);
        autoHeight = autoWidth * originalHeight / originalWidth;
        console.log("autoHeight" + autoHeight);
        results.imageWidth = autoWidth;
        results.imageheight = autoHeight;
      } else {
        //否则展示原来的数据
        results.imageWidth = originalWidth;
        results.imageheight = originalHeight;
      }
    }
  });
  return results;
}

function wxParseTemArray(temArrayName, bindNameReg, total, that) {
  var array = [];
  var temData = that.data;
  var obj = null;
  for (var i = 0; i < total; i++) {
    var simArr = temData[bindNameReg + i].nodes;
    array.push(simArr);
  }

  temArrayName = temArrayName || 'wxParseTemArray';
  obj = JSON.parse('{"' + temArrayName + '":""}');
  obj[temArrayName] = array;
  that.setData(obj);
}

/**
 * 配置emojis
 * 
 */

function emojisInit() {
  var reg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var baseSrc = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "/wxParse/emojis/";
  var emojis = arguments[2];

  _html2json2.default.emojisInit(reg, baseSrc, emojis);
}

module.exports = {
  wxParse: wxParse,
  wxParseTemArray: wxParseTemArray,
  emojisInit: emojisInit
};
});
define("util/city.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var cityObj = [{ "id": "35", "provincecode": "150000", "city": "\u963F\u62C9\u5584\u76DF", "code": "152900", "initial": "A" }, { "id": "38", "provincecode": "210000", "city": "\u978D\u5C71\u5E02", "code": "210300", "initial": "A" }, { "id": "105", "provincecode": "340000", "city": "\u5B89\u5E86\u5E02", "code": "340800", "initial": "A" }, { "id": "156", "provincecode": "410000", "city": "\u5B89\u9633\u5E02", "code": "410500", "initial": "A" }, { "id": "256", "provincecode": "510000", "city": "\u963F\u575D\u85CF\u65CF\u7F8C\u65CF\u81EA\u6CBB\u5DDE", "code": "513200", "initial": "A" }, { "id": "262", "provincecode": "520000", "city": "\u5B89\u987A\u5E02", "code": "520400", "initial": "A" }, { "id": "289", "provincecode": "540000", "city": "\u963F\u91CC\u5730\u533A", "code": "542500", "initial": "A" }, { "id": "299", "provincecode": "610000", "city": "\u5B89\u5EB7\u5E02", "code": "610900", "initial": "A" }, { "id": "335", "provincecode": "650000", "city": "\u963F\u514B\u82CF\u5730\u533A", "code": "652900", "initial": "A" }, { "id": "341", "provincecode": "650000", "city": "\u963F\u52D2\u6CF0\u5730\u533A", "code": "654300", "initial": "A" }, { "id": "1", "provincecode": "110000", "city": "\u5317\u4EAC\u5E02", "code": "110100", "initial": "B" }, { "id": "7", "provincecode": "130000", "city": "\u4FDD\u5B9A\u5E02", "code": "130600", "initial": "B" }, { "id": "25", "provincecode": "150000", "city": "\u5305\u5934\u5E02", "code": "150200", "initial": "B" }, { "id": "31", "provincecode": "150000", "city": "\u5DF4\u5F66\u6DD6\u5C14\u5E02", "code": "150800", "initial": "B" }, { "id": "40", "provincecode": "210000", "city": "\u672C\u6EAA\u5E02", "code": "210500", "initial": "B" }, { "id": "55", "provincecode": "220000", "city": "\u767D\u5C71\u5E02", "code": "220600", "initial": "B" }, { "id": "57", "provincecode": "220000", "city": "\u767D\u57CE\u5E02", "code": "220800", "initial": "B" }, { "id": "100", "provincecode": "340000", "city": "\u868C\u57E0\u5E02", "code": "340300", "initial": "B" }, { "id": "150", "provincecode": "370000", "city": "\u6EE8\u5DDE\u5E02", "code": "371600", "initial": "B" }, { "id": "222", "provincecode": "450000", "city": "\u5317\u6D77\u5E02", "code": "450500", "initial": "B" }, { "id": "227", "provincecode": "450000", "city": "\u767E\u8272\u5E02", "code": "451000", "initial": "B" }, { "id": "254", "provincecode": "510000", "city": "\u5DF4\u4E2D\u5E02", "code": "511900", "initial": "B" }, { "id": "265", "provincecode": "520000", "city": "\u6BD5\u8282\u5730\u533A", "code": "522400", "initial": "B" }, { "id": "271", "provincecode": "530000", "city": "\u4FDD\u5C71\u5E02", "code": "530500", "initial": "B" }, { "id": "293", "provincecode": "610000", "city": "\u5B9D\u9E21\u5E02", "code": "610300", "initial": "B" }, { "id": "304", "provincecode": "620000", "city": "\u767D\u94F6\u5E02", "code": "620400", "initial": "B" }, { "id": "333", "provincecode": "650000", "city": "\u535A\u5C14\u5854\u62C9\u8499\u53E4\u81EA\u6CBB\u5DDE", "code": "652700", "initial": "B" }, { "id": "334", "provincecode": "650000", "city": "\u5DF4\u97F3\u90ED\u695E\u8499\u53E4\u81EA\u6CBB\u5DDE", "code": "652800", "initial": "B" }, { "id": "9", "provincecode": "130000", "city": "\u627F\u5FB7\u5E02", "code": "130800", "initial": "C" }, { "id": "10", "provincecode": "130000", "city": "\u6CA7\u5DDE\u5E02", "code": "130900", "initial": "C" }, { "id": "16", "provincecode": "140000", "city": "\u957F\u6CBB\u5E02", "code": "140400", "initial": "C" }, { "id": "27", "provincecode": "150000", "city": "\u8D64\u5CF0\u5E02", "code": "150400", "initial": "C" }, { "id": "48", "provincecode": "210000", "city": "\u671D\u9633\u5E02", "code": "211300", "initial": "C" }, { "id": "50", "provincecode": "220000", "city": "\u957F\u6625\u5E02", "code": "220100", "initial": "C" }, { "id": "77", "provincecode": "320000", "city": "\u5E38\u5DDE\u5E02", "code": "320400", "initial": "C" }, { "id": "107", "provincecode": "340000", "city": "\u6EC1\u5DDE\u5E02", "code": "341100", "initial": "C" }, { "id": "110", "provincecode": "340000", "city": "\u5DE2\u6E56\u5E02", "code": "341400", "initial": "C" }, { "id": "113", "provincecode": "340000", "city": "\u6C60\u5DDE\u5E02", "code": "341700", "initial": "C" }, { "id": "183", "provincecode": "430000", "city": "\u957F\u6C99\u5E02", "code": "430100", "initial": "C" }, { "id": "189", "provincecode": "430000", "city": "\u5E38\u5FB7\u5E02", "code": "430700", "initial": "C" }, { "id": "192", "provincecode": "430000", "city": "\u90F4\u5DDE\u5E02", "code": "431000", "initial": "C" }, { "id": "215", "provincecode": "440000", "city": "\u6F6E\u5DDE\u5E02", "code": "445100", "initial": "C" }, { "id": "231", "provincecode": "450000", "city": "\u5D07\u5DE6\u5E02", "code": "451400", "initial": "C" }, { "id": "238", "provincecode": "510000", "city": "\u6210\u90FD\u5E02", "code": "510100", "initial": "C" }, { "id": "276", "provincecode": "530000", "city": "\u695A\u96C4\u5F5D\u65CF\u81EA\u6CBB\u5DDE", "code": "532300", "initial": "C" }, { "id": "285", "provincecode": "540000", "city": "\u660C\u90FD\u5730\u533A", "code": "542100", "initial": "C" }, { "id": "332", "provincecode": "650000", "city": "\u660C\u5409\u56DE\u65CF\u81EA\u6CBB\u5DDE", "code": "652300", "initial": "C" }, { "id": "14", "provincecode": "140000", "city": "\u5927\u540C\u5E02", "code": "140200", "initial": "D" }, { "id": "37", "provincecode": "210000", "city": "\u5927\u8FDE\u5E02", "code": "210200", "initial": "D" }, { "id": "41", "provincecode": "210000", "city": "\u4E39\u4E1C\u5E02", "code": "210600", "initial": "D" }, { "id": "64", "provincecode": "230000", "city": "\u5927\u5E86\u5E02", "code": "230600", "initial": "D" }, { "id": "71", "provincecode": "230000", "city": "\u5927\u5174\u5B89\u5CAD\u5730\u533A", "code": "232700", "initial": "D" }, { "id": "139", "provincecode": "370000", "city": "\u4E1C\u8425\u5E02", "code": "370500", "initial": "D" }, { "id": "148", "provincecode": "370000", "city": "\u5FB7\u5DDE\u5E02", "code": "371400", "initial": "D" }, { "id": "213", "provincecode": "440000", "city": "\u4E1C\u839E\u5E02", "code": "441900", "initial": "D" }, { "id": "242", "provincecode": "510000", "city": "\u5FB7\u9633\u5E02", "code": "510600", "initial": "D" }, { "id": "252", "provincecode": "510000", "city": "\u8FBE\u5DDE\u5E02", "code": "511700", "initial": "D" }, { "id": "280", "provincecode": "530000", "city": "\u5927\u7406\u767D\u65CF\u81EA\u6CBB\u5DDE", "code": "532900", "initial": "D" }, { "id": "281", "provincecode": "530000", "city": "\u5FB7\u5B8F\u50A3\u65CF\u666F\u9887\u65CF\u81EA\u6CBB\u5DDE", "code": "533100", "initial": "D" }, { "id": "283", "provincecode": "530000", "city": "\u8FEA\u5E86\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "533400", "initial": "D" }, { "id": "311", "provincecode": "620000", "city": "\u5B9A\u897F\u5E02", "code": "621100", "initial": "D" }, { "id": "29", "provincecode": "150000", "city": "\u9102\u5C14\u591A\u65AF\u5E02", "code": "150600", "initial": "E" }, { "id": "174", "provincecode": "420000", "city": "\u9102\u5DDE\u5E02", "code": "420700", "initial": "E" }, { "id": "181", "provincecode": "420000", "city": "\u6069\u65BD\u571F\u5BB6\u65CF\u82D7\u65CF\u81EA\u6CBB\u5DDE", "code": "422800", "initial": "E" }, { "id": "39", "provincecode": "210000", "city": "\u629A\u987A\u5E02", "code": "210400", "initial": "F" }, { "id": "44", "provincecode": "210000", "city": "\u961C\u65B0\u5E02", "code": "210900", "initial": "F" }, { "id": "108", "provincecode": "340000", "city": "\u961C\u9633\u5E02", "code": "341200", "initial": "F" }, { "id": "115", "provincecode": "350000", "city": "\u798F\u5DDE\u5E02", "code": "350100", "initial": "F" }, { "id": "133", "provincecode": "360000", "city": "\u629A\u5DDE\u5E02", "code": "361000", "initial": "F" }, { "id": "202", "provincecode": "440000", "city": "\u4F5B\u5C71\u5E02", "code": "440600", "initial": "F" }, { "id": "223", "provincecode": "450000", "city": "\u9632\u57CE\u6E2F\u5E02", "code": "450600", "initial": "F" }, { "id": "130", "provincecode": "360000", "city": "\u8D63\u5DDE\u5E02", "code": "360700", "initial": "G" }, { "id": "197", "provincecode": "440000", "city": "\u5E7F\u5DDE\u5E02", "code": "440100", "initial": "G" }, { "id": "220", "provincecode": "450000", "city": "\u6842\u6797\u5E02", "code": "450300", "initial": "G" }, { "id": "225", "provincecode": "450000", "city": "\u8D35\u6E2F\u5E02", "code": "450800", "initial": "G" }, { "id": "244", "provincecode": "510000", "city": "\u5E7F\u5143\u5E02", "code": "510800", "initial": "G" }, { "id": "251", "provincecode": "510000", "city": "\u5E7F\u5B89\u5E02", "code": "511600", "initial": "G" }, { "id": "257", "provincecode": "510000", "city": "\u7518\u5B5C\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "513300", "initial": "G" }, { "id": "259", "provincecode": "520000", "city": "\u8D35\u9633\u5E02", "code": "520100", "initial": "G" }, { "id": "314", "provincecode": "620000", "city": "\u7518\u5357\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "623000", "initial": "G" }, { "id": "320", "provincecode": "630000", "city": "\u679C\u6D1B\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632600", "initial": "G" }, { "id": "326", "provincecode": "640000", "city": "\u56FA\u539F\u5E02", "code": "640400", "initial": "G" }, { "id": "5", "provincecode": "130000", "city": "\u90AF\u90F8\u5E02", "code": "130400", "initial": "H" }, { "id": "12", "provincecode": "130000", "city": "\u8861\u6C34\u5E02", "code": "131100", "initial": "H" }, { "id": "24", "provincecode": "150000", "city": "\u547C\u548C\u6D69\u7279\u5E02", "code": "150100", "initial": "H" }, { "id": "30", "provincecode": "150000", "city": "\u547C\u4F26\u8D1D\u5C14\u5E02", "code": "150700", "initial": "H" }, { "id": "49", "provincecode": "210000", "city": "\u846B\u82A6\u5C9B\u5E02", "code": "211400", "initial": "H" }, { "id": "59", "provincecode": "230000", "city": "\u54C8\u5C14\u6EE8\u5E02", "code": "230100", "initial": "H" }, { "id": "62", "provincecode": "230000", "city": "\u9E64\u5C97\u5E02", "code": "230400", "initial": "H" }, { "id": "69", "provincecode": "230000", "city": "\u9ED1\u6CB3\u5E02", "code": "231100", "initial": "H" }, { "id": "81", "provincecode": "320000", "city": "\u6DEE\u5B89\u5E02", "code": "320800", "initial": "H" }, { "id": "87", "provincecode": "330000", "city": "\u676D\u5DDE\u5E02", "code": "330100", "initial": "H" }, { "id": "91", "provincecode": "330000", "city": "\u6E56\u5DDE\u5E02", "code": "330500", "initial": "H" }, { "id": "98", "provincecode": "340000", "city": "\u5408\u80A5\u5E02", "code": "340100", "initial": "H" }, { "id": "101", "provincecode": "340000", "city": "\u6DEE\u5357\u5E02", "code": "340400", "initial": "H" }, { "id": "103", "provincecode": "340000", "city": "\u6DEE\u5317\u5E02", "code": "340600", "initial": "H" }, { "id": "106", "provincecode": "340000", "city": "\u9EC4\u5C71\u5E02", "code": "341000", "initial": "H" }, { "id": "112", "provincecode": "340000", "city": "\u4EB3\u5DDE\u5E02", "code": "341600", "initial": "H" }, { "id": "151", "provincecode": "370000", "city": "\u8377\u6CFD\u5E02", "code": "371700", "initial": "H" }, { "id": "157", "provincecode": "410000", "city": "\u9E64\u58C1\u5E02", "code": "410600", "initial": "H" }, { "id": "170", "provincecode": "420000", "city": "\u9EC4\u77F3\u5E02", "code": "420200", "initial": "H" }, { "id": "178", "provincecode": "420000", "city": "\u9EC4\u5188\u5E02", "code": "421100", "initial": "H" }, { "id": "186", "provincecode": "430000", "city": "\u8861\u9633\u5E02", "code": "430400", "initial": "H" }, { "id": "194", "provincecode": "430000", "city": "\u6000\u5316\u5E02", "code": "431200", "initial": "H" }, { "id": "207", "provincecode": "440000", "city": "\u60E0\u5DDE\u5E02", "code": "441300", "initial": "H" }, { "id": "210", "provincecode": "440000", "city": "\u6CB3\u6E90\u5E02", "code": "441600", "initial": "H" }, { "id": "228", "provincecode": "450000", "city": "\u8D3A\u5DDE\u5E02", "code": "451100", "initial": "H" }, { "id": "229", "provincecode": "450000", "city": "\u6CB3\u6C60\u5E02", "code": "451200", "initial": "H" }, { "id": "232", "provincecode": "460000", "city": "\u6D77\u53E3\u5E02", "code": "460100", "initial": "H" }, { "id": "277", "provincecode": "530000", "city": "\u7EA2\u6CB3\u54C8\u5C3C\u65CF\u5F5D\u65CF\u81EA\u6CBB\u5DDE", "code": "532500", "initial": "H" }, { "id": "297", "provincecode": "610000", "city": "\u6C49\u4E2D\u5E02", "code": "610700", "initial": "H" }, { "id": "316", "provincecode": "630000", "city": "\u6D77\u4E1C\u5730\u533A", "code": "632100", "initial": "H" }, { "id": "317", "provincecode": "630000", "city": "\u6D77\u5317\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632200", "initial": "H" }, { "id": "318", "provincecode": "630000", "city": "\u9EC4\u5357\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632300", "initial": "H" }, { "id": "319", "provincecode": "630000", "city": "\u6D77\u5357\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632500", "initial": "H" }, { "id": "322", "provincecode": "630000", "city": "\u6D77\u897F\u8499\u53E4\u65CF\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632800", "initial": "H" }, { "id": "331", "provincecode": "650000", "city": "\u54C8\u5BC6\u5730\u533A", "code": "652200", "initial": "H" }, { "id": "338", "provincecode": "650000", "city": "\u548C\u7530\u5730\u533A", "code": "653200", "initial": "H" }, { "id": "17", "provincecode": "140000", "city": "\u664B\u57CE\u5E02", "code": "140500", "initial": "J" }, { "id": "19", "provincecode": "140000", "city": "\u664B\u4E2D\u5E02", "code": "140700", "initial": "J" }, { "id": "42", "provincecode": "210000", "city": "\u9526\u5DDE\u5E02", "code": "210700", "initial": "J" }, { "id": "51", "provincecode": "220000", "city": "\u5409\u6797\u5E02", "code": "220200", "initial": "J" }, { "id": "61", "provincecode": "230000", "city": "\u9E21\u897F\u5E02", "code": "230300", "initial": "J" }, { "id": "66", "provincecode": "230000", "city": "\u4F73\u6728\u65AF\u5E02", "code": "230800", "initial": "J" }, { "id": "90", "provincecode": "330000", "city": "\u5609\u5174\u5E02", "code": "330400", "initial": "J" }, { "id": "93", "provincecode": "330000", "city": "\u91D1\u534E\u5E02", "code": "330700", "initial": "J" }, { "id": "125", "provincecode": "360000", "city": "\u666F\u5FB7\u9547\u5E02", "code": "360200", "initial": "J" }, { "id": "127", "provincecode": "360000", "city": "\u4E5D\u6C5F\u5E02", "code": "360400", "initial": "J" }, { "id": "131", "provincecode": "360000", "city": "\u5409\u5B89\u5E02", "code": "360800", "initial": "J" }, { "id": "135", "provincecode": "370000", "city": "\u6D4E\u5357\u5E02", "code": "370100", "initial": "J" }, { "id": "142", "provincecode": "370000", "city": "\u6D4E\u5B81\u5E02", "code": "370800", "initial": "J" }, { "id": "159", "provincecode": "410000", "city": "\u7126\u4F5C\u5E02", "code": "410800", "initial": "J" }, { "id": "175", "provincecode": "420000", "city": "\u8346\u95E8\u5E02", "code": "420800", "initial": "J" }, { "id": "177", "provincecode": "420000", "city": "\u8346\u5DDE\u5E02", "code": "421000", "initial": "J" }, { "id": "203", "provincecode": "440000", "city": "\u6C5F\u95E8\u5E02", "code": "440700", "initial": "J" }, { "id": "216", "provincecode": "440000", "city": "\u63ED\u9633\u5E02", "code": "445200", "initial": "J" }, { "id": "302", "provincecode": "620000", "city": "\u5609\u5CEA\u5173\u5E02", "code": "620200", "initial": "J" }, { "id": "303", "provincecode": "620000", "city": "\u91D1\u660C\u5E02", "code": "620300", "initial": "J" }, { "id": "309", "provincecode": "620000", "city": "\u9152\u6CC9\u5E02", "code": "620900", "initial": "J" }, { "id": "153", "provincecode": "410000", "city": "\u5F00\u5C01\u5E02", "code": "410200", "initial": "K" }, { "id": "268", "provincecode": "530000", "city": "\u6606\u660E\u5E02", "code": "530100", "initial": "K" }, { "id": "329", "provincecode": "650000", "city": "\u514B\u62C9\u739B\u4F9D\u5E02", "code": "650200", "initial": "K" }, { "id": "336", "provincecode": "650000", "city": "\u514B\u5B5C\u52D2\u82CF\u67EF\u5C14\u514B\u5B5C\u81EA\u6CBB\u5DDE", "code": "653000", "initial": "K" }, { "id": "337", "provincecode": "650000", "city": "\u5580\u4EC0\u5730\u533A", "code": "653100", "initial": "K" }, { "id": "11", "provincecode": "130000", "city": "\u5ECA\u574A\u5E02", "code": "131000", "initial": "L" }, { "id": "22", "provincecode": "140000", "city": "\u4E34\u6C7E\u5E02", "code": "141000", "initial": "L" }, { "id": "23", "provincecode": "140000", "city": "\u5415\u6881\u5E02", "code": "141100", "initial": "L" }, { "id": "45", "provincecode": "210000", "city": "\u8FBD\u9633\u5E02", "code": "211000", "initial": "L" }, { "id": "53", "provincecode": "220000", "city": "\u8FBD\u6E90\u5E02", "code": "220400", "initial": "L" }, { "id": "80", "provincecode": "320000", "city": "\u8FDE\u4E91\u6E2F\u5E02", "code": "320700", "initial": "L" }, { "id": "97", "provincecode": "330000", "city": "\u4E3D\u6C34\u5E02", "code": "331100", "initial": "L" }, { "id": "111", "provincecode": "340000", "city": "\u516D\u5B89\u5E02", "code": "341500", "initial": "L" }, { "id": "122", "provincecode": "350000", "city": "\u9F99\u5CA9\u5E02", "code": "350800", "initial": "L" }, { "id": "146", "provincecode": "370000", "city": "\u83B1\u829C\u5E02", "code": "371200", "initial": "L" }, { "id": "147", "provincecode": "370000", "city": "\u4E34\u6C82\u5E02", "code": "371300", "initial": "L" }, { "id": "149", "provincecode": "370000", "city": "\u804A\u57CE\u5E02", "code": "371500", "initial": "L" }, { "id": "154", "provincecode": "410000", "city": "\u6D1B\u9633\u5E02", "code": "410300", "initial": "L" }, { "id": "162", "provincecode": "410000", "city": "\u6F2F\u6CB3\u5E02", "code": "411100", "initial": "L" }, { "id": "195", "provincecode": "430000", "city": "\u5A04\u5E95\u5E02", "code": "431300", "initial": "L" }, { "id": "219", "provincecode": "450000", "city": "\u67F3\u5DDE\u5E02", "code": "450200", "initial": "L" }, { "id": "230", "provincecode": "450000", "city": "\u6765\u5BBE\u5E02", "code": "451300", "initial": "L" }, { "id": "241", "provincecode": "510000", "city": "\u6CF8\u5DDE\u5E02", "code": "510500", "initial": "L" }, { "id": "247", "provincecode": "510000", "city": "\u4E50\u5C71\u5E02", "code": "511100", "initial": "L" }, { "id": "258", "provincecode": "510000", "city": "\u51C9\u5C71\u5F5D\u65CF\u81EA\u6CBB\u5DDE", "code": "513400", "initial": "L" }, { "id": "260", "provincecode": "520000", "city": "\u516D\u76D8\u6C34\u5E02", "code": "520200", "initial": "L" }, { "id": "273", "provincecode": "530000", "city": "\u4E3D\u6C5F\u5E02", "code": "530700", "initial": "L" }, { "id": "275", "provincecode": "530000", "city": "\u4E34\u6CA7\u5E02", "code": "530900", "initial": "L" }, { "id": "284", "provincecode": "540000", "city": "\u62C9\u8428\u5E02", "code": "540100", "initial": "L" }, { "id": "290", "provincecode": "540000", "city": "\u6797\u829D\u5730\u533A", "code": "542600", "initial": "L" }, { "id": "301", "provincecode": "620000", "city": "\u5170\u5DDE\u5E02", "code": "620100", "initial": "L" }, { "id": "312", "provincecode": "620000", "city": "\u9647\u5357\u5E02", "code": "621200", "initial": "L" }, { "id": "313", "provincecode": "620000", "city": "\u4E34\u590F\u56DE\u65CF\u81EA\u6CBB\u5DDE", "code": "622900", "initial": "L" }, { "id": "68", "provincecode": "230000", "city": "\u7261\u4E39\u6C5F\u5E02", "code": "231000", "initial": "M" }, { "id": "102", "provincecode": "340000", "city": "\u9A6C\u978D\u5C71\u5E02", "code": "340500", "initial": "M" }, { "id": "205", "provincecode": "440000", "city": "\u8302\u540D\u5E02", "code": "440900", "initial": "M" }, { "id": "208", "provincecode": "440000", "city": "\u6885\u5DDE\u5E02", "code": "441400", "initial": "M" }, { "id": "243", "provincecode": "510000", "city": "\u7EF5\u9633\u5E02", "code": "510700", "initial": "M" }, { "id": "249", "provincecode": "510000", "city": "\u7709\u5C71\u5E02", "code": "511400", "initial": "M" }, { "id": "74", "provincecode": "320000", "city": "\u5357\u4EAC\u5E02", "code": "320100", "initial": "N" }, { "id": "79", "provincecode": "320000", "city": "\u5357\u901A\u5E02", "code": "320600", "initial": "N" }, { "id": "88", "provincecode": "330000", "city": "\u5B81\u6CE2\u5E02", "code": "330200", "initial": "N" }, { "id": "121", "provincecode": "350000", "city": "\u5357\u5E73\u5E02", "code": "350700", "initial": "N" }, { "id": "123", "provincecode": "350000", "city": "\u5B81\u5FB7\u5E02", "code": "350900", "initial": "N" }, { "id": "124", "provincecode": "360000", "city": "\u5357\u660C\u5E02", "code": "360100", "initial": "N" }, { "id": "164", "provincecode": "410000", "city": "\u5357\u9633\u5E02", "code": "411300", "initial": "N" }, { "id": "218", "provincecode": "450000", "city": "\u5357\u5B81\u5E02", "code": "450100", "initial": "N" }, { "id": "246", "provincecode": "510000", "city": "\u5185\u6C5F\u5E02", "code": "511000", "initial": "N" }, { "id": "248", "provincecode": "510000", "city": "\u5357\u5145\u5E02", "code": "511300", "initial": "N" }, { "id": "282", "provincecode": "530000", "city": "\u6012\u6C5F\u5088\u50F3\u65CF\u81EA\u6CBB\u5DDE", "code": "533300", "initial": "N" }, { "id": "288", "provincecode": "540000", "city": "\u90A3\u66F2\u5730\u533A", "code": "542400", "initial": "N" }, { "id": "46", "provincecode": "210000", "city": "\u76D8\u9526\u5E02", "code": "211100", "initial": "P" }, { "id": "117", "provincecode": "350000", "city": "\u8386\u7530\u5E02", "code": "350300", "initial": "P" }, { "id": "126", "provincecode": "360000", "city": "\u840D\u4E61\u5E02", "code": "360300", "initial": "P" }, { "id": "155", "provincecode": "410000", "city": "\u5E73\u9876\u5C71\u5E02", "code": "410400", "initial": "P" }, { "id": "160", "provincecode": "410000", "city": "\u6FEE\u9633\u5E02", "code": "410900", "initial": "P" }, { "id": "240", "provincecode": "510000", "city": "\u6500\u679D\u82B1\u5E02", "code": "510400", "initial": "P" }, { "id": "308", "provincecode": "620000", "city": "\u5E73\u51C9\u5E02", "code": "620800", "initial": "P" }, { "id": "4", "provincecode": "130000", "city": "\u79E6\u7687\u5C9B\u5E02", "code": "130300", "initial": "Q" }, { "id": "60", "provincecode": "230000", "city": "\u9F50\u9F50\u54C8\u5C14\u5E02", "code": "230200", "initial": "Q" }, { "id": "67", "provincecode": "230000", "city": "\u4E03\u53F0\u6CB3\u5E02", "code": "230900", "initial": "Q" }, { "id": "94", "provincecode": "330000", "city": "\u8862\u5DDE\u5E02", "code": "330800", "initial": "Q" }, { "id": "119", "provincecode": "350000", "city": "\u6CC9\u5DDE\u5E02", "code": "350500", "initial": "Q" }, { "id": "136", "provincecode": "370000", "city": "\u9752\u5C9B\u5E02", "code": "370200", "initial": "Q" }, { "id": "212", "provincecode": "440000", "city": "\u6E05\u8FDC\u5E02", "code": "441800", "initial": "Q" }, { "id": "224", "provincecode": "450000", "city": "\u94A6\u5DDE\u5E02", "code": "450700", "initial": "Q" }, { "id": "264", "provincecode": "520000", "city": "\u9ED4\u897F\u5357\u5E03\u4F9D\u65CF\u82D7\u65CF\u81EA\u6CBB\u5DDE", "code": "522300", "initial": "Q" }, { "id": "266", "provincecode": "520000", "city": "\u9ED4\u4E1C\u5357\u82D7\u65CF\u4F97\u65CF\u81EA\u6CBB\u5DDE", "code": "522600", "initial": "Q" }, { "id": "267", "provincecode": "520000", "city": "\u9ED4\u5357\u5E03\u4F9D\u65CF\u82D7\u65CF\u81EA\u6CBB\u5DDE", "code": "522700", "initial": "Q" }, { "id": "269", "provincecode": "530000", "city": "\u66F2\u9756\u5E02", "code": "530300", "initial": "Q" }, { "id": "310", "provincecode": "620000", "city": "\u5E86\u9633\u5E02", "code": "621000", "initial": "Q" }, { "id": "145", "provincecode": "370000", "city": "\u65E5\u7167\u5E02", "code": "371100", "initial": "R" }, { "id": "287", "provincecode": "540000", "city": "\u65E5\u5580\u5219\u5730\u533A", "code": "542300", "initial": "R" }, { "id": "2", "provincecode": "130000", "city": "\u77F3\u5BB6\u5E84\u5E02", "code": "130100", "initial": "S" }, { "id": "18", "provincecode": "140000", "city": "\u6714\u5DDE\u5E02", "code": "140600", "initial": "S" }, { "id": "36", "provincecode": "210000", "city": "\u6C88\u9633\u5E02", "code": "210100", "initial": "S" }, { "id": "52", "provincecode": "220000", "city": "\u56DB\u5E73\u5E02", "code": "220300", "initial": "S" }, { "id": "56", "provincecode": "220000", "city": "\u677E\u539F\u5E02", "code": "220700", "initial": "S" }, { "id": "63", "provincecode": "230000", "city": "\u53CC\u9E2D\u5C71\u5E02", "code": "230500", "initial": "S" }, { "id": "70", "provincecode": "230000", "city": "\u7EE5\u5316\u5E02", "code": "231200", "initial": "S" }, { "id": "78", "provincecode": "320000", "city": "\u82CF\u5DDE\u5E02", "code": "320500", "initial": "S" }, { "id": "86", "provincecode": "320000", "city": "\u5BBF\u8FC1\u5E02", "code": "321300", "initial": "S" }, { "id": "92", "provincecode": "330000", "city": "\u7ECD\u5174\u5E02", "code": "330600", "initial": "S" }, { "id": "109", "provincecode": "340000", "city": "\u5BBF\u5DDE\u5E02", "code": "341300", "initial": "S" }, { "id": "118", "provincecode": "350000", "city": "\u4E09\u660E\u5E02", "code": "350400", "initial": "S" }, { "id": "134", "provincecode": "360000", "city": "\u4E0A\u9976\u5E02", "code": "361100", "initial": "S" }, { "id": "163", "provincecode": "410000", "city": "\u4E09\u95E8\u5CE1\u5E02", "code": "411200", "initial": "S" }, { "id": "165", "provincecode": "410000", "city": "\u5546\u4E18\u5E02", "code": "411400", "initial": "S" }, { "id": "171", "provincecode": "420000", "city": "\u5341\u5830\u5E02", "code": "420300", "initial": "S" }, { "id": "180", "provincecode": "420000", "city": "\u968F\u5DDE\u5E02", "code": "421300", "initial": "S" }, { "id": "187", "provincecode": "430000", "city": "\u90B5\u9633\u5E02", "code": "430500", "initial": "S" }, { "id": "198", "provincecode": "440000", "city": "\u97F6\u5173\u5E02", "code": "440200", "initial": "S" }, { "id": "199", "provincecode": "440000", "city": "\u6DF1\u5733\u5E02", "code": "440300", "initial": "S" }, { "id": "201", "provincecode": "440000", "city": "\u6C55\u5934\u5E02", "code": "440500", "initial": "S" }, { "id": "209", "provincecode": "440000", "city": "\u6C55\u5C3E\u5E02", "code": "441500", "initial": "S" }, { "id": "233", "provincecode": "460000", "city": "\u4E09\u4E9A\u5E02", "code": "460200", "initial": "S" }, { "id": "245", "provincecode": "510000", "city": "\u9042\u5B81\u5E02", "code": "510900", "initial": "S" }, { "id": "274", "provincecode": "530000", "city": "\u601D\u8305\u5E02", "code": "530800", "initial": "S" }, { "id": "286", "provincecode": "540000", "city": "\u5C71\u5357\u5730\u533A", "code": "542200", "initial": "S" }, { "id": "300", "provincecode": "610000", "city": "\u5546\u6D1B\u5E02", "code": "611000", "initial": "S" }, { "id": "324", "provincecode": "640000", "city": "\u77F3\u5634\u5C71\u5E02", "code": "640200", "initial": "S" }, { "id": "3", "provincecode": "130000", "city": "\u5510\u5C71\u5E02", "code": "130200", "initial": "T" }, { "id": "13", "provincecode": "140000", "city": "\u592A\u539F\u5E02", "code": "140100", "initial": "T" }, { "id": "28", "provincecode": "150000", "city": "\u901A\u8FBD\u5E02", "code": "150500", "initial": "T" }, { "id": "47", "provincecode": "210000", "city": "\u94C1\u5CAD\u5E02", "code": "211200", "initial": "T" }, { "id": "54", "provincecode": "220000", "city": "\u901A\u5316\u5E02", "code": "220500", "initial": "T" }, { "id": "85", "provincecode": "320000", "city": "\u6CF0\u5DDE\u5E02", "code": "321200", "initial": "T" }, { "id": "96", "provincecode": "330000", "city": "\u53F0\u5DDE\u5E02", "code": "331000", "initial": "T" }, { "id": "104", "provincecode": "340000", "city": "\u94DC\u9675\u5E02", "code": "340700", "initial": "T" }, { "id": "143", "provincecode": "370000", "city": "\u6CF0\u5B89\u5E02", "code": "370900", "initial": "T" }, { "id": "263", "provincecode": "520000", "city": "\u94DC\u4EC1\u5730\u533A", "code": "522200", "initial": "T" }, { "id": "292", "provincecode": "610000", "city": "\u94DC\u5DDD\u5E02", "code": "610200", "initial": "T" }, { "id": "305", "provincecode": "620000", "city": "\u5929\u6C34\u5E02", "code": "620500", "initial": "T" }, { "id": "330", "provincecode": "650000", "city": "\u5410\u9C81\u756A\u5730\u533A", "code": "652100", "initial": "T" }, { "id": "340", "provincecode": "650000", "city": "\u5854\u57CE\u5730\u533A", "code": "654200", "initial": "T" }, { "id": "343", "provincecode": "120000", "city": "\u5929\u6D25\u5E02", "code": "120100", "initial": "T" }, { "id": "26", "provincecode": "150000", "city": "\u4E4C\u6D77\u5E02", "code": "150300", "initial": "W" }, { "id": "32", "provincecode": "150000", "city": "\u4E4C\u5170\u5BDF\u5E03\u5E02", "code": "150900", "initial": "W" }, { "id": "75", "provincecode": "320000", "city": "\u65E0\u9521\u5E02", "code": "320200", "initial": "W" }, { "id": "89", "provincecode": "330000", "city": "\u6E29\u5DDE\u5E02", "code": "330300", "initial": "W" }, { "id": "99", "provincecode": "340000", "city": "\u829C\u6E56\u5E02", "code": "340200", "initial": "W" }, { "id": "141", "provincecode": "370000", "city": "\u6F4D\u574A\u5E02", "code": "370700", "initial": "W" }, { "id": "144", "provincecode": "370000", "city": "\u5A01\u6D77\u5E02", "code": "371000", "initial": "W" }, { "id": "169", "provincecode": "420000", "city": "\u6B66\u6C49\u5E02", "code": "420100", "initial": "W" }, { "id": "221", "provincecode": "450000", "city": "\u68A7\u5DDE\u5E02", "code": "450400", "initial": "W" }, { "id": "278", "provincecode": "530000", "city": "\u6587\u5C71\u58EE\u65CF\u82D7\u65CF\u81EA\u6CBB\u5DDE", "code": "532600", "initial": "W" }, { "id": "295", "provincecode": "610000", "city": "\u6E2D\u5357\u5E02", "code": "610500", "initial": "W" }, { "id": "306", "provincecode": "620000", "city": "\u6B66\u5A01\u5E02", "code": "620600", "initial": "W" }, { "id": "325", "provincecode": "640000", "city": "\u5434\u5FE0\u5E02", "code": "640300", "initial": "W" }, { "id": "328", "provincecode": "650000", "city": "\u4E4C\u9C81\u6728\u9F50\u5E02", "code": "650100", "initial": "W" }, { "id": "6", "provincecode": "130000", "city": "\u90A2\u53F0\u5E02", "code": "130500", "initial": "X" }, { "id": "21", "provincecode": "140000", "city": "\u5FFB\u5DDE\u5E02", "code": "140900", "initial": "X" }, { "id": "33", "provincecode": "150000", "city": "\u5174\u5B89\u76DF", "code": "152200", "initial": "X" }, { "id": "34", "provincecode": "150000", "city": "\u9521\u6797\u90ED\u52D2\u76DF", "code": "152500", "initial": "X" }, { "id": "76", "provincecode": "320000", "city": "\u5F90\u5DDE\u5E02", "code": "320300", "initial": "X" }, { "id": "114", "provincecode": "340000", "city": "\u5BA3\u57CE\u5E02", "code": "341800", "initial": "X" }, { "id": "116", "provincecode": "350000", "city": "\u53A6\u95E8\u5E02", "code": "350200", "initial": "X" }, { "id": "128", "provincecode": "360000", "city": "\u65B0\u4F59\u5E02", "code": "360500", "initial": "X" }, { "id": "158", "provincecode": "410000", "city": "\u65B0\u4E61\u5E02", "code": "410700", "initial": "X" }, { "id": "161", "provincecode": "410000", "city": "\u8BB8\u660C\u5E02", "code": "411000", "initial": "X" }, { "id": "166", "provincecode": "410000", "city": "\u4FE1\u9633\u5E02", "code": "411500", "initial": "X" }, { "id": "173", "provincecode": "420000", "city": "\u8944\u6A0A\u5E02", "code": "420600", "initial": "X" }, { "id": "176", "provincecode": "420000", "city": "\u5B5D\u611F\u5E02", "code": "420900", "initial": "X" }, { "id": "179", "provincecode": "420000", "city": "\u54B8\u5B81\u5E02", "code": "421200", "initial": "X" }, { "id": "185", "provincecode": "430000", "city": "\u6E58\u6F6D\u5E02", "code": "430300", "initial": "X" }, { "id": "196", "provincecode": "430000", "city": "\u6E58\u897F\u571F\u5BB6\u65CF\u82D7\u65CF\u81EA\u6CBB\u5DDE", "code": "433100", "initial": "X" }, { "id": "279", "provincecode": "530000", "city": "\u897F\u53CC\u7248\u7EB3\u50A3\u65CF\u81EA\u6CBB\u5DDE", "code": "532800", "initial": "X" }, { "id": "291", "provincecode": "610000", "city": "\u897F\u5B89\u5E02", "code": "610100", "initial": "X" }, { "id": "294", "provincecode": "610000", "city": "\u54B8\u9633\u5E02", "code": "610400", "initial": "X" }, { "id": "315", "provincecode": "630000", "city": "\u897F\u5B81\u5E02", "code": "630100", "initial": "X" }, { "id": "15", "provincecode": "140000", "city": "\u9633\u6CC9\u5E02", "code": "140300", "initial": "Y" }, { "id": "20", "provincecode": "140000", "city": "\u8FD0\u57CE\u5E02", "code": "140800", "initial": "Y" }, { "id": "43", "provincecode": "210000", "city": "\u8425\u53E3\u5E02", "code": "210800", "initial": "Y" }, { "id": "58", "provincecode": "220000", "city": "\u5EF6\u8FB9\u671D\u9C9C\u65CF\u81EA\u6CBB\u5DDE", "code": "222400", "initial": "Y" }, { "id": "65", "provincecode": "230000", "city": "\u4F0A\u6625\u5E02", "code": "230700", "initial": "Y" }, { "id": "82", "provincecode": "320000", "city": "\u76D0\u57CE\u5E02", "code": "320900", "initial": "Y" }, { "id": "83", "provincecode": "320000", "city": "\u626C\u5DDE\u5E02", "code": "321000", "initial": "Y" }, { "id": "129", "provincecode": "360000", "city": "\u9E70\u6F6D\u5E02", "code": "360600", "initial": "Y" }, { "id": "132", "provincecode": "360000", "city": "\u5B9C\u6625\u5E02", "code": "360900", "initial": "Y" }, { "id": "140", "provincecode": "370000", "city": "\u70DF\u53F0\u5E02", "code": "370600", "initial": "Y" }, { "id": "172", "provincecode": "420000", "city": "\u5B9C\u660C\u5E02", "code": "420500", "initial": "Y" }, { "id": "188", "provincecode": "430000", "city": "\u5CB3\u9633\u5E02", "code": "430600", "initial": "Y" }, { "id": "191", "provincecode": "430000", "city": "\u76CA\u9633\u5E02", "code": "430900", "initial": "Y" }, { "id": "193", "provincecode": "430000", "city": "\u6C38\u5DDE\u5E02", "code": "431100", "initial": "Y" }, { "id": "211", "provincecode": "440000", "city": "\u9633\u6C5F\u5E02", "code": "441700", "initial": "Y" }, { "id": "217", "provincecode": "440000", "city": "\u4E91\u6D6E\u5E02", "code": "445300", "initial": "Y" }, { "id": "226", "provincecode": "450000", "city": "\u7389\u6797\u5E02", "code": "450900", "initial": "Y" }, { "id": "250", "provincecode": "510000", "city": "\u5B9C\u5BBE\u5E02", "code": "511500", "initial": "Y" }, { "id": "253", "provincecode": "510000", "city": "\u96C5\u5B89\u5E02", "code": "511800", "initial": "Y" }, { "id": "270", "provincecode": "530000", "city": "\u7389\u6EAA\u5E02", "code": "530400", "initial": "Y" }, { "id": "296", "provincecode": "610000", "city": "\u5EF6\u5B89\u5E02", "code": "610600", "initial": "Y" }, { "id": "298", "provincecode": "610000", "city": "\u6986\u6797\u5E02", "code": "610800", "initial": "Y" }, { "id": "321", "provincecode": "630000", "city": "\u7389\u6811\u85CF\u65CF\u81EA\u6CBB\u5DDE", "code": "632700", "initial": "Y" }, { "id": "323", "provincecode": "640000", "city": "\u94F6\u5DDD\u5E02", "code": "640100", "initial": "Y" }, { "id": "339", "provincecode": "650000", "city": "\u4F0A\u7281\u54C8\u8428\u514B\u81EA\u6CBB\u5DDE", "code": "654000", "initial": "Y" }, { "id": "8", "provincecode": "130000", "city": "\u5F20\u5BB6\u53E3\u5E02", "code": "130700", "initial": "Z" }, { "id": "84", "provincecode": "320000", "city": "\u9547\u6C5F\u5E02", "code": "321100", "initial": "Z" }, { "id": "95", "provincecode": "330000", "city": "\u821F\u5C71\u5E02", "code": "330900", "initial": "Z" }, { "id": "120", "provincecode": "350000", "city": "\u6F33\u5DDE\u5E02", "code": "350600", "initial": "Z" }, { "id": "137", "provincecode": "370000", "city": "\u6DC4\u535A\u5E02", "code": "370300", "initial": "Z" }, { "id": "138", "provincecode": "370000", "city": "\u67A3\u5E84\u5E02", "code": "370400", "initial": "Z" }, { "id": "152", "provincecode": "410000", "city": "\u90D1\u5DDE\u5E02", "code": "410100", "initial": "Z" }, { "id": "167", "provincecode": "410000", "city": "\u5468\u53E3\u5E02", "code": "411600", "initial": "Z" }, { "id": "168", "provincecode": "410000", "city": "\u9A7B\u9A6C\u5E97\u5E02", "code": "411700", "initial": "Z" }, { "id": "184", "provincecode": "430000", "city": "\u682A\u6D32\u5E02", "code": "430200", "initial": "Z" }, { "id": "190", "provincecode": "430000", "city": "\u5F20\u5BB6\u754C\u5E02", "code": "430800", "initial": "Z" }, { "id": "200", "provincecode": "440000", "city": "\u73E0\u6D77\u5E02", "code": "440400", "initial": "Z" }, { "id": "204", "provincecode": "440000", "city": "\u6E5B\u6C5F\u5E02", "code": "440800", "initial": "Z" }, { "id": "206", "provincecode": "440000", "city": "\u8087\u5E86\u5E02", "code": "441200", "initial": "Z" }, { "id": "214", "provincecode": "440000", "city": "\u4E2D\u5C71\u5E02", "code": "442000", "initial": "Z" }, { "id": "239", "provincecode": "510000", "city": "\u81EA\u8D21\u5E02", "code": "510300", "initial": "Z" }, { "id": "255", "provincecode": "510000", "city": "\u8D44\u9633\u5E02", "code": "512000", "initial": "Z" }, { "id": "261", "provincecode": "520000", "city": "\u9075\u4E49\u5E02", "code": "520300", "initial": "Z" }, { "id": "272", "provincecode": "530000", "city": "\u662D\u901A\u5E02", "code": "530600", "initial": "Z" }, { "id": "307", "provincecode": "620000", "city": "\u5F20\u6396\u5E02", "code": "620700", "initial": "Z" }, { "id": "327", "provincecode": "640000", "city": "\u4E2D\u536B\u5E02", "code": "640500", "initial": "Z" }];

//城市检索的首字母
var searchLetter = ["A", "B", "C", "D", "E", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "W", "X", "Y", "Z"];

function searchLetter() {
    return searchLetter;
}

//对城市信息进行分组
function cityList() {

    var tempObj = [];
    for (var i = 0; i < searchLetter.length; i++) {
        var initial = searchLetter[i];
        var cityInfo = [];
        var tempArr = {};
        tempArr.initial = initial;
        for (var j = 0; j < cityObj.length; j++) {
            if (initial == cityObj[j].initial) {
                cityInfo.push(cityObj[j]);
            }
        }
        tempArr.cityInfo = cityInfo;
        tempObj.push(tempArr);
    }
    return tempObj;
}

function pushCity() {}

module.exports = {
    searchLetter: searchLetter,
    cityList: cityList
};
});
define("util/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

function formatTime(phpDate) {
    var date = new Date(parseInt(phpDate) * 1000);
    var year = date.getFullYear();
    var month = formatNumber(date.getMonth() + 1);
    var day = formatNumber(date.getDate());

    var hour = date.getHours();
    var minute = date.getMinutes();

    // var date = formatNumber(month) + "月" + formatNumber(day) + "日 ";
    var time = formatNumber(hour) + ":" + formatNumber(minute);

    return [year, month, day, time];
}

function formatRemainTime(phpDate) {
    var hour = Math.floor(phpDate / 3600),
        min = Math.floor(phpDate % 3600 / 60),
        sec = phpDate % 60;

    var time = formatNumber(hour) + ":" + formatNumber(min) + ":" + formatNumber(sec);

    return time;
}

function formatNumber(n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
}

module.exports = {
    formatTime: formatTime,
    formatRemainTime: formatRemainTime
};
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

//app.js
App({
    // 将 HTML 格式转换为普通文本
    strip_tags: function strip_tags(input, allowed) {
        allowed = (((allowed || "") + "").toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)
        var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
            commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
        return input.replace(commentsAndPhpTags, '').replace(tags, function ($0, $1) {
            return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
        });
    },
    onError: function onError(err) {
        console.log('app err ...', err);
    },

    onLaunch: function onLaunch() {
        console.log('app on launch... ', wx.getExtConfigSync);
        //读取一下ext配置
        if (wx.getExtConfigSync) {
            var ext = wx.getExtConfigSync();
            if (ext.server_url) this.globalData.server_url = ext.server_url;
            if (ext.prefix_url) this.globalData.prefix_url = ext.prefix_url;
            if (ext.sp_name) this.globalData.sp_name = ext.sp_name;
            if (ext.main_color) this.globalData.main_color = ext.main_color;
            console.log('[info] get cfg from ext... ', ext);
            if (ext.sp_name) wx.setNavigationBarTitle({ title: ext.sp_name });
        } else {
            console.log('[info] wx.getExtConfigSync not exist ... ');
        }
        console.info('rmt address is ', this.globalData.server_url);

        //自动登录一下
        this.getUserInfo();
    },

    alert: function alert(str) {
        wx.showModal({ 'title': '提示',
            'content': str,
            'showCancel': false,
            'confirmColor': '#FF0000'
        });
    },

    confirm: function confirm(str, cb) {
        wx.showModal({
            'content': str,
            'success': function success(res) {
                if (res.confirm) {
                    typeof cb == 'function' && cb();
                }
            }
        });
    },

    //发送请求, 如果没登录会尝试自动登录
    request: function request(object) {
        var that = this;
        if (!object.url.startsWith('https')) {
            object.url = this.globalData.server_url + object.url;
        }

        if (!object.header) object.header = {};
        var cookie = object.header.cookie || '';
        if (this.globalData.PHPSESSID) {
            if (cookie) cookie += '; ';
            cookie += 'PHPSESSID=' + this.globalData.PHPSESSID;
        }
        object.header.cookie = cookie;

        if (object.method && object.method == 'POST') {
            object.header['content-type'] = 'application/x-www-form-urlencoded';
        }
        var success = object.success;
        var done = 0;
        setTimeout(function () {
            if (!done) wx.showToast({ title: '加载中。。。',
                icon: 'loading',
                duration: 10000 });
        }, 2000);

        object.success = function (ret) {
            //自动登录
            done = 1;
            wx.hideToast();
            //console.log('ajax return ... ', ret);
            if (ret.data.errno == '402') {
                if (!object._retry_login) {
                    object._retry_login = 1;
                } else if (object._retry_login > 1) {
                    console.warn('wx request failed!user has not login!');
                    return false;
                }
                //ERROR_USER_HAS_NOT_LOGIN 没登录，重试一下
                that.globalData.userInfo = null;
                that.getUserInfo(function () {
                    object.success = success;
                    object._retry_login += 1;
                    that.request(object);
                });
                return;
            }

            typeof success == 'function' && success(ret.data);
        };
        object.fail = function () {
            done = 1;
            wx.hideToast();
            that.alert('网络请求失败！');
        };
        return wx.request(object);
    },

    //用户登录, 登录到了自己的服务器
    getUserInfo: function getUserInfo(cb) {
        var that = this;
        if (this.globalData.userInfo) {
            typeof cb == "function" && cb(this.globalData.userInfo);
        } else {
            //调用登录接口
            wx.login({
                success: function success(ret) {
                    console.log('wx init login ok ...', ret);
                    wx.getUserInfo({
                        success: function success(res) {
                            console.log('get user info ok ...', res);
                            if (!res.encryptedData) {
                                var data = {
                                    name: res.userInfo.nickName,
                                    avatar: res.userInfo.avatarUrl
                                    //, '_d':1  // 测试用参数
                                };
                            } else {
                                var data = { code: ret.code, encryptedData: res.encryptedData, iv: res.iv };
                            }
                            that.request({
                                'url': '_u=xiaochengxu.login', 'method': 'POST',
                                'data': data,
                                'success': function success(ret) {
                                    console.log('xiaochengxu login ret... ', ret.data);
                                    var data = ret.data;
                                    that.globalData.su_uid = data.su_uid;
                                    console.log('wxapp su_uid', data.su_uid);
                                    that.globalData.openid = data.open_id;
                                    that.globalData.PHPSESSID = data.PHPSESSID;
                                    that.globalData.userInfo = res.userInfo;
                                    typeof cb == "function" && cb(that.globalData.userInfo);
                                },
                                'fail': function fail(ret) {
                                    console.log("xiaochengxu login fail ret >>>", ret);
                                }
                            });
                            that.request({
                                url: "_a=shop&_u=ajax.shop",
                                success: function success(ret) {
                                    console.log("get shop color >>>", ret);
                                    that.globalData.main_color = "#" + ret.data.color1;
                                }
                            });
                        },
                        fail: function fail(res) {
                            console.log('failed ...', res);
                            that.alert('无法获取账号信息，小程序功能将无法正常使用！');
                        }
                    });
                }

            });
        }
    },

    globalData: {
        userInfo: null
        //浏览天下
        , server_url: 'https://weixin.uctphp.com/?_uct_token=66714053a0e2028f77886828a754e8da&',
        prefix_url: 'https://weixin.uctphp.com/'
        //,server_url:'http://localhost:8001/?_uct_token=66714053a0e2028f77886828a754e8da&'
        //,prefix_url:'http://localhost:8001/'
        , sp_name: null,
        main_color: '#884898' //todo 小程序主色调
        // ,main_color: '#4a9efe' //todo 小程序主色调
        , company_name: '',
        su_uid: null,
        PHPSESSID: null,
        openid: ''

    }
});
});require("app.js")
var __wxRoute = "pages/business/business", __wxRouteBegin = true;
define("pages/business/business.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({

    data: {
        businessList: [],
        type: "",

        background: [],
        tabs: [],
        activeIndex: 0,
        sliderOffset: 0,
        sliderLeft: 0,
        sliderWidth: 0,
        navboxWidth: 0,
        navWidth: 0
    },

    onLoad: function onLoad(options) {
        var that = this;
        this.setData({
            mainColor: app.globalData.main_color
        });

        // 获取商家分类
        that.getBizCat();

        // 是否授权获取位置
        that.checkLocAuth();

        // 获取商家列表
        that.getBizlist(0);

        // 获取推荐商家列表
        that.getRecommendList();

        // 获取首页头部轮播图
        app.request({
            url: "_u=common.slides_list&pos=biz1",
            success: function success(ret) {
                console.log("background ret >>>>>", ret);
                var sliders = ret.data.list;
                sliders.forEach(function (ele) {
                    if (ele.image && !ele.image.startsWith('http')) ele.image = app.globalData.prefix_url + ele.image;
                });
                that.setData({
                    background: sliders
                });
            }
        });
    },

    onShow: function onShow() {
        // 获取商户信息
        this.getBusiness();
    },

    // 获取商家信息
    getBusiness: function getBusiness(cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_biz",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.setData({
                        businessData: ret.data
                    });
                }
            }
        });
    },

    // 获取当前位置
    checkLocAuth: function checkLocAuth(cb) {
        var that = this;

        wx.authorize({
            scope: 'scope.userLocation',
            success: function success() {
                that.getLocation();
            },
            fail: function fail() {
                wx.showModal({
                    title: "温馨提示",
                    content: "获取您的当前位置可提供更多信息，是否授权？",
                    confirmText: "去授权",
                    showCancel: false,
                    success: function success(ret) {
                        if (ret.confirm) {
                            wx.openSetting({
                                success: function success(ret) {
                                    if (ret.authSetting['scope.userLocation']) {
                                        that.getLocation();
                                    }
                                }
                            });
                        }
                    }
                });
            }
        });
    },

    // 获取当前地理位置
    getLocation: function getLocation() {
        var that = this;

        wx.getLocation({
            success: function success(ret) {
                console.log("get current position ret >>>>", ret);
                that.setData({
                    position: ret
                });
                that.getBizlist(0);
            }
        });
    },

    // 小导航
    subNavTap: function subNavTap(e) {
        var subNav = e.currentTarget.dataset.set,
            subUrl = subNav.link;

        if (!subUrl) return;

        if (subUrl.startsWith("map")) {
            var locArr = subUrl.split("-"),
                lat = parseFloat(locArr[1]),
                lng = parseFloat(locArr[2]),
                title = locArr[3];
            wx.openLocation({
                latitude: lat,
                longitude: lng,
                scale: 18,
                name: title
                // address:'金平区长平路93号'
            });
        } else if (subUrl.startsWith("phone")) {
            var phone = subUrl.split("-")[1];
            wx.makePhoneCall({
                phoneNumber: phone
            });
        } else if (subUrl.startsWith("app")) {
            var appId = subUrl.split("-")[1];
            wx.navigateToMiniProgram({
                appId: appId,
                // path: 'pages/index/index?id=123',
                extraData: {
                    fromApp: 'mall'
                },
                // envVersion: 'develop',
                success: function success(res) {
                    // 打开成功
                }
            });
        } else if (subUrl.startsWith("web")) {
            var webUrl = subUrl.split("-")[1];
            wx.navigateTo({
                url: "pages/webPage/webPage?url=" + webUrl
            });
        } else if (subUrl.startsWith("vedio")) {
            var vedioUrl = encodeURI(subUrl.split("-")[1]);
            wx.navigateTo({
                url: "pages/vedioPage/vedioPage?url=" + vedioUrl
            });
        } else {
            wx.navigateTo({
                url: subUrl
            });
        }
    },

    // 点击入驻
    joinTap: function joinTap() {
        var businessData = this.data.businessData;
        var link = "";

        if (businessData.status == 1) {
            link = "/pages/businessCenter/businessCenter";
        } else {
            link = "/pages/apply/apply";
        }

        wx.navigateTo({
            url: link
        });
    },

    // 获取商家分类
    getBizCat: function getBizCat() {
        var that = this;

        app.request({
            url: "_a=shop&_u=ajax.biz_cats",
            success: function success(ret) {
                console.log("get business cat ret >>>", ret);
                var tabs = ret.data.unshift({ title: "全部" });
                that.setData({
                    tabs: ret.data
                });
                that.initNavigations();
            }
        });
    },

    // 初始化分类导航栏
    initNavigations: function initNavigations() {
        var that = this;
        var tabNums = that.data.tabs.length;
        var sliderWidth, sliderLeft, sliderOffset, navboxWidth, navWidth;

        if (tabNums < 5) {
            sliderWidth = 96;

            wx.getSystemInfo({
                success: function success(res) {
                    sliderLeft = (res.windowWidth / tabNums - sliderWidth) / 2;
                    sliderOffset = res.windowWidth / tabNums * that.data.activeIndex;
                    navboxWidth = res.windowWidth;
                    navWidth = 2 * res.windowWidth / tabNums;
                }
            });
        } else {
            sliderWidth = 65;
            sliderLeft = (75 - sliderWidth) / 2;
            sliderOffset = 75 * that.data.activeIndex;
            navboxWidth = tabNums * 75;
            navWidth = 500;
        }

        that.setData({
            sliderWidth: sliderWidth,
            sliderLeft: sliderLeft,
            sliderOffset: sliderOffset,
            navboxWidth: navboxWidth,
            navWidth: navWidth
        });
    },

    // 获取商家列表
    getBizlist: function getBizlist(page) {
        var that = this,
            type = that.data.type,
            position = that.data.position;
        if (type == "全部") type = "";

        var postData = { type: type, limit: 10, page: page };

        // 是否获取当前位置
        if (position) {
            postData.lat = position.latitude;
            postData.lng = position.longitude;
            postData.sort = 3;
        }

        app.request({
            url: "_a=shop&_u=biz.ajax_bizlist",
            data: postData,
            success: function success(ret) {
                console.log("business ret >>>", ret);
                var businessList = ret.data.list,
                    len = businessList.length;

                businessList.forEach(function (ele) {
                    if (!ele.main_img.startsWith("http")) ele.main_img = app.globalData.prefix_url + ele.main_img;
                    if (ele.juli) ele.juli = parseFloat(ele.juli).toFixed(1);
                });

                var list = page == 0 ? [] : that.data.businessList;
                list = list.concat(businessList);

                that.setData({
                    businessList: list,
                    page: page,
                    showEmpty: len < 10
                });
                wx.hideLoading();
            }
        });
    },

    // 获取推荐商家列表
    getRecommendList: function getRecommendList() {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_bizlist",
            data: {
                limit: -1,
                hadrecommend: 1
            },
            success: function success(ret) {
                console.log("getRecommendList ret >>>", ret);
                var recommendList = ret.data.list;
                recommendList.forEach(function (ele) {
                    if (!ele.main_img.startsWith("http")) ele.main_img = app.globalData.prefix_url + ele.main_img;
                });

                that.setData({
                    recommendList: recommendList
                });
            }
        });
    },

    tabClick: function tabClick(e) {
        // wx.showLoading({
        //     title: '加载中',
        // });
        this.setData({
            type: e.currentTarget.dataset.type,
            sliderOffset: e.currentTarget.offsetLeft,
            activeIndex: e.currentTarget.id
        });
        this.getBizlist(0);
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onReachBottom: function onReachBottom() {
        var that = this,
            page = that.data.page + 1;

        that.getBizlist(page);
        that.setData({
            page: page
        });
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/business/business.js")
var __wxRoute = "pages/index/index", __wxRouteBegin = true;
define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var sliderWidth = 96;
var app = getApp();
var util = require('../../util/util.js');

Page({
    data: {
        activeIndex: 0,
        sliderOffset: 0,
        sliderLeft: 0,
        sliderWidth: sliderWidth,
        tabs: ['最新发布', '距离最近'],
        currentCity: "全国",
        switchCity: true,

        noMore: false,

        timeList: [],
        timePage: 0,
        disList: [],
        distancePage: 0,
        showList: [],

        // 评论框
        showCommentModal: false,
        parentId: 0
    },

    onLoad: function onLoad(options) {
        var that = this;

        // 导航栏函数
        wx.getSystemInfo({
            success: function success(res) {
                that.setData({
                    windowWidth: res.windowWidth,
                    sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
                    sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
                });
            }
        });
        var currentCity = wx.getStorageSync("city");
        if (currentCity) {
            that.setData({
                currentCity: currentCity
            });
        }

        that.getAllCats();
        that.getBanners();
        // that.getLocation();
        that.getBasicInfo();
    },

    onShow: function onShow() {
        var that = this;

        if (that.data.switchCity) {
            wx.setStorage({
                key: "city",
                data: that.data.currentCity
            });

            this.setData({
                timeList: [],
                timePage: 0,
                disList: [],
                distancePage: 0,
                showList: [],

                switchCity: false
            });

            if (that.data.activeIndex == 0) {
                that.getMsgList('time', null, 0);
            } else {
                that.getLocation(function (loc) {
                    that.setData({
                        loc: loc
                    });
                    that.getMsgList('distance', loc, 0);
                });
            }
        }
    },

    // 获取轮播图
    getBanners: function getBanners() {
        var that = this;
        // 获取首页头部轮播图
        app.request({
            url: "_u=common.slides_list",
            data: {
                pos: 'class1'
            },
            success: function success(ret) {
                var sliders = ret.data.list;
                if (sliders && sliders.length > 0) {
                    sliders.forEach(function (ele) {
                        ele.img = app.globalData.prefix_url + ele.image;
                    });
                    that.setData({
                        background: sliders
                    });
                }
            }
        });
    },

    // 小导航
    subNavTap: function subNavTap(e) {
        var subNav = e.currentTarget.dataset.set,
            subUrl = subNav.link;

        if (!subUrl) return;

        if (subUrl.startsWith("map")) {
            var locArr = subUrl.split("-"),
                lat = parseFloat(locArr[1]),
                lng = parseFloat(locArr[2]),
                title = locArr[3];
            wx.openLocation({
                latitude: lat,
                longitude: lng,
                scale: 18,
                name: title
                // address:'金平区长平路93号'
            });
        } else if (subUrl.startsWith("phone")) {
            var phone = subUrl.split("-")[1];
            wx.makePhoneCall({
                phoneNumber: phone
            });
        } else if (subUrl.startsWith("app")) {
            var appId = subUrl.split("-")[1];
            wx.navigateToMiniProgram({
                appId: appId,
                // path: 'pages/index/index?id=123',
                extraData: {
                    fromApp: 'mall'
                },
                // envVersion: 'develop',
                success: function success(res) {
                    // 打开成功
                }
            });
        } else if (subUrl.startsWith("web")) {
            var webUrl = subUrl.split("-")[1];
            wx.navigateTo({
                url: "pages/webPage/webPage?url=" + webUrl
            });
        } else if (subUrl.startsWith("vedio")) {
            var vedioUrl = encodeURI(subUrl.split("-")[1]);
            wx.navigateTo({
                url: "pages/vedioPage/vedioPage?url=" + vedioUrl
            });
        } else {
            wx.navigateTo({
                url: subUrl
            });
        }
    },

    // 获取所有分类   
    getAllCats: function getAllCats(cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_cats',
            success: function success(ret) {
                console.log("all cats >>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var list = ret.data;
                    list.forEach(function (ele) {
                        ele.image = app.globalData.prefix_url + ele.image;
                    });
                    that.setData({
                        cats: list
                    });
                }
            }
        });
    },

    // 获取基本信息 如小程序标题
    getBasicInfo: function getBasicInfo() {
        var that = this;

        app.request({
            url: "_a=classmsg&_u=ajax.get_sets",
            success: function success(ret) {
                console.log("basic info >>>>", ret);
                wx.setNavigationBarTitle({
                    title: ret.data.title
                });
            }
        });
    },

    // 获取用户地理位置
    getLocation: function getLocation(cb) {
        var that = this;

        wx.getLocation({
            success: function success(res) {
                if (typeof cb == 'function') {
                    cb(res);
                } else {
                    // var requestUrl = '_easy=web.index.geo2name&lat='+res.latitude+'&lng='+res.longitude+'&type=tencent';
                    // app.request({
                    //     url: requestUrl,
                    //     success: function(ret) {
                    //         console.log("address >>>>>", ret);
                    //         var city = ret.data.address_component.city.replace("市", "");

                    //         that.setData({
                    //             currentCity: city
                    //         });
                    //         that.getMsgList('time', null, 0);
                    //     }
                    // });
                    // that.getMsgList('time', null, 0);
                }
            },
            fail: function fail() {
                wx.showModal({
                    title: '获取位置失败',
                    content: '请检查您的网络，以及是否禁用位置',
                    showFalse: false
                });
                // var windowWidth = that.data.windowWidth,
                // sliderOffset = windowWidth / 2 * that.data.activeIndex
                that.setData({
                    sliderOffset: 0,
                    activeIndex: 0,
                    currentCity: "深圳"
                });
            }
        });
    },

    // 获取信息列表
    getMsgList: function getMsgList(type, loc, page, cb) {
        var that = this,
            requestData = {},
            city = that.data.currentCity;

        city == "全国" && (city = "");

        if (type == 'time') {
            requestData = {
                sort: 2,
                address: city,
                page: page
            };
        } else if (type == 'distance') {
            requestData = {
                sort: 3,
                address: city,
                lat: loc.latitude,
                lng: loc.longitude,
                page: page
            };
        }

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_by_cat_uid',
            data: requestData,
            success: function success(ret) {
                console.log("getMsgList ret >>>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    // that.getMsgListCb(ret);
                    // var that = this;
                    var list = ret.data.list;

                    list.forEach(function (ele) {
                        // 处理时间
                        var time = util.formatTime(ele.create_time);
                        ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                        // 判断是否包含图片
                        if (ele.images && ele.images.length !== 0) {
                            for (var i = 0; i < ele.images.length; i++) {
                                ele.images[i] = app.globalData.prefix_url + ele.images[i];
                            }
                        }

                        // 区别商家和用户
                        if (ele.biz) {
                            var image = ele.biz.main_img;
                            // if (image.startsWith("http")) {}
                            ele.biz.main_img = image.startsWith("http") ? image : app.globalData.prefix_url + image;
                        }
                    });

                    if (type == 'time') {
                        var timeList = that.data.timeList.concat(list);
                        that.setData({
                            showList: timeList,
                            timeList: timeList
                        });
                    } else if (type == 'distance') {
                        var disList = that.data.disList.concat(list);
                        that.setData({
                            showList: disList,
                            disList: disList
                        });
                    }

                    that.setData({
                        noMore: list.length < 10
                    });

                    // 停止刷鞋
                    wx.stopPullDownRefresh();
                }
            }
        });
    },

    // 导航栏点击事件
    tabClick: function tabClick(e) {
        var that = this;
        var tabs = that.data.tabs;
        var selectedIndex = e.currentTarget.id;

        if (selectedIndex == 1) {
            if (that.data.disList.length == 0) {
                that.getLocation(function (loc) {
                    that.setData({
                        loc: loc
                    });
                    that.getMsgList('distance', loc, 0);
                });
            } else {
                that.setData({
                    showList: that.data.disList
                });
            }
        } else {
            if (that.data.disList.length == 0) {
                that.getMsgList('time', null, 0);
            } else {
                that.setData({
                    showList: that.data.timeList
                });
            }
        }

        that.setData({
            sliderOffset: e.currentTarget.offsetLeft,
            activeIndex: selectedIndex
        });
        // var list = selectedIndex == 0 ? that.data.timeList : that.data.disList;
    },

    // 联系发布者
    phoneCallTap: function phoneCallTap(e) {
        var number = e.currentTarget.id;
        wx.makePhoneCall({
            phoneNumber: number
        });
    },

    // 预览消息图片
    previewImages: function previewImages(e) {
        var id = e.currentTarget.id.split("-");
        console.log("image id >>>>>>", id);
        var idx = id[0],
            subIdx = id[1];

        var showList = this.data.showList,
            images = showList[idx].images,
            img = images[subIdx];

        wx.previewImage({
            current: img, // 当前显示图片的http链接
            urls: images // 需要预览的图片http链接列表
        });
    },

    // 点赞
    likeTap: function likeTap(e) {
        var that = this,
            id = e.currentTarget.id,
            like = e.currentTarget.dataset.like,
            showList = that.data.showList;

        app.request({
            url: '_a=classmsg&_u=ajax.add_good_cnt',
            data: {
                msg_uid: id
            },
            success: function success(ret) {
                console.log("like tap ret >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    if (like) {
                        wx.showToast({
                            title: '取消点赞成功'
                        });
                    } else {
                        wx.showToast({
                            title: '点赞成功'
                        });
                    }
                }
            }
        });

        showList.forEach(function (ele) {
            if (ele.uid == id) {
                ele.su_good = !ele.su_good;
                ele.su_good ? ele.good_cnt++ : ele.good_cnt--;
            }
        });

        that.setData({
            showList: showList
        });
    },

    // 评论
    commentTap: function commentTap(e) {
        var id = e.currentTarget.id;

        this.setData({
            showCommentModal: true,
            commentId: id
        });
    },
    // 提交评论
    bindFormSubmit: function bindFormSubmit(e) {
        var comment = e.detail.value.textarea;

        if (comment) {
            var that = this,
                commentId = that.data.commentId;
            // parentId = that.data.parentId;

            console.log("commentId >>>>", commentId);
            // console.log("parentId >>>>", parentId);

            app.request({
                url: "_a=classmsg&_u=ajax.add_comment",
                data: {
                    msg_uid: commentId,
                    // parent_uid: parentId,
                    content: comment
                },
                success: that.commentCallback
            });
        } else {
            wx.showModal({
                title: "清填写评论内容",
                showCancel: false
            });
        }
    },
    commentCallback: function commentCallback(ret) {
        var that = this;
        var options = that.data.options;
        console.log("comment ret >>>>", ret);

        if (ret.data && ret.data != 0) {
            that.setData({
                showCommentModal: false
                // parentId: 0
            });

            wx.showToast({
                title: "评论成功"
                // success: that.getComment(that.data.resourceId)
            });
        }
    },
    quitCommentTap: function quitCommentTap() {
        this.setData({
            showCommentModal: false
        });
    },

    // 回复评论
    // revertTap: function(e) {
    //     // console.log()
    //     var id = e.currentTarget.id.split('-');
    //     var commentId = id[0],
    //         parentId = id[1];

    //     this.setData({
    //         commentId: commentId,
    //         parentId: parentId,
    //         showCommentModal: true
    //     });
    // },

    // 下拉刷新
    // onPullDownRefresh: function(){
    //     this.setData({
    //         timeList: [],
    //         timePage: 0,
    //         disList: [],
    //         distancePage: 0,
    //         showList: []
    //     });
    //     this.onLoad();
    // },

    // 分享该页面
    onShareAppMessage: function onShareAppMessage() {},

    // 上拉加载
    onReachBottom: function onReachBottom() {
        console.log("onReachBottom reach bottom");
        var activeIndex = this.data.activeIndex;
        if (activeIndex == 0) {
            var page = this.data.timePage + 1;
            this.getMsgList('time', null, page);
            this.setData({
                timePage: page
            });
        } else {
            var page = this.data.distancePage + 1;
            var loc = this.data.loc;
            this.getMsgList('distance', loc, page);
            this.setData({
                distancePage: page
            });
        }
    }
});
});require("pages/index/index.js")
var __wxRoute = "pages/businessCenter/businessCenter", __wxRouteBegin = true;
define("pages/businessCenter/businessCenter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({

    data: {
        mainColor: app.globalData.main_color
    },

    onLoad: function onLoad(options) {
        this.setData({
            mainColor: app.globalData.main_color
        });
        this.getBizData();
    },

    onShow: function onShow() {
        this.getBusiness();
    },

    // 获取商家信息
    getBusiness: function getBusiness(cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_biz",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.getBusinessCb(ret);
                }
            }
        });
    },

    getBusinessCb: function getBusinessCb(ret) {
        var that = this;
        console.log("get business ret >>>>", ret);
        if (ret.data) {
            wx.setNavigationBarTitle({
                title: ret.data.title
            });
            that.setData({
                business: ret.data
            });
            var status = ret.data.status;
            if (status == 0) {
                wx.showModal({
                    title: "您的信息正在审核中，请耐心等待",
                    showCancel: false,
                    success: function success(res) {
                        if (res.confirm) {
                            wx.navigateBack();
                        }
                    }
                });
            } else if (status == 2) {
                wx.showModal({
                    title: "您的信息审核未通过，是否重新申请？",
                    confirmText: "重新申请",
                    success: function success(res) {
                        if (res.confirm) {
                            wx.navigateTo({
                                url: "../apply/apply"
                            });
                        } else {
                            wx.navigateBack();
                        }
                    }
                });
            }
        } else {
            wx.showModal({
                title: "您还不是商家",
                content: "是否申请成为商家？",
                confirmText: "去申请",
                success: function success(res) {
                    if (res.confirm) {
                        wx.redirectTo({
                            url: "../apply/apply"
                        });
                    } else {
                        wx.navigateBack();
                    }
                }
            });
        }
    },

    // 获取商家营业数据
    getBizData: function getBizData(cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=ajax.get_biz_cnt",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.initBizData(ret);
                }
            }
        });
    },

    // 初始化商家营业数据
    initBizData: function initBizData(ret) {
        console.log("data return >>>", ret);
        var bizData = ret.data;
        bizData.total_orders_paid = handlePrice(bizData.total_orders_paid);
        bizData.today_orders_paid = handlePrice(bizData.today_orders_paid);
        bizData.weekd_orders_create_paid = handlePrice(bizData.weekd_orders_create_paid);
        bizData.yesterday_orders_create_paid = handlePrice(bizData.yesterday_orders_create_paid);

        this.setData({
            bizData: bizData
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onReachBottom: function onReachBottom() {},

    onShareAppMessage: function onShareAppMessage() {}
});

// 处理价格函数
var handlePrice = function handlePrice(price) {
    return parseFloat(price / 100).toFixed(2);
};
});require("pages/businessCenter/businessCenter.js")
var __wxRoute = "pages/businessDetail/businessDetail", __wxRouteBegin = true;
define("pages/businessDetail/businessDetail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../util/util.js');
var page = 0;
var sliderWidth = 96;
var WxParse = require('../common/wxParse/wxParse.js');

Page({

    data: {
        mainColor: app.globalData.main_color,
        background: [],
        goods: [],
        page: 0,

        tabs: ["主页", "商品", "信息"],
        activeIndex: 0,
        sliderOffset: 0,
        sliderLeft: 0,
        // 评论框
        showCommentModal: false
    },

    onLoad: function onLoad(options) {
        console.log("options >>>>>", options);
        var that = this;
        this.setData({
            options: options,
            mainColor: app.globalData.main_color
        });
        var businessId = options.uid;

        wx.getSystemInfo({
            success: function success(res) {
                that.setData({
                    sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
                    sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
                });
            }
        });

        // 获取商家信息
        this.getBusinessData(businessId);

        // 获取该商家所有商品
        this.getGoods(0);
    },

    onShow: function onShow() {
        var businessId = this.data.options.uid;
        // 获取商家发布的优惠券
        this.getCoupon(businessId);
    },

    // 获取商家数据
    getBusinessData: function getBusinessData(businessId) {
        var that = this;
        // 获取商家数据
        app.request({
            url: "_a=shop&_u=biz.ajax_biz_uid",
            data: {
                uid: businessId
            },
            success: function success(ret) {
                console.log("business ret >>>", ret);
                var businessData = ret.data;
                var background = [];
                that.getMsgById(businessData.su_uid);
                if (!businessData.main_img.startsWith("http")) businessData.main_img = app.globalData.prefix_url + businessData.main_img;

                if (businessData.images && businessData.images.length > 0) {
                    for (var i = 0; i < businessData.images.length; i++) {
                        if (!businessData.images[i].startsWith("http")) {
                            businessData.images[i] = app.globalData.prefix_url + businessData.images[i];
                        }
                    }
                    if (businessData.images.length > 3) {
                        background = businessData.images.slice(0, 3);
                        businessData.detailImg = businessData.images.slice(3);
                    } else {
                        background = businessData.images;
                    }
                }

                WxParse.wxParse('article', 'html', businessData.brief, that);

                that.setData({
                    businessData: businessData,
                    background: background
                });
            }
        });
    },

    // 获取商家发布的优惠券
    getCoupon: function getCoupon(businessId) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.get_bizcoupon",
            data: {
                biz_uid: businessId,
                limit: -1
            },
            success: function success(ret) {
                console.log("coupons ret >>>>>", ret);
                var couponList = ret.data.list;
                couponList.forEach(function (ele) {
                    var img = ele.img;
                    ele.img = img.startsWith("http") ? img : app.globalData.prefix_url + img;
                });
                that.setData({
                    couponList: couponList
                });
            }
        });
    },

    // 领取优惠券
    drawCoupon: function drawCoupon(e) {
        var that = this;
        var couponId = e.currentTarget.dataset.id;
        var businessId = that.data.options.uid;

        if (couponId) {
            app.request({
                url: "_a=shop&_u=biz.addbizusercoupon",
                data: {
                    biz_uid: businessId,
                    coupon_uid: couponId
                },
                success: function success(ret) {
                    console.log("领取优惠券 >>>>>", ret);
                    if (ret.data && ret.data != 0) {
                        wx.showToast({
                            title: "领取成功"
                        });
                        // that.getCoupon(businessId);
                        var link = "../coupon/coupon?bizId=" + businessId + "&couponId=" + couponId;
                        wx.navigateTo({
                            url: link
                        });
                    } else if (ret.error == 607) {
                        wx.showModal({
                            title: "领取失败",
                            content: "已超过领取限制",
                            showCancel: false
                        });
                    }
                }
            });
        }
    },

    // 获取所有商品函数
    getGoods: function getGoods(page) {
        var that = this;
        var businessId = that.data.options.uid;

        // 获取商家在售商品
        app.request({
            url: "_a=shop&_u=ajax.products",
            data: {
                biz_uid: businessId,
                page: page
            },
            success: function success(ret) {
                console.log("business goods ret >>>", ret);
                var goods = ret.data.list,
                    list = that.data.goods;

                goods.forEach(function (good) {
                    if (!good.main_img.startsWith("http")) good.main_img = app.globalData.prefix_url + good.main_img;
                    good.price /= 100;
                });

                list = list.concat(goods);

                that.setData({
                    goods: list,
                    goodsCount: ret.data.count,
                    page: page,
                    noMore: goods.length < 10
                });
            }
        });
    },

    // 获取商家发布的信息
    getMsgById: function getMsgById(id) {
        var that = this;

        app.request({
            url: "_a=classmsg&_u=ajax.get_class_by_su_uid",
            data: {
                su_uid: id,
                limit: -1
            },
            success: function success(ret) {
                console.log("shop msg list ret >>>>", ret);

                var list = ret.data.list;

                list.forEach(function (ele) {
                    // 处理时间
                    var time = util.formatTime(ele.create_time);
                    ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                    // 判断是否包含图片
                    if (ele.images && ele.images.length !== 0) {
                        for (var i = 0; i < ele.images.length; i++) {
                            ele.images[i] = app.globalData.prefix_url + ele.images[i];
                        }
                    }
                });

                that.setData({
                    showList: list
                });
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    // 收藏店铺
    favTap: function favTap(e) {
        var businessData = this.data.businessData,
            that = this;

        if (businessData.had_fav) {
            // 已收藏
            wx.showModal({
                title: "确定取消收藏？",
                confirmText: "容朕想想",
                cancelText: "取消收藏",
                success: function success(res) {
                    if (res.cancel) {
                        app.request({
                            url: "_a=shop&_u=biz.del_biz_fav",
                            data: {
                                uid: businessData.had_fav
                            },
                            success: function success(ret) {
                                console.log("cancel favorite ret >>>", ret);
                                if (ret.data && ret.data != 0) {
                                    // wx.showToast({
                                    //     title: "收藏成功"
                                    // });
                                    that.getBusinessData(businessData.uid);
                                }
                            }
                        });
                    }
                }
            });
        } else {
            // 未收藏
            app.request({
                url: "_a=shop&_u=biz.add_biz_fav",
                data: {
                    biz_uid: businessData.uid
                },
                success: function success(ret) {
                    console.log("favorite tap ret >>>", ret);
                    if (ret.data && ret.data != 0) {
                        wx.showToast({
                            title: "收藏成功"
                        });
                        that.getBusinessData(businessData.uid);
                    }
                }
            });
        }
    },

    // 打电话
    phoneCall: function phoneCall() {
        var phone = this.data.businessData.phone;
        wx.makePhoneCall({
            phoneNumber: phone
        });
    },

    // 打开地图导航
    openMap: function openMap(e) {
        var businessData = this.data.businessData,
            lat = parseFloat(businessData.lat),
            lng = parseFloat(businessData.lng);

        if (lat != 0 && lng != 0) {
            wx.openLocation({
                latitude: lat,
                longitude: lng,
                scale: 18,
                name: businessData.title,
                address: businessData.location
            });
        } else {
            wx.showModal({
                title: "无法导航",
                content: "这家商家没有提供具体位置",
                showCancel: false
            });
        }
    },

    tabClick: function tabClick(e) {
        this.setData({
            sliderOffset: e.currentTarget.offsetLeft,
            activeIndex: e.currentTarget.id
        });
    },

    // 预览消息图片
    previewImages: function previewImages(e) {
        var id = e.currentTarget.id.split("-");
        console.log("image id >>>>>>", id);
        var idx = id[0],
            subIdx = id[1];

        var showList = this.data.showList,
            images = showList[idx].images,
            img = images[subIdx];

        wx.previewImage({
            current: img, // 当前显示图片的http链接
            urls: images // 需要预览的图片http链接列表
        });
    },

    // 点赞
    likeTap: function likeTap(e) {
        var that = this,
            id = e.currentTarget.id,
            showList = that.data.showList;

        app.request({
            url: '_a=classmsg&_u=ajax.add_good_cnt',
            data: {
                msg_uid: id
            },
            success: function success(ret) {
                console.log("like tap ret >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    wx.showToast({
                        title: '点赞成功'
                    });
                }
            }
        });

        showList.forEach(function (ele) {
            if (ele.uid == id) {
                ele.su_good = !ele.su_good;
                ele.su_good ? ele.good_cnt++ : ele.good_cnt--;
            }
        });

        that.setData({
            showList: showList
        });
    },

    // 评论
    commentTap: function commentTap(e) {
        var id = e.currentTarget.id;

        this.setData({
            showCommentModal: true,
            commentId: id
        });
    },
    // 提交评论
    bindFormSubmit: function bindFormSubmit(e) {
        var comment = e.detail.value.textarea;

        if (comment) {
            var that = this,
                commentId = that.data.commentId;

            console.log("commentId >>>>", commentId);

            app.request({
                url: "_a=classmsg&_u=ajax.add_comment",
                data: {
                    msg_uid: commentId,
                    content: comment
                },
                success: that.commentCallback
            });
        } else {
            wx.showModal({
                title: "请填写评论内容",
                showCancel: false
            });
        }
    },
    commentCallback: function commentCallback(ret) {
        var that = this;
        var options = that.data.options;
        console.log("comment ret >>>>", ret);

        if (ret.data && ret.data != 0) {
            that.setData({
                showCommentModal: false
            });

            wx.showToast({
                title: "评论成功",
                success: function success(res) {
                    if (res && res != 0) {
                        that.getMsgById(that.data.businessData.su_uid);
                    }
                }
            });
        }
    },
    quitCommentTap: function quitCommentTap() {
        this.setData({
            showCommentModal: false
        });
    },

    onReachBottom: function onReachBottom() {
        var that = this;
        var page = this.data.page + 1;

        // 获取商家在售商品
        this.getGoods(page);
    },

    onShareAppMessage: function onShareAppMessage() {
        var businessData = this.data.businessData;
        console.log(app.globalData.userInfo);

        return {
            title: (app.globalData.userInfo.nickName || '') + ' 邀请你来逛逛 ' + businessData.title,
            // path: '/page/class/pages/goodDetail/goodDetail?parentId=' + app.globalData.su_uid + "&uid=" + goodDetail.uid,
            success: function success(res) {
                // 转发成功
            },
            fail: function fail(res) {
                // 转发失败
            }
        };
    }
});
});require("pages/businessDetail/businessDetail.js")
var __wxRoute = "pages/goodDetail/goodDetail", __wxRouteBegin = true;
define("pages/goodDetail/goodDetail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// var sliderWidth = 96;
var app = getApp();
var WxParse = require('../common/wxParse/wxParse.js');
var util = require('../../util/util.js');

Page({
    data: {
        mainColor: app.globalData.main_color,

        // 导航栏数据
        // tabs: ["商品", "商品详情"],
        // activeIndex: 0,
        // sliderOffset: 0,
        // sliderLeft: 0,
        // sliderWidth: 96,
        // navboxWidth: 0,
        // navWidth: 0,
        // sliderLeft: 0,

        // 商品轮播图数据
        background: [],
        background_main: '',

        group_price: 0,

        // 是否已收藏
        hasCollect: false,

        // 阴影页是否显示
        isSelect: false,

        // 商品规格选择
        selectedIndex: [],
        selectedNum: 1,
        specialKey: "",

        serviceImg: app.globalData.server_url + "_u=common.img&name=service.png",
        cartImg: app.globalData.server_url + "_u=common.img&name=cart.png",
        favoriteImg: app.globalData.server_url + "_u=common.img&name=favorite.png",
        favoriteSelectedImg: app.globalData.server_url + "_u=common.img&name=favorites_fill.png"
    },
    onLoad: function onLoad(options) {
        var that = this;
        this.setData({
            mainColor: app.globalData.main_color
        });
        var id = options.uid;

        // 分销功能
        if (options.parentId) {
            app.request({
                url: "_a=su&_u=ajax.update_su",
                data: {
                    from_su_uid: options.parentId
                },
                success: function success(ret) {
                    console.log("add fans ret", ret);
                }
            });
        }

        that.setData({
            goodId: id,
            options: options
        });

        // 获取商品详情
        that.getGoodDetail(id);

        // 获取用户收藏列表 判断该商品是否已收藏
        that.getFavorite(id);

        // 获取商品评论
        that.getComments(id);

        // wx.getSystemInfo({
        //     success: function(res) {
        //         that.setData({
        //             sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
        //             sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        //             ,navboxWidth:  res.windowWidth
        //             ,navWidth:  res.windowWidth / that.data.tabs.length  
        //         });
        //         console.log("res >>>>>", 2*res.windowWidth/2);
        //         console.log("data >>>>>", that.data);
        //     }
        // });
    },

    // 获取商品详情函数
    getGoodDetail: function getGoodDetail(id, cb) {
        var that = this;

        // 获取商品详情
        app.request({
            url: "_a=shop&_u=ajax.product",
            data: {
                uid: id
            },
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.getGoodDetailCb(ret);
                }
            }
        });
    },
    getGoodDetailCb: function getGoodDetailCb(ret) {
        console.log("good detail >>>>>", ret);
        var that = this;
        var detail = ret.data;
        var background = [];
        var id = that.data.goodId;

        // 商品视频
        // if (detail.video_url) {
        //     that.setData({
        //         vedioUrl: detail.video_url
        //     });
        // } else {
        //     that.setData({
        //         vedioUrl: ''
        //     });
        // }
        if (detail.video_url) {
            background.push({ vedio: detail.video_url });
        }

        if (detail.main_img && !detail.main_img.startsWith("http")) detail.main_img = app.globalData.prefix_url + detail.main_img;

        // 商品图片 轮播图
        if (!detail.images) detail.images = [detail.main_img];
        if (detail.images.length > 0) {
            detail.images.forEach(function (image) {
                if (image && !image.startsWith("http")) image = app.globalData.prefix_url + image;
                background.push({ img: image });
            });

            that.setData({
                background: background,
                background_main: detail.main_img
            });
        }

        // 关联商品
        if (detail.linked_products && detail.linked_products.length > 0) {
            var goods = detail.linked_products;

            goods.forEach(function (good) {
                if (good.main_img && !good.main_img.startsWith("http")) good.main_img = app.globalData.prefix_url + good.main_img;
                good.price /= 100;
            });

            console.log("linked goodsList = ", goods);

            that.setData({
                goodsList: goods
            });
        } else {
            that.setData({
                goodsList: null
            });
        }

        // 处理商品价格
        detail.price = parseInt(detail.price) / 100;
        detail.group_price = detail.group_price == 0 ? 0 : detail.group_price / 100;

        console.log("good >>>>>", ret);
        var mainImg = detail.main_img.startsWith("http") ? detail.main_img : app.globalData.prefix_url + detail.main_img;

        that.setData({
            detail: detail,
            quantity: detail.quantity,
            price: detail.price,
            specialImg: mainImg,
            // id: id
            group_price: detail.group_price
        });

        // 商品库存
        var quantity = parseInt(detail.quantity);
        if (quantity === 0) {
            that.setData({
                selectedNum: 0
            });
        }

        if (detail.sku_table) {
            // 商品规格
            // 获取所有规格的名称
            var specialClass = Object.keys(detail.sku_table.table);

            var specials = [];

            specialClass.forEach(function (ele) {
                var special = {
                    name: ele,
                    list: detail.sku_table.table[ele],
                    selectedIndex: 0
                };

                specials.push(special);
            });
            that.calculate(specials);
        }

        // 判断是否为拼团商品 获取开团列表
        if (detail.group_price != 0) {
            app.request({
                url: "_a=shop&_u=ajax.get_product_order_list",
                data: {
                    uid: id
                },
                success: function success(ret) {
                    // ret.data.list
                    console.log("group good ret >>>", ret);
                    var groupList = ret.data.list;
                    groupList = groupList.length > 2 ? groupList.slice(0, 2) : groupList;
                    groupList.forEach(function (ele) {
                        var now = new Date();
                        var remainTime = parseInt(ele.paid_time) + 3600 * 24 - parseInt(now.getTime() / 1000);
                        ele.leftTime = remainTime;
                        ele.remainTime = util.formatRemainTime(remainTime);
                    });

                    that.freshTime(groupList);

                    that.setData({
                        groupList: groupList
                    });
                }
            });
        }
        //商品详情
        WxParse.wxParse('article', 'html', detail.content, that);
    },

    // 轮播图切换事件
    swiperChange: function swiperChange(e) {
        console.log("swiperChange event >>>>>", e);
    },

    // 判断商品是否已收藏
    getFavorite: function getFavorite(id, cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=ajax.favlist",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    console.log("favlist >>>>>>>", ret);
                    var favlist = ret.data.list;

                    favlist.forEach(function (ele) {
                        if (ele.product_uid == id) {
                            that.setData({
                                hasCollect: true,
                                favId: ele.uid
                            });
                        }
                    });
                }
            }
        });
    },

    // 获取商品评论
    getComments: function getComments(id, cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=ajax.comments",
            data: {
                uid: id
            },
            success: function success(ret) {
                console.log("comments >>>>>", ret);
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    var comments = ret.data.list;

                    comments.forEach(function (comment) {
                        // 处理评论人姓名
                        if (comment.user.name.length > 1) {
                            comment.name = comment.user.name.slice(0, 1) + "***" + comment.user.name.slice(-1);
                        } else {
                            comment.name = "*";
                        }

                        // 处理评论评分
                        if (comment.score > 3) {
                            comment.degree = "好评";
                            comment.degreeImg = "../../../resources/pic/good.png";
                        } else if (comment.score > 1) {
                            comment.degree = "中评";
                            comment.degreeImg = "../../../resources/pic/normal.png";
                        } else {
                            comment.degree = "差评";
                            comment.degreeImg = "../../../resources/pic/bad.png";
                        }

                        // 处理评论时间
                        var date = util.formatTime(comment.create_time);
                        comment.time = date[0] + "-" + date[1] + "-" + date[2];

                        // 处理评论图片
                        if (comment.images.length > 0) {
                            for (var i = 0; i < comment.images.length; i++) {
                                var img = comment.images[i];
                                if (img && !img.startsWith("http")) comment.images[i] = app.globalData.prefix_url + img;
                            }
                        }
                    });

                    that.setData({
                        comments: comments
                    });
                }
            }
        });
    },

    // 查看评论图片
    previewImg: function previewImg(e) {
        console.log("tap image >>>", e);
        var id = e.currentTarget.id;

        var index = id.split("-"),
            commentIndex = parseInt(index[0]),
            imageIndex = parseInt(index[1]);

        var commentList = this.data.comments;

        wx.previewImage({
            current: commentList[commentIndex].images[imageIndex], // 当前显示图片的http链接
            urls: commentList[commentIndex].images // 需要预览的图片http链接列表
        });
    },

    // 刷新时间
    freshTime: function freshTime(groupList) {
        var that = this;
        var sh = setInterval(function () {
            groupList.forEach(function (ele) {
                ele.leftTime--;
                if (ele.leftTime <= 0) {
                    ele.remainTime = "团购已过期";
                } else {
                    ele.remainTime = util.formatRemainTime(ele.leftTime);
                }
            });

            that.setData({
                groupList: groupList
            });
        }, 1000);
    },

    // 参团事件
    navToGroupJoin: function navToGroupJoin(e) {
        var groupId = e.currentTarget.id,
            goodId = this.data.goodId;

        var navUrl = "../joinGroup/joinGroup?goodId=" + goodId + "&groupId=" + groupId;

        wx.navigateTo({
            url: navUrl
        });
    },

    // 查看关联商品
    reload: function reload(e) {
        var goodId = e.currentTarget.id;
        // var options = this.data.options;
        // options.uid = goodId;
        // this.onLoad(options);
        wx.redirectTo({
            url: "../goodDetail/goodDetail?uid=" + goodId
        });
    },

    // 选择商品规格函数
    bindSelectSpecial: function bindSelectSpecial(e) {
        var that = this;
        var id = e.currentTarget.id;
        var keyValue = id.split(' ');

        var specials = that.data.specials;

        specials.forEach(function (special) {
            if (special.name == keyValue[0]) {
                special.selectedIndex = parseInt(keyValue[1]);
            }
        });

        that.calculate(specials);
    },

    // 购买数量减一
    substractNum: function substractNum() {
        var that = this;
        var selectedNum = that.data.selectedNum - 1;
        that.setData({
            selectedNum: selectedNum
        });
    },

    // 购买数量加一
    addNum: function addNum() {
        var that = this;
        var selectedNum = that.data.selectedNum + 1;

        that.setData({
            selectedNum: selectedNum
        });
    },

    // 通过用户选择的规格，获取对应信息
    calculate: function calculate(specials) {
        var that = this;
        var detail = that.data.detail;
        var selectedNum = that.data.selectedNum;
        var selectedSpecialKey = "";

        // 获取所有规格组合下的产品信息
        var specialKeys = Object.keys(detail.sku_table.info);

        // 获取用户选择的规格
        specialKeys.forEach(function (specialKey) {
            for (var i = 0; i < specials.length; i++) {
                if (specialKey.indexOf(specials[i].list[specials[i].selectedIndex]) == -1) {
                    break;
                } else {
                    if (i == specials.length - 1) {
                        selectedSpecialKey = specialKey;
                    }
                }
            }
        });

        var selectSpecial = detail.sku_table.info[selectedSpecialKey];
        var price = selectSpecial.price / 100;
        var quantity = selectSpecial.quantity;
        if (selectSpecial.icon_img && !selectSpecial.icon_img.startsWith("http")) selectSpecial.icon_img = app.globalData.prefix_url + selectSpecial.icon_img;
        var specialImg = selectSpecial.icon_img ? selectSpecial.icon_img : detail.main_img;
        selectedNum = selectedNum > quantity ? quantity : selectedNum;
        if (quantity > 0) selectedNum = selectedNum == 0 ? 1 : selectedNum;

        // specials：用户挑选的规格；
        that.setData({
            specials: specials,
            price: price,
            quantity: quantity,
            specialKey: selectedSpecialKey,
            selectedNum: selectedNum,
            specialImg: specialImg
        });
    },

    // 加入收藏
    addToFavorite: function addToFavorite() {
        var that = this;
        var goodId = that.data.goodId;
        var options = that.data.options;
        var hasCollect = that.data.hasCollect;

        if (!hasCollect) {
            app.request({
                url: "_a=shop&_u=ajax.add_to_fav",
                data: {
                    product_uid: goodId
                },
                success: function success(ret) {
                    console.log("addToFavorite ret >>>", ret);
                    if (ret.data && ret.data != 0) {
                        wx.showToast({
                            title: "收藏成功!",
                            success: function success() {
                                that.onLoad(options);
                            }
                        });
                    }
                }
            });
        } else {
            var favId = that.data.favId;
            console.log("delete favId >>>", favId);
            app.request({
                url: "_a=shop&_u=ajax.delete_fav",
                data: {
                    uids: favId
                },
                success: function success(ret) {
                    console.log("delete Favorite ret >>>", ret);
                    if (ret.data && ret.data != 0) {
                        wx.showToast({
                            title: "移出收藏",
                            success: function success() {
                                that.onLoad(options);
                                that.setData({ hasCollect: false });
                            }
                        });
                    }
                }
            });
        }
    },

    // 加入购物车
    bindAddCart: function bindAddCart() {
        var that = this;
        var localData = that.data;
        var id = localData.goodId,
            specialKey = localData.specialKey,
            specials = localData.specials,
            selectedNum = localData.selectedNum,
            detailData = localData.detail,
            price = localData.price;
        var hasGood = false;

        // 微信小程序本地存储
        var good = {
            specialKey: specialKey,
            specials: specials,
            selectedNum: selectedNum,
            detailData: detailData,
            price: price
        };

        if (selectedNum <= 0) {
            wx.showToast({
                icon: 'loading',
                title: '已售罄'
            });
        } else {
            // 检查本地数据是否含有购物车信息
            var cart = wx.getStorageSync("cart");
            console.log("local cart >>>", cart);

            // 本地购物车为空
            if (cart === "") {
                cart = {};
                cart.list = [];
                cart.list.push(good);
            } else {
                // cart.list.push(good);
                cart.list.forEach(function (ele) {
                    if (ele.detailData.uid === good.detailData.uid && ele.specialKey === good.specialKey) {
                        ele.selectedNum += selectedNum;
                        hasGood = true;
                    }
                });

                if (!hasGood) {
                    cart.list.push(good);
                }
            }

            wx.setStorage({
                key: "cart",
                data: cart,
                success: function success() {
                    that.tapShadow();
                    wx.showToast({
                        title: "添加成功"
                    });
                }
            });
        }
    },

    // 点击阴影部分，关闭选择规格页
    tapShadow: function tapShadow() {
        var that = this;
        that.setData({
            isSelect: false
        });
    },

    // 打开选择规格页面
    showSelect: function showSelect() {
        var that = this;
        that.setData({
            isSelect: true
        });
    },

    // 查看全部评论
    viewComments: function viewComments() {
        var sliderOffset = this.data.navboxWidth / this.data.tabs.length;

        this.setData({
            sliderOffset: sliderOffset,
            activeIndex: 1
        });
    },

    // 前往购物车页面
    navToCart: function navToCart() {
        wx.switchTab({
            url: "/page/cart/cart"
        });
    },

    // 立即购买 前往订单页面
    navToOrder: function navToOrder() {
        var that = this;

        // 获取需要存储的数据
        var detail = that.data.detail;
        var price = that.data.price;
        var specialKey = that.data.specialKey;
        var specials = that.data.specials;
        var selectedNum = that.data.selectedNum;

        var order = {};
        order.list = [];
        var goodOrder = {
            detailData: detail,
            price: price,
            selectedNum: selectedNum,
            specials: specials,
            specialKey: specialKey
        };

        if (selectedNum >= 1) {
            order.list.push(goodOrder);
            // 将选中的订单存入本地
            wx.setStorage({
                key: "order",
                data: order
            });

            wx.navigateTo({
                url: "../order/order"
            });
        } else {
            wx.showToast({
                icon: 'loading',
                title: '已售罄'
            });
        }
    },

    // 开团
    findGroup: function findGroup() {
        var that = this;

        // 获取需要存储的数据
        var detail = that.data.detail;
        // var price = that.data.price;
        // 团购价
        var price = detail.group_price;
        var specialKey = that.data.specialKey;
        var specials = that.data.specials;
        var selectedNum = that.data.selectedNum;

        var order = {};
        order.list = [];
        var goodOrder = {
            detailData: detail,
            price: price,
            selectedNum: selectedNum,
            specials: specials,
            specialKey: specialKey,
            goUid: 0
        };

        if (selectedNum >= 1) {
            order.list.push(goodOrder);

            // 将选中的订单存入本地
            wx.setStorage({
                key: "groupOrder",
                data: order
            });

            wx.navigateTo({
                url: "../groupOrder/groupOrder"
            });
        } else {
            wx.showToast({
                icon: 'loading',
                title: '已售罄'
            });
        }
    },

    // 点击导航项
    tabClick: function tabClick(e) {
        this.setData({
            sliderOffset: e.currentTarget.offsetLeft,
            activeIndex: e.currentTarget.id
        });
    },

    // 分享商品页面
    onShareAppMessage: function onShareAppMessage(res) {
        var goodDetail = this.data.detail;

        return {
            title: app.globalData.userInfo.nickName + '给你分享了一个宝贝 ' + goodDetail.title,
            path: '/pages/goodDetail/goodDetail?parentId=' + app.globalData.su_uid + "&uid=" + goodDetail.uid,
            success: function success(res) {
                // 转发成功
            },
            fail: function fail(res) {
                // 转发失败
            }
        };
    }
});
});require("pages/goodDetail/goodDetail.js")
var __wxRoute = "pages/apply/apply", __wxRouteBegin = true;
define("pages/apply/apply.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({

    data: {
        showTopTips: false,

        // 判断是否是修改店铺信息
        update: false,

        accounts: ["零食", "女装", "鞋靴"],
        accountIndex: 0,

        mainColor: "",

        postData: {
            extra_info: {}
        },
        mainImg: "",
        uploadImg: "",

        checkboxItems: [{ value: 'WIFI', checked: false }, { value: '停车位', checked: false }, { value: '支付宝支付', checked: false }, { value: '微信支付', checked: false }],

        files: [],
        uploadImage: [],

        isAgree: false
    },

    onLoad: function onLoad(options) {
        this.setData({
            options: options,
            mainColor: app.globalData.main_color
        });

        // 获取所有商家分类
        this.getBizClass();
    },

    onShow: function onShow() {},

    getBizInfo: function getBizInfo(bizId, cb) {
        var that = this;
        var postData = that.data.postData;

        app.request({
            url: "_a=shop&_u=biz.ajax_biz",
            data: {
                uid: bizId
            },
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    console.log("get business ret >>>>", ret);
                    if (!ret.data) return;

                    postData = ret.data;
                    // postData.

                    // 商户类型
                    var types = that.data.accounts;
                    postData.extra_info.name = postData.contact;

                    // 店内设施
                    var checkboxItems = that.data.checkboxItems,
                        values = postData.extra_info.bar_installation;
                    for (var i = 0, lenI = checkboxItems.length; i < lenI; i++) {
                        checkboxItems[i].checked = false;

                        for (var j = 0, lenJ = values.length; j < lenJ; j++) {
                            if (checkboxItems[i].value == values[j]) {
                                checkboxItems[i].checked = true;
                                break;
                            }
                        }
                    }

                    // 商家图片
                    var mainImg = postData.main_img.startsWith("http") ? postData.main_img : app.globalData.prefix_url + postData.main_img;
                    // var files = postData.images;
                    var uploadImage = postData.images;
                    var files = [];

                    for (var i = 0; i < uploadImage.length; i++) {
                        var img = uploadImage[i];
                        img = img.startsWith("http") ? img : app.globalData.prefix_url + img;
                        files.push(img);
                    }

                    that.setData({
                        mainImg: mainImg,
                        uploadImg: postData.main_img,
                        files: files,
                        uploadImage: uploadImage,
                        checkboxItems: checkboxItems,
                        postData: postData,
                        accountIndex: types.indexOf(postData.type)
                    });
                }
            }
        });
    },

    // 获取所有商家分类函数
    getBizClass: function getBizClass(cb) {
        var that = this;

        app.request({
            url: "_a=shop&_u=ajax.biz_cats",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    console.log("cat >>>", ret);
                    var catList = ret.data;
                    var accounts = [];
                    catList.forEach(function (ele) {
                        accounts.push(ele.title);
                    });
                    that.setData({
                        accounts: accounts
                    });

                    if (that.data.options.bizId) {
                        // 获取填写过的信息
                        that.getBizInfo(that.data.options.bizId);
                        wx.setNavigationBarTitle({
                            title: "修改商户信息"
                        });
                        that.setData({
                            update: true
                        });
                    }
                }
            }
        });
    },

    // 填写信息
    userInput: function userInput(e) {
        var id = e.currentTarget.id;
        var value = e.detail.value;
        var properties = ['title', 'location', 'phone', 'account', 'passwd', 'contact'];
        var postData = this.data.postData;

        if (properties.indexOf(id) >= 0) {
            postData[id] = value;
        } else {
            postData.extra_info[id] = value;
        }

        this.setData({
            postData: postData
        });
    },

    // 确认密码
    pswConfirm: function pswConfirm(e) {
        var newPassword = e.detail.value;
        var oldPasswd = this.data.postData.passwd;
        var showTopTips = false;

        if (newPassword === oldPasswd) {
            showTopTips = false;
        } else {
            showTopTips = true;
        }

        this.setData({
            showTopTips: showTopTips
        });
    },

    // 选择店内设施
    checkboxChange: function checkboxChange(e) {
        console.log('checkbox发生change事件，携带value值为：', e.detail.value);
        var postData = this.data.postData;
        var checkboxItems = this.data.checkboxItems,
            values = e.detail.value;
        postData.extra_info.bar_installation = values;

        for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
            checkboxItems[i].checked = false;

            for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
                if (checkboxItems[i].value == values[j]) {
                    checkboxItems[i].checked = true;
                    break;
                }
            }
        }

        this.setData({
            checkboxItems: checkboxItems
        });
    },

    bindAccountChange: function bindAccountChange(e) {
        console.log('picker account 发生选择改变，携带值为', e.detail.value);

        this.setData({
            accountIndex: e.detail.value
        });
    },

    // 操作商家地址
    handleLoc: function handleLoc() {
        var loc = this.data.postData.location;

        if (loc) {
            this.clearLoc();
        } else {
            this.chooseLoc();
        }
    },

    // 选择商家地址
    chooseLoc: function chooseLoc() {
        var that = this,
            postData = that.data.postData;
        wx.chooseLocation({
            success: function success(ret) {
                console.log("chooseLocation rer >>>>>", ret);
                if (ret.address.includes(ret.name)) {
                    postData.location = ret.address;
                } else if (ret.name.includes(ret.address)) {
                    postData.location = ret.name;
                } else {
                    postData.location = ret.address + ret.name;
                }
                postData.lng = ret.longitude;
                postData.lat = ret.latitude;
                that.setData({
                    postData: postData
                });
            }
        });
    },
    // 清空地址
    clearLoc: function clearLoc() {
        var postData = this.data.postData;
        postData.location = postData.lng = postData.lat = "";
        this.setData({
            postData: postData
        });
    },

    // 设置营业时间
    bindTimeChange: function bindTimeChange(e) {
        var id = e.currentTarget.id;

        this.setData({
            time: e.detail.value
        });
    },

    // 图片预览
    previewImage: function previewImage(e) {
        var mainImg = this.data.mainImg;

        wx.previewImage({
            current: mainImg,
            urls: [mainImg]
        });
    },

    // 选择图片函数
    chooseImage: function chooseImage(e) {
        var that = this;
        wx.chooseImage({
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success: that.chooseImageCb
        });
    },
    // 选择图片成功回调函数
    chooseImageCb: function chooseImageCb(res) {
        var that = this;
        var imageList = res.tempFilePaths;

        if (imageList.length > 6) {
            wx.showModal({
                content: "最多只能上传6张图片",
                showCancel: false
            });
        } else {
            that.setData({
                mainImg: imageList[0]
            });
            console.log("local show img >>>", imageList[0]);

            var uploadImg = that.data.uploadImg;
            var uploadURL = app.globalData.prefix_url + "?_a=upload&_u=index.upload";

            res.tempFilePaths.forEach(function (imageSrc) {
                // 上传图片
                wx.uploadFile({
                    url: uploadURL,
                    filePath: imageSrc,
                    name: 'file',
                    success: function success(res) {
                        var picData = JSON.parse(res.data);

                        uploadImg = picData.data.url;

                        wx.showToast({
                            title: '图片上传成功',
                            icon: 'success',
                            duration: 500
                        });

                        that.setData({
                            uploadImg: uploadImg
                        });

                        console.log("uploadImg >>>", uploadImg);
                    },
                    fail: function fail(_ref) {
                        var errMsg = _ref.errMsg;

                        console.log('uploadImage fail, errMsg is', errMsg);
                    }
                });
            });
        }
    },

    // 选择商家图片
    chooseShopImage: function chooseShopImage(e) {
        var that = this;

        wx.chooseImage({
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: that.chooseShopImageCb
        });
    },
    chooseShopImageCb: function chooseShopImageCb(res) {
        var that = this,
            chooseFiles = res.tempFilePaths;

        that.uploadShopImg(chooseFiles, 0);
    },
    // 依次上传多张图片
    uploadShopImg: function uploadShopImg(imgArr, idx) {
        var that = this,
            uploadImage = that.data.uploadImage,
            uploadURL = app.globalData.prefix_url + "?_a=upload&_u=index.upload";

        // 上传图片
        wx.uploadFile({
            url: uploadURL,
            filePath: imgArr[idx],
            name: 'file',
            success: function success(res) {
                var picData = JSON.parse(res.data);

                var files = that.data.files.concat(imgArr[idx]);
                that.setData({
                    files: files
                });

                var picUrl = picData.data.url;
                console.log("chooseImage url >>>>", picUrl);
                uploadImage.push(picUrl);
                console.log("uploadImage >>>>>>", uploadImage);
                that.setData({
                    uploadImage: uploadImage
                });
            },
            fail: function fail(_ref2) {
                var errMsg = _ref2.errMsg;

                console.log('uploadImage fail, errMsg is', errMsg);
            },
            complete: function complete() {
                idx++;
                if (idx >= imgArr.length) {
                    wx.showToast({
                        title: '图片上传成功'
                    });
                } else {
                    that.uploadShopImg(imgArr, idx);
                }
            }
        });
    },
    // 预览上传图片
    previewShopImage: function previewShopImage(e) {
        var id = parseInt(e.currentTarget.id);
        var current = this.data.files[id];
        wx.previewImage({
            current: current,
            urls: this.data.files
        });
    },

    // 删除长按的图片
    deleteImg: function deleteImg(e) {
        var id = parseInt(e.currentTarget.id),
            uploadImage = that.data.uploadImage,
            files = this.data.files;
        console.log("delete id >>>", id);
        files.splice(id, 1);
        uploadImage.splice(id, 1);
        console.log("files show >>>>>", files);
        console.log("uploadImage >>>>>", uploadImage);
        this.setData({
            files: files,
            uploadImage: uploadImage
        });
    },

    // 是否同意协议
    bindAgreeChange: function bindAgreeChange(e) {
        this.setData({
            isAgree: !!e.detail.value.length
        });
    },

    // 提交信息
    submitInfo: function submitInfo(e) {
        var that = this;

        // 获取输入框中的内容
        var brief = e.detail.value.textarea;
        var data = that.data;

        var postData = data.postData;
        postData.main_img = data.uploadImg;
        postData.type = data.accounts[data.accountIndex];
        postData.brief = brief;
        postData.images = data.uploadImage.join(";");

        console.log("postData >>>>>", postData);
        // return;

        if (this.data.showTopTips) {
            wx.showModal({
                title: "请确认密码",
                showCancel: false
            });
        } else if (!this.data.isAgree) {
            wx.showModal({
                title: "请确认阅读并同意相关条款",
                showCancel: false
            });
        } else if (postData.title && postData.location && postData.phone && postData.main_img && postData.brief && postData.contact) {
            // 更新商铺数据
            if (that.data.update) {
                that.updateBiz(postData);
            } else {
                that.applyBiz(postData);
            }
        } else {
            wx.showModal({
                title: "请将信息填写完整",
                showCancel: false
            });
        }
    },

    // 申请成为商户
    applyBiz: function applyBiz(postData) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_apply",
            data: postData,
            success: function success(ret) {
                console.log("reply return >>>", ret);
                if (ret.errno == 0 & ret.data !== "0") {
                    wx.showToast({
                        title: "申请提交成功！"
                    });
                    wx.navigateBack();
                } else {
                    wx.showModal({
                        title: "提交失败",
                        content: "请检查您的网络",
                        showCancel: false
                    });
                }
            }
        });
    },

    updateBiz: function updateBiz(postData) {
        var that = this;

        app.request({
            url: "_a=shop&_u=biz.edit_biz",
            data: postData,
            success: function success(ret) {
                console.log("update return >>>", ret);
                if (ret.errno == 0 & ret.data !== "0") {
                    wx.showToast({
                        title: "修改提交成功！"
                    });
                    wx.navigateBack();
                } else {
                    wx.showModal({
                        title: "提交失败",
                        content: "请检查您的网络",
                        showCancel: false
                    });
                }
            }
        });
    }
});
});require("pages/apply/apply.js")
var __wxRoute = "pages/coupon/coupon", __wxRouteBegin = true;
define("pages/coupon/coupon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

// pages/coupon/coupon.js
var app = getApp();
var WxParse = require('../common/wxParse/wxParse.js');
var util = require('../../util/util.js');

Page({

    /**
     * 页面的初始数据
     */
    data: {
        open: false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function onLoad(options) {
        var that = this;

        if (!app.globalData.su_uid) {
            app.getUserInfo(function (userInfo) {
                that.onLoad(options);
            });
        } else {
            var bizId = options.bizId,
                couponId = options.couponId;

            this.setData({
                options: options
            });

            // 获取商家数据
            this.getBusinessData(bizId);

            // 获取优惠券数据
            this.getCouponData(couponId);
        }
    },

    onShow: function onShow() {},

    // 获取商家数据
    getBusinessData: function getBusinessData(businessId) {
        var that = this;
        // 获取商家数据
        app.request({
            url: "_a=shop&_u=biz.ajax_biz_uid",
            data: {
                uid: businessId
            },
            success: function success(ret) {
                console.log("business ret >>>", ret);
                var businessData = ret.data;
                if (!businessData.main_img.startsWith("http")) businessData.main_img = app.globalData.prefix_url + businessData.main_img;

                that.setData({
                    businessData: businessData
                });
            }
        });
    },

    // 获取优惠券数据
    getCouponData: function getCouponData(couponId) {
        var that = this;

        app.request({
            url: "_a=shop&_u=biz.bizcoupon",
            data: {
                coupon_uid: couponId
            },
            success: function success(ret) {
                console.log("coupon data >>>", ret);
                var couponData = ret.data;
                var img = couponData.img;
                couponData.img = img.startsWith("http") ? img : app.globalData.prefix_url + img;

                if (couponData.duration == 0) {
                    couponData.time = "长期有效";
                } else {
                    var duration = parseInt(couponData.duration),
                        create_time = parseInt(couponData.create_time),
                        startTime = util.formatTime(create_time),
                        endTime = util.formatTime(create_time + duration);

                    couponData.time = startTime.join(".") + " - " + endTime.join(".");
                }
                WxParse.wxParse('article', 'html', couponData.brief, that);

                if (couponData.user_coupon) {
                    that.createQRcode(couponData.user_coupon);
                }

                that.setData({
                    couponData: couponData
                });
            }
        });
    },

    // 领取红包
    openTap: function openTap() {
        var that = this,
            options = that.data.options;

        this.setData({
            open: true
        });
        // var t = setTimeout(function() {
        app.request({
            url: "_a=shop&_u=biz.addbizusercoupon",
            data: {
                biz_uid: options.bizId,
                coupon_uid: options.couponId
            },
            success: function success(ret) {
                console.log("领取优惠券 >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    setTimeout(function () {
                        wx.showToast({
                            title: "领取成功"
                        });
                        that.getCouponData(options.couponId);
                    }, 2000);
                }
            }
        });
        // }, 2000);
    },

    // 获取二维码
    createQRcode: function createQRcode(userCoupon) {
        var that = this;
        // var businessData = that.data.businessData;

        // if (businessData && businessData.hadv == 1) {
        var encodeUrl = encodeURIComponent("/pages/verification/verification?couponId=" + userCoupon.uid + "&bizId=" + userCoupon.biz_uid + "&userId=" + userCoupon.user_id);
        var qrcodeUrl = app.globalData.server_url + "_u=xiaochengxu.qrcode&type=1&path=" + encodeUrl;
        console.log("qrcodeUrl >>>>", qrcodeUrl);

        that.setData({
            qrcode: qrcodeUrl
        });
        // }       
    },

    previewCode: function previewCode() {
        var qrcodeUrl = this.data.qrcode;

        wx.previewImage({
            current: qrcodeUrl, // 当前显示图片的http链接
            urls: [qrcodeUrl] // 需要预览的图片http链接列表
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onShareAppMessage: function onShareAppMessage() {
        return {
            title: "优惠券红包"
        };
    }
});
});require("pages/coupon/coupon.js")
var __wxRoute = "pages/myCoupon/myCoupon", __wxRouteBegin = true;
define("pages/myCoupon/myCoupon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

// pages/myCoupon/myCoupon.js
var app = getApp();
var util = require('../../util/util.js');

Page({

    /**
     * 页面的初始数据
     */
    data: {
        couponList: [],
        page: 0
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function onLoad(options) {},

    onShow: function onShow() {
        var that = this;

        this.getMyCoupons(0);
    },

    getMyCoupons: function getMyCoupons(page) {
        var that = this;

        app.request({
            url: "_a=shop&_u=biz.get_bizusercoupon",
            data: {
                available: 1,
                page: page,
                limit: 10
            },
            success: function success(ret) {
                console.log("my coupons ret >>>>>", ret);
                page = page || 0;
                var couponList = page == 0 ? [] : that.data.couponList;
                var list = ret.data.list;

                list.forEach(function (ele) {
                    var img = ele.info.img;
                    ele.image = img.startsWith("http") ? img : app.globalData.prefix_url + img;

                    if (ele.expire_time == 0) {
                        ele.endTime = "长期有效";
                    } else {
                        var startTime = util.formatTime(ele.create_time),
                            endTime = util.formatTime(ele.expire_time);

                        ele.endTime = startTime.join(".") + "-" + endTime.join(".");
                    }
                });

                couponList = couponList.concat(list);

                that.setData({
                    couponList: couponList,
                    page: page
                });
            }
        });
    },

    delete: function _delete(e) {
        var couponId = e.currentTarget.dataset.id;
        var that = this;

        wx.showModal({
            title: "温馨提示",
            content: "确定删除这张优惠券吗",
            success: function success(ret) {
                if (ret.confirm) {
                    app.request({
                        url: "_a=shop&_u=biz.edit_userbizcoupon_status",
                        data: {
                            uid: couponId
                        },
                        success: function success(ret) {
                            console.log("delete ret >>>>>", ret);
                            if (ret.data) {
                                wx.showToast({
                                    title: "删除成功"
                                });
                                that.onShow();
                            }
                        }
                    });
                }
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onReachBottom: function onReachBottom() {
        var page = this.data.page + 1;
        this.getMyCoupons(page);
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/myCoupon/myCoupon.js")
var __wxRoute = "pages/verification/verification", __wxRouteBegin = true;
define("pages/verification/verification.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

// pages/verification/verification.js
var app = getApp();

Page({

    data: {},

    onLoad: function onLoad(options) {
        var that = this;

        if (app.globalData.su_uid) {
            that.setData({
                options: options
            });

            var couponId = options.couponId;
            var userId = options.userId;
            var bizId = options.bizId;

            // 校验优惠券信息
            that.getCouponData(couponId, userId);
        } else {
            app.getUserInfo(function (userInfo) {
                that.onLoad(options);
            });
        }
    },

    onShow: function onShow() {},

    // 校验优惠券信息
    getCouponData: function getCouponData(couponId, userId) {
        var that = this;

        app.request({
            url: "_a=shop&_u=biz.check_userbizcoupon",
            data: {
                uid: couponId,
                su_uid: userId
            },
            success: function success(ret) {
                console.log("coupon check >>>", ret);
                var check = ret.data;
                var couponData = check.info;
                var img = couponData.img;
                couponData.image = img.startsWith("http") ? img : app.globalData.prefix_url + img;
                couponData.statusText = that.status2Text(check.status);

                that.setData({
                    couponData: couponData,
                    checkStatus: check.status
                });
            }
        });
    },

    status2Text: function status2Text(status) {
        switch (status) {
            case 0:
                return "可使用";
            case 1:
                return "已核销";
            case 2:
                return "已过期";
            case 20:
                return "商家已下架该活动";
        }
    },

    // 核销操作
    verification: function verification() {
        var that = this;
        var options = that.data.options;

        app.request({
            url: "_a=shop&_u=biz.usebizcoupon",
            data: {
                uid: options.couponId,
                biz_uid: options.bizId
            },
            success: function success(ret) {
                console.log("核销返回 >>>>", ret);
                if (ret.data) {
                    wx.showModal({
                        title: "核销成功",
                        showCancel: false,
                        success: function success(res) {
                            if (res.confirm) {
                                that.onLoad(that.data.options);
                            }
                        }
                    });
                } else {
                    wx.showModal({
                        title: "核销失败",
                        content: "请检查优惠券使用情况，并重新扫码",
                        showCancel: false
                    });
                }
            }
        });
    },

    // 打开扫一扫
    scancode: function scancode() {
        wx.scanCode({
            success: function success(res) {
                console.log("scan ret >>>", res);
                // res.path
                wx.redirectTo({
                    url: res.path
                });
            }
        });
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function onHide() {}
});
});require("pages/verification/verification.js")
var __wxRoute = "pages/localNews/localNews", __wxRouteBegin = true;
define("pages/localNews/localNews.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

// pages/localNews/localNews.js
var app = getApp();
var util = require("../../util/util.js");

Page({

    data: {
        noMore: false,
        newsList: [],
        page: 0
    },

    onLoad: function onLoad(options) {
        this.getNews(0);
    },

    onShow: function onShow() {},

    // 获取新闻
    getNews: function getNews(page) {
        var that = this;

        app.request({
            url: "_a=classmsg&_u=ajax.get_newslist",
            data: {
                type: "",
                limit: 10,
                page: page
            },
            success: function success(ret) {
                console.log("news ret >>>>>", ret);
                var list = ret.data.list,
                    newsList = that.data.newsList;

                list.forEach(function (ele) {
                    var time = util.formatTime(ele.create_time);
                    ele.time = time.join("-");
                    // ele.img.startsWith("http")
                    if (ele.img && !ele.img.startsWith("http")) ele.img = app.globalData.prefix_url + ele.img;
                });

                newsList = newsList.concat(list);

                that.setData({
                    page: page,
                    newsList: newsList,
                    noMore: list.length < 10
                });
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {
        this.setData({
            newsList: [],
            page: 0
        });
        this.onLoad();
    },

    onReachBottom: function onReachBottom() {
        var page = this.data.page + 1;
        this.getNews(page);
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/localNews/localNews.js")
var __wxRoute = "pages/article/article", __wxRouteBegin = true;
define("pages/article/article.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

// pages/article/article.js
var app = getApp();
var WxParse = require('../common/wxParse/wxParse.js');
var util = require("../../util/util.js");

Page({
    data: {},

    onLoad: function onLoad(options) {
        if (options.uid) {
            this.getArticle(options.uid);
        } else if (options.type_in) {
            this.getDeal(options.type_in);
        }
    },

    onShow: function onShow() {},

    getArticle: function getArticle(id) {
        var that = this;

        app.request({
            url: "_a=classmsg&_u=ajax.get_news_by_uid",
            data: {
                uid: id
            },
            success: function success(ret) {
                console.log("article ret >>>>>", ret);
                var article = ret.data,
                    content = article.content;

                article.time = util.formatTime(article.create_time).join("-");

                WxParse.wxParse('content', 'html', content, that, 5);

                that.setData({
                    article: article
                });
            }
        });
    },

    // 获取商家入驻条款
    getDeal: function getDeal(type_in) {
        var that = this;
        app.request({
            url: "_a=shop&_u=ajax.get_user_agreement",
            data: {
                type_in: type_in
            },
            success: that.getMsgCb
        });
    },

    getMsgCb: function getMsgCb(ret) {
        var that = this;
        console.log("article ret >>>", ret);
        var article = ret.data;
        var time = util.formatTime(article.create_time);
        article.time = time[0] + "-" + time[1] + "-" + time[2];

        var content = article.content;
        WxParse.wxParse('content', 'html', content, that, 5);

        that.setData({
            article: article
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/article/article.js")
var __wxRoute = "pages/classMsg/classMsg", __wxRouteBegin = true;
define("pages/classMsg/classMsg.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
var util = require('../../util/util.js');

Page({

    data: {
        page: 0,
        msgList: []
    },

    onLoad: function onLoad(options) {
        var that = this;
        var classId = options.classId;

        this.setData({
            options: options
        });
        that.getMsgList(classId, 0);
        that.getClassBtId(classId);
    },

    onShow: function onShow() {},

    getClassBtId: function getClassBtId(id, cb) {
        var that = this;
        app.request({
            url: "_a=classmsg&_u=ajax.get_class_cat_by_uid",
            data: {
                uid: id
            },
            success: function success(ret) {
                console.log("class detail >>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    wx.setNavigationBarTitle({
                        title: ret.data.title
                    });
                }
            }
        });
    },

    getMsgList: function getMsgList(classId, page, cb) {
        var _this = this;

        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_by_cat_uid',
            data: {
                cat_uid: classId,
                sort: 2,
                page: page
            },
            success: function success(ret) {
                console.log("msgList >>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var list = ret.data.list;

                    list.forEach(function (ele) {
                        // 处理时间
                        var time = util.formatTime(ele.create_time);
                        ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                        // 判断是否包含图片
                        if (ele.images && ele.images.length !== 0) {
                            for (var i = 0; i < ele.images.length; i++) {
                                ele.images[i] = app.globalData.prefix_url + ele.images[i];
                            }
                        }

                        // 区别商家和用户
                        if (ele.biz) {
                            var image = ele.biz.main_img;
                            // if (image.startsWith("http")) {}
                            ele.biz.main_img = image.startsWith("http") ? image : app.globalData.prefix_url + image;
                        }
                    });

                    var msgList = that.data.msgList.concat(list);
                    _this.setData({
                        msgList: msgList
                    });

                    if (list.length < 10) {
                        that.setData({
                            noMore: true
                        });
                    }

                    // 停止刷鞋
                    wx.stopPullDownRefresh();
                }
            }
        });
    },

    // 联系发布者
    phoneCallTap: function phoneCallTap(e) {
        var number = e.currentTarget.id;
        wx.makePhoneCall({
            phoneNumber: number
        });
    },

    // 预览消息图片
    previewImages: function previewImages(e) {
        var id = e.currentTarget.id.split("-");
        console.log("image id >>>>>>", id);
        var idx = id[0],
            subIdx = id[1];

        var msgList = this.data.msgList,
            images = msgList[idx].images,
            img = images[subIdx];

        wx.previewImage({
            current: img, // 当前显示图片的http链接
            urls: images // 需要预览的图片http链接列表
        });
    },

    // 点赞
    likeTap: function likeTap(e) {
        var that = this,
            id = e.currentTarget.id,
            msgList = that.data.msgList;

        app.request({
            url: '_a=classmsg&_u=ajax.add_good_cnt',
            data: {
                msg_uid: id
            },
            success: function success(ret) {
                console.log("like tap ret >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    wx.showToast({
                        title: '点赞成功'
                    });
                }
            }
        });

        msgList.forEach(function (ele) {
            if (ele.uid == id) {
                ele.su_good = !ele.su_good;
                ele.su_good ? ele.good_cnt++ : ele.good_cnt--;
            }
        });

        that.setData({
            msgList: msgList
        });
    },

    // 评论
    commentTap: function commentTap(e) {
        var id = e.currentTarget.id;

        this.setData({
            showCommentModal: true,
            commentId: id
        });
    },

    // 提交评论
    bindFormSubmit: function bindFormSubmit(e) {
        var comment = e.detail.value.textarea;
        var that = this,
            commentId = that.data.commentId;
        // parentId = that.data.parentId;

        console.log("commentId >>>>", commentId);
        // console.log("parentId >>>>", parentId);

        app.request({
            url: "_a=classmsg&_u=ajax.add_comment",
            data: {
                msg_uid: commentId,
                // parent_uid: parentId,
                content: comment
            },
            success: that.commentCallback
        });
    },
    commentCallback: function commentCallback(ret) {
        var that = this;
        var options = that.data.options;
        console.log("comment ret >>>>", ret);

        if (ret.data && ret.data != 0) {
            that.setData({
                showCommentModal: false
                // parentId: 0
            });

            wx.showToast({
                title: "评论成功"
                // success: that.getComment(that.data.resourceId)
            });
        }
    },

    quitCommentTap: function quitCommentTap() {
        this.setData({
            showCommentModal: false
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {
        this.setData({
            page: 0,
            msgList: []
        });
        this.onLoad(this.data.options);
    },

    onReachBottom: function onReachBottom() {
        var page = this.data.page + 1,
            classId = this.data.options.classId;
        this.getMsgList(classId, page);

        this.setData({
            page: page
        });
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/classMsg/classMsg.js")
var __wxRoute = "pages/msgDetail/msgDetail", __wxRouteBegin = true;
define("pages/msgDetail/msgDetail.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../util/util.js');

Page({

    data: {
        lat: 0,
        lng: 0,
        id: 0
    },

    onLoad: function onLoad(options) {
        var id = options.id;
        this.setData({
            id: id
        });
        this.getLoc();
    },

    onShow: function onShow() {},

    getLoc: function getLoc() {
        // 获取用户地理位置
        var that = this;

        wx.getLocation({
            success: function success(res) {
                if (typeof cb == 'function') {
                    cb(res);
                } else {
                    that.setData({
                        lat: res.latitude,
                        lng: res.longitude
                    });
                }
            },
            fail: function fail() {
                wx.showToast({
                    title: '获取位置失败',
                    icon: 'loading'
                });
            },
            complete: function complete() {
                that.getMsgDetail();
            }
        });
    },

    // 添加消息查看次数
    getMsgDetail: function getMsgDetail() {
        var that = this;
        var id = that.data.id,
            lat = that.data.lat,
            lng = that.data.lng;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_by_uid',
            data: {
                uid: id,
                lat: lat,
                lng: lng
            },
            success: function success(ret) {
                console.log("getMsgDetail ret >>>>>", ret);
                var detail = ret.data;
                // 处理时间
                var time = util.formatTime(detail.create_time);
                detail.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                // 判断是否包含图片
                if (detail.images && detail.images.length !== 0) {
                    for (var i = 0; i < detail.images.length; i++) {
                        detail.images[i] = app.globalData.prefix_url + detail.images[i];
                    }
                }

                if (detail.biz) {
                    var img = detail.biz.main_img;
                    if (!img.startsWith("http")) detail.biz.main_img = app.globalData.prefix_url + img;
                }

                detail.distance = detail.juli ? parseInt(detail.juli) + 'km' : '未获取位置';

                that.setData({
                    msgData: detail
                });

                // 停止刷新
                wx.stopPullDownRefresh();
            }
        });
    },

    previewImg: function previewImg(e) {
        var idx = e.currentTarget.id,
            images = this.data.msgData.images;

        wx.previewImage({
            current: images[idx], // 当前显示图片的http链接
            urls: images // 需要预览的图片http链接列表
        });
    },

    // 点赞
    likeTap: function likeTap() {
        var that = this,
            id = that.data.id,
            msgData = that.data.msgData,
            like = msgData.su_good;

        app.request({
            url: '_a=classmsg&_u=ajax.add_good_cnt',
            data: {
                msg_uid: id
            },
            success: function success(ret) {
                console.log("like tap ret >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    var title = like ? '取消成功' : '点赞成功';
                    wx.showToast({
                        title: title
                    });
                }
            }
        });

        msgData.su_good = !like;
        msgData.su_good ? msgData.good_cnt++ : msgData.good_cnt--;

        that.setData({
            msgData: msgData
        });
    },

    // 评论
    commentTap: function commentTap(e) {
        // var id = this.data.id;

        this.setData({
            showCommentModal: true
            // commentId: id
        });
    },

    // 提交评论
    bindFormSubmit: function bindFormSubmit(e) {
        var comment = e.detail.value.textarea;
        var that = this,
            commentId = that.data.id;
        // parentId = that.data.parentId;

        console.log("commentId >>>>", commentId);
        // console.log("parentId >>>>", parentId);

        app.request({
            url: "_a=classmsg&_u=ajax.add_comment",
            data: {
                msg_uid: commentId,
                // parent_uid: parentId,
                content: comment
            },
            success: that.commentCallback
        });
    },
    commentCallback: function commentCallback(ret) {
        var that = this;
        var options = that.data.options;
        console.log("comment ret >>>>", ret);

        if (ret.data && ret.data != 0) {
            that.setData({
                showCommentModal: false
                // parentId: 0
            });

            wx.showToast({
                title: "评论成功"
                // success: that.getComment(that.data.resourceId)
            });

            that.getMsgDetail();
        }
    },

    quitCommentTap: function quitCommentTap() {
        this.setData({
            showCommentModal: false
        });
    },

    makePhoneCall: function makePhoneCall(e) {
        var msgData = this.data.msgData;
        var phone = msgData.tel;

        if (msgData.biz) {
            phone = msgData.biz.phone;
        }
        wx.makePhoneCall({
            phoneNumber: phone
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {
        that.getMsgDetail();
    },

    onReachBottom: function onReachBottom() {},

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/msgDetail/msgDetail.js")
var __wxRoute = "pages/search/search", __wxRouteBegin = true;
define("pages/search/search.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
var util = require("../../util/util.js");

// 输入框进行输入时隐藏搜索结果
Page({

    data: {
        searchType: "message",
        inputVal: "",
        page: 0,
        showList: [],
        businessList: [],
        showEmpty: false,
        noMore: false,
        searchRecord: []
    },

    onLoad: function onLoad(options) {
        var that = this;
        console.log("options >>>", options);

        if (options.type == "business") {
            this.setData({
                searchType: options.type
            });

            // 获取商户搜索历史记录
            this.getBizRecord();
        } else {
            // 获取动态消息历史搜索记录
            this.getRecord();
        }
    },

    onShow: function onShow() {},

    // 获取历史搜索记录函数
    getRecord: function getRecord() {
        var that = this;
        wx.getStorage({
            key: 'search',
            success: function success(res) {
                // console.log(res.data)
                var searchData = res.data;
                if (searchData) {
                    that.setData({
                        searchRecord: searchData.list
                    });
                }
                console.log("msg storage >>>", res);
            }
        });
    },

    // 获取历史搜索记录函数
    getBizRecord: function getBizRecord() {
        var that = this;
        wx.getStorage({
            key: 'searchBiz',
            success: function success(res) {
                console.log("business storage >>>", res);
                var searchData = res.data;
                if (searchData) {
                    that.setData({
                        searchRecord: searchData.list
                    });
                }
            }
        });
    },

    // 输入关键字事件
    inputTyping: function inputTyping(e) {
        var that = this;
        var searchKey = e.detail.value;

        this.setData({
            inputVal: searchKey
        });
    },

    // 搜素关键字事件
    searchTap: function searchTap(e) {
        var that = this,
            searchType = that.data.searchType,
            searchKey = e.detail.value,
            searchRecord = that.data.searchRecord;

        this.setData({
            inputVal: searchKey
        });

        if (searchKey) {
            // 存入搜索历史记录
            if (searchRecord.indexOf(searchKey) == -1) {
                searchRecord.unshift(searchKey);
                var searchData = {};
                var key = searchType == "message" ? "search" : "searchBiz";
                searchData.list = searchRecord;

                wx.setStorage({
                    key: key,
                    data: searchData
                });
            }
            if (searchType == "message") {
                that.searchByKey(searchKey, 0);
            } else {
                that.searchBizByKey(searchKey, 0);
            }
        }
    },

    // 搜索动态消息
    searchByKey: function searchByKey(searchKey, page) {
        var that = this;
        app.request({
            url: "_a=classmsg&_u=ajax.get_class_by_cat_uid",
            data: {
                key: searchKey,
                page: page
            },
            success: function success(ret) {
                console.log("msg ret >>>>>", ret);

                var list = ret.data.list;

                list.forEach(function (ele) {
                    // 处理时间
                    var time = util.formatTime(ele.create_time);
                    ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                    // 判断是否包含图片
                    if (ele.images && ele.images.length !== 0) {
                        for (var i = 0; i < ele.images.length; i++) {
                            ele.images[i] = app.globalData.prefix_url + ele.images[i];
                        }
                    }
                });

                var showList = page == 0 ? [] : that.data.showList;
                showList = showList.concat(list);

                that.setData({
                    page: page,
                    noMore: list.length < 10,
                    showList: showList
                });

                // 停止刷鞋
                wx.stopPullDownRefresh();
            }
        });
    },

    // 搜搜商户
    searchBizByKey: function searchBizByKey(searchKey, page) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_bizlist",
            data: {
                key: searchKey,
                page: page
            },
            success: function success(ret) {
                console.log("business ret >>>", ret);
                var businessList = ret.data.list,
                    len = businessList.length;

                businessList.forEach(function (ele) {
                    if (!ele.main_img.startsWith("http")) ele.main_img = app.globalData.prefix_url + ele.main_img;
                    if (ele.juli) ele.juli = parseFloat(ele.juli).toFixed(1);
                });

                var list = page == 0 ? [] : that.data.businessList;
                list = list.concat(businessList);

                that.setData({
                    businessList: list,
                    page: page,
                    showEmpty: len < 10
                });
            }
        });
    },

    // 清除输入框内容
    clearInput: function clearInput() {
        this.setData({
            inputVal: "",
            showList: [],
            businessList: [],
            noMore: false,
            showEmpty: false
        });
    },

    // 点击搜索历史记录
    tapRecord: function tapRecord(e) {
        var id = e.currentTarget.id;
        var type = this.data.searchType;

        this.setData({
            inputVal: id
        });

        if (type == "message") {
            this.searchByKey(id, 0);
        } else {
            this.searchBizByKey(id, 0);
        }
    },

    // 清除历史记录
    clearRecord: function clearRecord(e) {
        var that = this;
        var type = this.data.searchType;
        var key = type == "message" ? "search" : "searchBiz";

        wx.removeStorage({
            key: key,
            success: function success(res) {
                that.setData({
                    searchRecord: []
                });
            }
        });
    },

    // 用户点击输入框进行输入
    // inputFocus: function(e) {
    //     console.log("input e >>>", e);
    //     this.getRecord();
    //     this.setData({
    //         searchResult: []
    //     });
    // },

    // onPullDownRefresh: function () {

    // },

    onReachBottom: function onReachBottom() {
        var that = this;
        var page = that.data.page + 1;
        var type = that.data.searchType;

        if (type == "message") {
            that.searchByKey(that.data.inputVal, page);
        } else {
            that.searchBizByKey(that.data.inputVal, page);
        }
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/search/search.js")
var __wxRoute = "pages/switchCity/switchCity", __wxRouteBegin = true;
define("pages/switchCity/switchCity.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var city = require('../../util/city.js');

Page({
    data: {
        searchLetter: [],
        showLetter: "",
        winHeight: 0,
        tHeight: 0,
        bHeight: 0,
        startPageY: 0,
        cityList: [],
        isShowLetter: false,
        scrollTop: 0,
        city: ""
    },

    onLoad: function onLoad(options) {
        // 生命周期函数--监听页面加载
        var searchLetter = city.searchLetter;
        var cityList = city.cityList();
        var optionsCity = options.city;
        if (optionsCity.startsWith("全国")) optionsCity = optionsCity.replace("市", "");
        // cityList.unshift("")
        // console.log(cityInfo);

        var sysInfo = wx.getSystemInfoSync();
        console.log(sysInfo);
        var winHeight = sysInfo.windowHeight;

        //添加要匹配的字母范围值
        //1、更加屏幕高度设置子元素的高度
        var itemH = winHeight / searchLetter.length;
        var tempObj = [];
        for (var i = 0; i < searchLetter.length; i++) {
            var temp = {};
            temp.name = searchLetter[i];
            temp.tHeight = i * itemH;
            temp.bHeight = (i + 1) * itemH;

            tempObj.push(temp);
        }

        this.setData({
            winHeight: winHeight,
            itemH: itemH,
            searchLetter: tempObj,
            cityList: cityList,
            city: optionsCity
        });

        console.log(this.data.cityInfo);
    },

    onShow: function onShow() {
        // 生命周期函数--监听页面显示

    },

    searchStart: function searchStart(e) {
        var showLetter = e.currentTarget.dataset.letter;
        var pageY = e.touches[0].pageY;
        this.setScrollTop(this, showLetter);
        this.nowLetter(pageY, this);
        this.setData({
            showLetter: showLetter,
            startPageY: pageY,
            isShowLetter: true
        });
    },
    searchMove: function searchMove(e) {
        var pageY = e.touches[0].pageY;
        var startPageY = this.data.startPageY;
        var tHeight = this.data.tHeight;
        var bHeight = this.data.bHeight;
        var showLetter = 0;
        console.log(pageY);
        if (startPageY - pageY > 0) {
            //向上移动
            if (pageY < tHeight) {
                // showLetter=this.mateLetter(pageY,this);
                this.nowLetter(pageY, this);
            }
        } else {
            //向下移动
            if (pageY > bHeight) {
                // showLetter=this.mateLetter(pageY,this);
                this.nowLetter(pageY, this);
            }
        }
    },
    searchEnd: function searchEnd(e) {
        // console.log(e);
        // var showLetter=e.currentTarget.dataset.letter;
        var that = this;
        setTimeout(function () {
            that.setData({
                isShowLetter: false
            });
        }, 1000);
    },

    nowLetter: function nowLetter(pageY, that) {
        //当前选中的信息
        var letterData = this.data.searchLetter;
        var bHeight = 0;
        var tHeight = 0;
        var showLetter = "";
        for (var i = 0; i < letterData.length; i++) {
            if (letterData[i].tHeight <= pageY && pageY <= letterData[i].bHeight) {
                bHeight = letterData[i].bHeight;
                tHeight = letterData[i].tHeight;
                showLetter = letterData[i].name;
                break;
            }
        }

        this.setScrollTop(that, showLetter);

        that.setData({
            bHeight: bHeight,
            tHeight: tHeight,
            showLetter: showLetter,
            startPageY: pageY
        });
    },
    bindScroll: function bindScroll(e) {
        console.log(e.detail);
    },
    setScrollTop: function setScrollTop(that, showLetter) {
        that.setData({
            scrollLetter: showLetter
        });
    },
    bindCity: function bindCity(e) {
        var city = e.currentTarget.dataset.city,
            city = city.replace("市", "");
        var pages = getCurrentPages();
        var indexPage = pages[pages.length - 2];

        indexPage.setData({
            currentCity: city,
            switchCity: true
        });

        wx.navigateBack();
    }
});
});require("pages/switchCity/switchCity.js")
var __wxRoute = "pages/editSelect/editSelect", __wxRouteBegin = true;
define("pages/editSelect/editSelect.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();

Page({

    data: {},

    onLoad: function onLoad(options) {
        var that = this;
        that.getAllCats();
    },

    onShow: function onShow() {},

    getAllCats: function getAllCats(cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_cats',
            success: function success(ret) {
                console.log("all cats >>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var list = ret.data;
                    list.forEach(function (ele) {
                        ele.image = app.globalData.prefix_url + ele.image;
                    });
                    that.setData({
                        cats: list
                    });
                }
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    onReachBottom: function onReachBottom() {},

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/editSelect/editSelect.js")
var __wxRoute = "pages/edit/edit", __wxRouteBegin = true;
define("pages/edit/edit.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
// var uploadImage = [];

Page({
    data: {
        // picFile: "../../resources/pic/default.png",
        showTopTips: false,
        files: [],
        uploadImage: [],
        phone: "",

        buyTop: false,
        dates: [],
        dateIndex: 0,

        loc: {
            longitude: 0,
            latitude: 0
        }
    },

    onLoad: function onLoad(options) {
        var that = this;
        var classId = options.classId;
        that.setData({
            classId: classId
        });
        that.getPostPrice();
        that.getClassDetail(classId);
        that.getUserPhone();
        that.getBusiness();
    },

    // 获取发布消息的各项费用
    getPostPrice: function getPostPrice(cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_classset',
            success: function success(ret) {
                console.log("get price ret >>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var priceList = ret.data,
                        priceArr = [],
                        dates = [];

                    priceList.forEach(function (ele) {
                        var date = ele[0] + '天';
                        dates.push(date);
                        var price = parseFloat(ele[1] / 100).toFixed(2);
                        priceArr.push(price);
                    });
                    that.setData({
                        dates: dates,
                        priceArr: priceArr
                    });
                }
            }
        });
    },

    getClassDetail: function getClassDetail(classId, cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_cat_by_uid',
            data: {
                uid: classId
            },
            success: function success(ret) {
                console.log("class detail >>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var price = parseFloat(ret.data.paid_fee / 100).toFixed(2);
                    that.setData({
                        price: price,
                        totalPrice: price
                    });
                }
            }
        });
    },

    getUserPhone: function getUserPhone() {
        var that = this;

        app.request({
            url: '_a=su&_u=ajax.profile',
            data: {},
            success: function success(ret) {
                console.log("userInfo >>>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var phone = ret.data.profile.phone;
                    if (phone) {
                        that.setData({
                            phone: phone
                        });
                    }
                }
            }
        });
    },

    // 获取商家信息
    getBusiness: function getBusiness(cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_biz",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.getBusinessCb(ret);
                }
            }
        });
    },

    getBusinessCb: function getBusinessCb(ret) {
        var that = this;
        console.log("get business ret >>>>", ret);
        var businessData = ret.data;
        if (businessData) {
            var loc = {};
            loc.longitude = businessData.lng;
            loc.latitude = businessData.lat;

            that.setData({
                phone: businessData.phone,
                currentAddress: businessData.location,
                loc: loc
            });
        }
    },

    // 用户输入
    userInput: function userInput(e) {
        var content = e.detail.value,
            id = e.currentTarget.dataset.id;
        if (id == "phone") {
            this.setData({
                phone: content
            });
        } else {
            this.setData({
                currentAddress: content
            });
        }
        console.log("input detail >>>>>", content);
    },

    // 选择是否置顶
    switchChange: function switchChange(e) {
        var buyTop = !this.data.buyTop;
        this.setData({
            buyTop: buyTop
        });
        // this.calculatePrice();
    },

    // 选择置顶天数
    bindPickerChange: function bindPickerChange(e) {
        this.setData({
            dateIndex: e.detail.value
        });
        // this.calculatePrice();
    },

    // 选择图片
    chooseImage: function chooseImage(e) {
        var that = this;
        var count = 6 - that.data.files.length;

        if (count > 0) {
            wx.chooseImage({
                count: count,
                sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
                sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
                success: that.chooseImageCb
            });
        } else {
            this.setData({
                showTopTips: true
            });
            this.delayClose();
        }
    },
    chooseImageCb: function chooseImageCb(res) {
        var that = this,
            originFiles = that.data.files,
            length = 6 - originFiles.length,
            chooseFiles = res.tempFilePaths.slice(0, length);
        // files = originFiles.concat(chooseFiles);

        // that.setData({
        //     files: files
        // });

        that.uploadImg(chooseFiles, 0);
        // console.log("tempFilePaths >>>>", files);
    },
    // 依次上传多张图片
    uploadImg: function uploadImg(imgArr, idx) {
        var that = this,
            uploadImage = that.data.uploadImage,
            uploadURL = app.globalData.prefix_url + "?_a=upload&_u=index.upload";

        // 上传图片
        wx.uploadFile({
            url: uploadURL,
            filePath: imgArr[idx],
            name: 'file',
            success: function success(res) {
                var picData = JSON.parse(res.data);

                var files = that.data.files.concat(imgArr[idx]);
                that.setData({
                    files: files
                });

                var picUrl = picData.data.url;
                console.log("chooseImage url >>>>", picUrl);
                uploadImage.push(picUrl);
                console.log("uploadImage >>>>>>", uploadImage);
                that.setData({
                    uploadImage: uploadImage
                });
            },
            fail: function fail(_ref) {
                var errMsg = _ref.errMsg;

                console.log('uploadImage fail, errMsg is', errMsg);
            },
            complete: function complete() {
                idx++;
                if (idx >= imgArr.length) {
                    wx.showToast({
                        title: '图片上传成功'
                    });
                } else {
                    that.uploadImg(imgArr, idx);
                }
            }
        });
    },

    // 延迟关闭顶部提示
    delayClose: function delayClose() {
        var that = this;
        setTimeout(function () {
            that.setData({
                showTopTips: false
            });
        }, 1500);
    },

    // 预览上传图片
    previewImage: function previewImage(e) {
        var id = parseInt(e.currentTarget.id);
        var current = this.data.files[id];
        wx.previewImage({
            current: current, // 当前显示图片的http链接
            urls: this.data.files // 需要预览的图片http链接列表
        });
    },

    // 删除长按的图片
    deleteImg: function deleteImg(e) {
        var id = parseInt(e.currentTarget.id),
            uploadImage = that.data.uploadImage,
            files = this.data.files;
        console.log("delete id >>>", id);
        files.splice(id, 1);
        uploadImage.splice(id, 1);
        console.log("files show >>>>>", files);
        console.log("uploadImage >>>>>", uploadImage);
        this.setData({
            files: files,
            uploadImage: uploadImage
        });
    },

    // 获取当前位置
    getLocation: function getLocation() {
        var that = this;
        wx.getLocation({
            success: function success(res) {
                that.setData({
                    loc: res
                });
                var requestUrl = '_easy=web.index.geo2name&lat=' + res.latitude + '&lng=' + res.longitude + '&type=tencent';
                app.request({
                    url: requestUrl,
                    success: function success(ret) {
                        // that.addFriend(ret.data.address);
                        that.setData({
                            currentAddress: ret.data.address
                        });
                    }
                });
            },
            fail: function fail() {}
        });
    },

    // 点击发布打听
    tapPost: function tapPost(e) {
        var that = this;

        var content = e.detail.value.textarea,
            catId = that.data.classId,
            phone = that.data.phone ? that.data.phone : "",
            address = that.data.currentAddress ? that.data.currentAddress : "",
            price = that.data.price ? that.data.price * 100 : 0,
            days = that.data.buyTop ? that.data.dates[that.data.dateIndex] : 0,
            topPrice = that.data.buyTop ? that.data.priceArr[that.data.dateIndex] * 100 : 0,
            loc = that.data.loc,
            images = that.data.uploadImage.join(";");

        if (!!days && days != 0) days = days.substr(0, days.length - 1);

        var priceArr = [10, 5000, 10000, 20000, 50000, 100000];
        var price = priceArr[that.data.priceIndex];
        // var pic = that.data.uploadImage;

        console.log("else_info price >>>", topPrice);
        console.log("else_info days >>>", days);
        console.log("post content >>>", content);
        // 支付流程
        if (!content) {
            wx.showModal({
                content: "请填写消息内容",
                showCancel: false
            });
        } else if (!address) {
            wx.showModal({
                content: "请填写地址",
                showCancel: false
            });
        } else if (!phone) {
            wx.showModal({
                content: "请填写联系电话",
                showCancel: false
            });
        } else {
            // 发布消息
            app.request({
                url: "_a=classmsg&_u=ajax.add_classmsg",
                data: {
                    cat_uid: catId,
                    tel: phone,
                    images: images,
                    else_info: {
                        days: days,
                        paid_fee: topPrice
                    },
                    paid_fee: price,
                    brief: content,
                    address: address,
                    lng: loc.longitude,
                    lat: loc.latitude
                },
                success: that.postAskCb
            });
        }
    },

    // 发布打听回调函数
    postAskCb: function postAskCb(ret) {
        console.log("msg post return >>>>", ret);
        if (ret.data && ret.data != 0) {
            var price = this.data.price,
                topPrice = this.data.buyTop ? this.data.priceArr[this.data.dateIndex] * 100 : 0,
                totalPrice = price + topPrice;

            console.log("totalPrice >>>>>", totalPrice);
            if (totalPrice > 0) {
                this.do_pay(ret.data);
            } else {
                wx.showToast({
                    title: '发布成功',
                    success: function success(ret) {
                        wx.navigateBack();
                    }
                });
            }
            this.setData({
                postAskId: ret.data
            });
        } else if (ret.errno == 403 && ret.errstr == "ERROR_OUT_OF_LIMIT") {
            wx.showModal({
                title: "发布失败",
                content: "您发布的消息总数已超过每日/月发送消息数量限制，vip商户无此限制",
                showCancel: false
            });
        }
    },

    //支付
    do_pay: function do_pay(uid) {
        var that = this;
        var options = that.data.options;
        if (!uid || that.data.paying) return;
        that.setData({ paying: true });
        var data = { oid: 'm' + uid, openid: app.globalData.openid };
        app.request({
            url: '_a=pay&_u=index.wxxiaochengxu',
            data: data,
            'success': function success(ret) {
                console.log("pay return >>>>>>", ret);
                that.setData({ paying: false });
                if (!ret.data || !ret.data.xiaochengxuParameters) {
                    return app.alert('支付失败！' + ret.errno);
                }
                var obj = ret.data.xiaochengxuParameters;
                obj['success'] = function () {
                    // app.alert('支付成功!');
                    wx.showToast({
                        title: "支付成功"
                    });
                    app.request({
                        url: '_a=pay&_u=index.wxxiaochengxu_update_order',
                        data: data
                    });
                    // that.onLoad(options);
                    wx.navigateBack();
                };
                obj['complete'] = function () {
                    that.setData({ paying: false });
                };
                wx.requestPayment(obj);
            }
        });
    }
});
});require("pages/edit/edit.js")
var __wxRoute = "pages/my/my", __wxRouteBegin = true;
define("pages/my/my.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({
    data: {
        company_name: app.globalData.company_name,
        // 导航项列表数据
        navList: [{
            id: "myPost",
            pic: "myPost.jpg",
            title: "我的发布",
            show: true
        }, {
            id: "myCoupon",
            pic: "coupon.jpg",
            title: "我的红包",
            show: true
        }, {
            id: "businessDetail",
            pic: "myShop.jpg",
            title: "我的店铺",
            show: true
        }, {
            id: "businessQrcode",
            pic: "qrcode.jpg",
            title: "店铺二维码",
            show: false
        }, {
            id: "mySetting",
            pic: "setting.jpg",
            title: "隐私设置",
            show: true
        }, {
            id: "favorite",
            pic: "favorite.jpg",
            title: "我的收藏",
            show: true
        }, {
            id: "myAbout",
            pic: "about.jpg",
            title: "关于我们",
            show: true
        }],
        userInfo: {},
        shareTap: false
    },

    onLoad: function onLoad() {
        var that = this;

        this.setData({
            userInfo: app.globalData.userInfo
        });

        // 获取商户信息
        this.getBusiness();

        wx.showShareMenu({
            withShareTicket: true
        });
    },

    onShow: function onShow() {
        var that = this;
    },

    // 获取商家信息
    getBusiness: function getBusiness(cb) {
        var that = this;
        app.request({
            url: "_a=shop&_u=biz.ajax_biz",
            success: function success(ret) {
                if (typeof cb === "function") {
                    cb(ret);
                } else {
                    that.getBusinessCb(ret);
                }
            }
        });
    },

    getBusinessCb: function getBusinessCb(ret) {
        var that = this;
        console.log("get business ret >>>>", ret);
        var navList = that.data.navList;
        // navList[2].show = ret.data
        // wx.hideLoading()
        that.setData({
            businessData: ret.data
        });
    },

    tapItem: function tapItem(e) {
        var id = e.currentTarget.dataset.id;
        var that = this;

        if (id == "mySetting") {
            wx.openSetting({
                success: function success(res) {
                    console.log("setting ret >>>>", res);
                }
            });
        } else if (id == "businessDetail") {
            that.handleMyShop();
        } else if (id == "businessQrcode") {
            that.createQRcode();
        } else {
            var pageUrl = ["..", id, id].join("/");
            wx.navigateTo({
                url: pageUrl
            });
        }
    },

    // 操作我的店铺
    handleMyShop: function handleMyShop() {
        var that = this;
        var businessData = that.data.businessData;

        if (businessData) {
            var status = businessData.status;
            if (status == 0) {
                wx.showModal({
                    title: "您的信息正在审核中，请耐心等待",
                    showCancel: false
                });
            } else if (status == 1) {
                wx.navigateTo({
                    url: "/pages/businessDetail/businessDetail?uid=" + businessData.uid
                });
            } else if (status == 2) {
                wx.showModal({
                    title: "您的信息审核未通过，是否重新申请？",
                    confirmText: "重新申请",
                    success: function success(res) {
                        if (res.confirm) {
                            wx.navigateTo({
                                url: "../apply/apply"
                            });
                        } else {
                            wx.navigateBack();
                        }
                    }
                });
            }
        } else {
            wx.showModal({
                title: "您还不是商家",
                content: "是否申请成为商家？",
                confirmText: "去申请",
                success: function success(res) {
                    if (res.confirm) {
                        wx.navigateTo({
                            url: "../apply/apply"
                        });
                    }
                }
            });
        }
    },

    // 获取二维码
    createQRcode: function createQRcode() {
        var that = this;
        var businessData = that.data.businessData;

        if (businessData && businessData.hadv == 1) {
            var encodeUrl = encodeURIComponent("/pages/businessDetail/businessDetail?uid=" + businessData.uid);
            var qrcodeUrl = app.globalData.server_url + "_u=xiaochengxu.qrcode&type=1&path=" + encodeUrl;
            console.log("qrcodeUrl >>>>", qrcodeUrl);

            wx.previewImage({
                current: qrcodeUrl, // 当前显示图片的http链接
                urls: [qrcodeUrl] // 需要预览的图片http链接列表
            });
        } else {
            wx.showModal({
                title: "温馨提示",
                content: "成为入驻商户并申请VIP商户才可生成专属二维码",
                showCancel: false
            });
        }
    },

    // 获取用户信息回调函数
    getCallback: function getCallback(ret) {
        console.log("user >>>>", ret);
        var that = this;
        var userData = ret.data.su;
        that.setData({
            userInfo: userData,
            shareTap: true
        });

        if (!ret.data.profile.set_info.notMessPush) {
            // 获取全部最新消息
            app.request({
                url: "_a=su&_u=ajax.get_send_msg",
                success: function success(ret) {
                    console.log("new message >>>", ret);
                    var messList = ret.data.list;

                    // var showNews = false;
                    var messNum = wx.getStorageSync('messageNum');
                    if (messNum) {
                        var showNews = messList.length > messNum;
                        console.log("setStorage num ", messNum);

                        that.setData({
                            showNews: showNews
                        });
                    }
                }
            });
        }

        var list = that.data.navList;

        list.forEach(function (ele) {
            if (ele.id === "myApprove") {
                ele.title = state;
            }
        });

        that.setData({
            navList: list
        });
    },

    // 分享该页面
    onShareAppMessage: function onShareAppMessage(res) {
        if (res.from === 'button') {
            var userInfo = this.data.userInfo;
            var title = "请查收" + userInfo.name + "的名片";
            var shareUrl = "pages/my/pages/myNameCard/myNameCard?uid=" + userInfo.uid;

            console.log("shareUrl >>>", shareUrl);
            return {
                title: title,
                desc: '这是我在芒格学院的名片',
                path: shareUrl
            };
        }
        return {
            success: function success(res) {
                // 转发成功
            },
            fail: function fail(res) {
                // 转发失败
            }
        };
    }
});
});require("pages/my/my.js")
var __wxRoute = "pages/favorite/favorite", __wxRouteBegin = true;
define("pages/favorite/favorite.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置

Page({

    data: {
        cartImg: app.globalData.server_url + "_u=common.img&name=cart.png",
        favlist: [],
        bizList: []

        // tabs: ["收藏商品", "关注商铺"],
        // activeIndex: 0,
        // sliderOffset: 0,
        // sliderLeft: 0
    },

    onLoad: function onLoad(options) {
        var that = this;
        this.setData({
            mainColor: "#ff4526"
        });

        that.getFavBizList(0);
    },

    onShow: function onShow() {},

    // 获取收藏的商店列表
    getFavBizList: function getFavBizList(page) {
        var that = this;

        app.request({
            url: "_a=shop&_u=biz.get_biz_fav",
            data: {
                page: page
            },
            success: function success(ret) {
                console.log("favorite business list ret >>>>", ret);
                var bizList = ret.data.list;
                bizList.forEach(function (ele) {
                    if (!ele.biz.main_img.startsWith("http")) ele.biz.main_img = app.globalData.prefix_url + ele.biz.main_img;
                });
                var list = that.data.bizList.concat(bizList);

                that.setData({
                    page1: page,
                    bizList: list
                });
            }
        });
    },

    onPullDownRefresh: function onPullDownRefresh() {},

    // 页面上拉触底事件的处理函数
    onReachBottom: function onReachBottom() {
        var page = this.data.page1 + 1;
        this.getFavBizList(page);
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/favorite/favorite.js")
var __wxRoute = "pages/myPost/myPost", __wxRouteBegin = true;
define("pages/myPost/myPost.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../util/util.js');

Page({
    data: {
        showList: [],
        page: 0
    },

    onLoad: function onLoad(options) {
        this.getUserMsg(0);
    },

    onShow: function onShow() {},

    getUserMsg: function getUserMsg(page, cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_by_su_uid',
            data: {
                page: page
            },
            success: function success(ret) {
                console.log("msg ret >>>>>", ret);

                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var list = ret.data.list;
                    var showList = page == 0 ? [] : that.data.showList;

                    list.forEach(function (ele) {
                        // 处理时间
                        var time = util.formatTime(ele.create_time);
                        ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                        // 判断是否包含图片
                        if (ele.images && ele.images.length !== 0) {
                            for (var i = 0; i < ele.images.length; i++) {
                                ele.images[i] = app.globalData.prefix_url + ele.images[i];
                            }
                        }

                        // 区别商家和用户
                        if (ele.biz) {
                            var image = ele.biz.main_img;
                            // if (image.startsWith("http")) {}
                            ele.biz.main_img = image.startsWith("http") ? image : app.globalData.prefix_url + image;
                        }
                    });

                    var showList = showList.concat(list);

                    that.setData({
                        noMore: list.length < 10,
                        showList: showList
                    });

                    // 停止刷鞋
                    wx.stopPullDownRefresh();
                }
            }
        });
    },

    removeTap: function removeTap(e) {
        var id = e.currentTarget.dataset.id,
            that = this;
        console.log("remove tap id >>>", id);

        wx.showModal({
            title: "确定删除该消息？",
            success: function success(res) {
                if (res.confirm) {
                    that.removeRequest(id);
                }
            }
        });
    },

    removeRequest: function removeRequest(id) {
        var that = this;
        app.request({
            url: "_a=classmsg&_u=ajax.del_classmsg",
            data: {
                uids: id
            },
            success: function success(ret) {
                console.log("remove ret >>>>>", ret);
                if (ret.data && ret.data != 0) {
                    wx.showToast({
                        title: "删除成功"
                    });
                    that.getUserMsg(0);
                }
            }
        });
    },

    // 成交按钮
    makeDeal: function makeDeal(e) {
        var that = this;
        var msgId = e.currentTarget.dataset.id;

        wx.showModal({
            title: "温馨提示",
            content: "确定将此消息标记为已成交吗？",
            success: function success(ret) {
                if (ret.confirm) {
                    app.request({
                        url: "_a=classmsg&_u=ajax.edit_classmsg_status",
                        data: {
                            uid: msgId,
                            status: 2
                        },
                        success: function success(res) {
                            console.log("make deal ret >>>>>", res);
                            if (res.data && res.data != 0) {
                                wx.showToast({
                                    title: "标记成功"
                                });
                                that.getUserMsg(0);
                            }
                        }
                    });
                }
            }
        });
    },

    onReachBottom: function onReachBottom() {
        var page = this.data.page + 1;
        this.getUserMsg(page);
        this.setData({
            page: page
        });
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/myPost/myPost.js")
var __wxRoute = "pages/userInfo/userInfo", __wxRouteBegin = true;
define("pages/userInfo/userInfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var app = getApp();
var util = require('../../util/util.js');

Page({
    data: {
        showList: [],
        page: 0
    },

    onLoad: function onLoad(options) {
        var id = options.userId;

        this.setData({
            userId: id
        });

        this.getUserInfo(id);
        this.getMainInfo(id);
        this.getUserMsg(id, 0);
    },

    onShow: function onShow() {},

    getUserInfo: function getUserInfo(id, cb) {
        var that = this;

        app.request({
            url: '_a=su&_u=ajax.get_su',
            data: {
                su_uid: id
            },
            success: function success(ret) {
                console.log("userInfo >>>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    that.setData({
                        userInfo: ret.data.su
                    });
                    var title = ret.data.su.name + ' 的主页';
                    wx.setNavigationBarTitle({
                        title: title
                    });
                }
            }
        });
    },

    getMainInfo: function getMainInfo(id, cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_cnt',
            data: {
                su_uid: id
            },
            success: function success(ret) {
                console.log("count ret >>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    that.setData({
                        counts: ret.data
                    });
                }
            }
        });
    },

    getUserMsg: function getUserMsg(id, page, cb) {
        var that = this;

        app.request({
            url: '_a=classmsg&_u=ajax.get_class_by_su_uid',
            data: {
                su_uid: id,
                page: page
            },
            success: function success(ret) {
                console.log("msg ret >>>>>", ret);

                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    // that.getMsgListCb(ret);
                    // var that = this;
                    var list = ret.data.list;

                    list.forEach(function (ele) {
                        // 处理时间
                        var time = util.formatTime(ele.create_time);
                        ele.time = time[1] + '月' + time[2] + '日' + ' ' + time[3];

                        // 判断是否包含图片
                        if (ele.images && ele.images.length !== 0) {
                            for (var i = 0; i < ele.images.length; i++) {
                                ele.images[i] = app.globalData.prefix_url + ele.images[i];
                            }
                        }
                    });

                    var showList = that.data.showList.concat(list);

                    that.setData({
                        noMore: list.length < 10,
                        showList: showList
                    });

                    // 停止刷鞋
                    wx.stopPullDownRefresh();
                }
            }
        });
    },

    onReachBottom: function onReachBottom() {
        var page = this.data.page + 1,
            id = this.data.userId;

        this.getUserMsg(id, page);
        this.setData({
            page: page
        });
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/userInfo/userInfo.js")
var __wxRoute = "pages/mySet/mySet", __wxRouteBegin = true;
define("pages/mySet/mySet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
"use strict";

var app = getApp();

Page({
    data: {
        postData: {
            name: "",
            gender: 1,
            phone: ""
        }
    },

    onLoad: function onLoad(options) {
        this.getUserInfo();
    },

    onShow: function onShow() {},

    // 获取我的信息
    getUserInfo: function getUserInfo(cb) {
        var that = this;

        app.request({
            url: '_a=su&_u=ajax.profile',
            success: function success(ret) {
                console.log("userInfo >>>>>>", ret);
                if (typeof cb == 'function') {
                    cb(ret);
                } else {
                    var userInfo = ret.data,
                        postData = that.data.postData;
                    postData.name = userInfo.su.name;
                    postData.gender = userInfo.su.gender;
                    postData.phone = userInfo.profile.phone;

                    that.setData({
                        avatar: userInfo.su.avatar,
                        name: userInfo.su.name,
                        postData: postData
                    });
                }
            }
        });
    },

    userInput: function userInput(e) {
        var id = e.currentTarget.id,
            postData = this.data.postData;
        postData[id] = e.detail.value;

        this.setData({
            postData: postData
        });
    },

    sexChange: function sexChange(e) {
        var value = e.detail.value,
            postData = this.data.postData;

        postData.gender = value;
        this.setData({
            postData: postData
        });
    },

    postTap: function postTap() {
        var that = this,
            postData = this.data.postData;

        console.log("postData >>>", postData);

        app.request({
            url: '_a=su&_u=ajax.update_all_su',
            data: postData,
            success: function success(ret) {
                console.log("postData ret >>>>", ret);
                if (ret.data && ret.data != 0) {
                    wx.showToast({
                        title: "修改成功"
                    });
                    that.onLoad();
                }
            }
        });
    },

    onShareAppMessage: function onShareAppMessage() {}
});
});require("pages/mySet/mySet.js")